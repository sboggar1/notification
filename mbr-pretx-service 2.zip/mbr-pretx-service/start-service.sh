#!/bin/ash

# The 'ash' shell is the default for Alpine Linux
# Variables are expected to be passed via docker whens starting the image
# You may have other variables; modify as needed.
#
# e.g. docker run -p 8080:8080 -e ENV=qa -e APPNAME=mbr-lookup-app -e PROFILE=isd walmart/pos/cpc-cart:latest

BASE_DIR=/home/app

. /etc/profile
export HOME=/home/app

# These memory settings allow us to control how much memory is allocated to the container
# via Docker/k8s and force the JVM to use the maximum memory allocated
# e.g. docker run -m 3GB <other settings>
#
JVM_MEMORY="-XX:+UnlockExperimentalVMOptions -XX:+UseCGroupMemoryLimitForHeap -XX:MaxRAMFraction=1"

JAVA_OPTS="$JVM_MEMORY $JAVA_OPTS"

java ${JAVA_OPTS} -jar ${BASE_DIR}/mbr-pretx-service*.jar