import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestJunit {
	
   String message = "Hello World";	

   @Test
   public void testPrintMessage() {
   	  String messageToCompare = "Hello World";
      assertEquals(message, messageToCompare);
   }
}