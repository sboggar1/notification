package com.sams.clubops.functions;

import com.sams.clubops.functions.predicates.MembershipPredicate;
import com.sams.clubops.mbr.lookup.models.MembershipUpdateDTO;
import com.sams.clubops.mbr.lookup.models.RenewalsAndUpgradeStatus;
import com.sams.clubops.mbr.lookup.services.MemberDetailsService;
import com.sams.clubops.mbr.sets.exceptions.CustomFilterException;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class MembershipPredicateTest {

    @InjectMocks
    private MembershipPredicate membershipPredicate;

    @Mock
    private MemberDetailsService memberDetailsService;

    public MembershipPredicateTest() {
        MockitoAnnotations.initMocks(this);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @MethodSource("provideInvalidMembershipObj")
    public void validateExceptionForInvalidDataForExpiredOrDeletedMembership(Map<String, Object> getMembershipObj) {
        Assertions.assertThrows(CustomFilterException.class, () -> membershipPredicate.isNotExpiredOrDeletedMembership().test(getMembershipObj));
    }

    @ParameterizedTest
    @MethodSource("provideMembershipObj")
    public void validateIsNotExpiredOrDeletedMembership(Map<String, Object> getMembershipObj, boolean expected) {
        when(memberDetailsService.findByMembershipId(anyString())).thenAnswer(invocationOnMock -> {
            Object argument = invocationOnMock.getArguments()[0];
            final String NOT_FOUND = "1";
            final String COMPLETED = "2";
            if (argument.equals(NOT_FOUND))
                return Optional.empty();
            else if (argument.equals(COMPLETED)) {
                MembershipUpdateDTO membershipUpdateDTO = new MembershipUpdateDTO();
                membershipUpdateDTO.setRenewalsAndUpgradeStatus(RenewalsAndUpgradeStatus.COMPLETED);
                return Optional.of(membershipUpdateDTO);
            } else {
                MembershipUpdateDTO membershipUpdateDTO = new MembershipUpdateDTO();
                membershipUpdateDTO.setRenewalsAndUpgradeStatus(RenewalsAndUpgradeStatus.IN_PROCESS);
                return Optional.of(membershipUpdateDTO);
            }
        });
        Assert.assertEquals(expected, membershipPredicate.isNotExpiredOrDeletedMembership().test(getMembershipObj));
    }

    private static Stream<Arguments> provideInvalidMembershipObj() {
        return Stream.of(
                Arguments.of(new HashMap<String, Object>() {{
                    put("invalidMembershipObj", null);
                }}),
                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("noMembershipObj", null);
                    }});
                }}),
                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", "notMap");
                    }});
                }})
        );
    }

    private static Stream<Arguments> provideMembershipObj() {
        return Stream.of(
                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", new HashMap<String, Object>() {{
                            put("memberStatus", "ACTIVE");
                            put("memberRole", "PRIMARY");
                        }});
                    }});
                }}, true),

                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", new HashMap<String, Object>() {{
                            put("memberStatus", "DELETED");
                            put("memberRole", "PRIMARY");
                        }});
                        put("id", "1");//NOT_FOUND in db
                    }});
                }}, false),

                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", new HashMap<String, Object>() {{
                            put("memberStatus", "EXPIRED");
                            put("memberRole", "PRIMARY");
                        }});
                        put("id", "1");//NOT_FOUND in db
                    }});
                }}, false),

                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", new HashMap<String, Object>() {{
                            put("memberStatus", "EXPIRED");
                            put("memberRole", "PRIMARY");
                        }});
                        put("id", "3");//FOUND in db but in pending/failed state
                    }});
                }}, true),

                Arguments.of(new HashMap<String, Object>() {{
                    put("getMembership", new HashMap<String, Object>() {{
                        put("membership", new HashMap<String, Object>() {{
                            put("memberStatus", "EXPIRED");
                            put("memberRole", "PRIMARY");
                        }});
                        put("id", "2");//FOUND in db and in Completed state
                    }});
                }}, false)
        );
    }
}
