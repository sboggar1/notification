package com.sams.clubops.spring.api;

import com.sams.clubops.mbr.lookup.spring.api.MbrLookupServiceController;
import com.sams.clubops.mbr.sets.domain.request.MbrSetsResponse;
import com.sams.clubops.mbr.sets.service.MbrSetsService;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MbrLookupServiceControllerTest {

    private MockMvc mockMvc;

    @Spy
    private List<MbrSetsService> serviceList = new ArrayList<>();

    @Mock
    private MbrSetsService testing;

    @Before
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
        serviceList.add(testing);
        serviceList.add(testing);
        when(testing.getQualifiedName()).thenReturn("types/CREATE_MEMBER", "types/MULTIPLE_MEMBER");
        MbrLookupServiceController mbrLookupServiceController = new MbrLookupServiceController(serviceList);
        mockMvc = MockMvcBuilders.standaloneSetup(mbrLookupServiceController)
                .build();
    }

    @ParameterizedTest
    @MethodSource(value = "createMemberValidSource")
    public void shouldCreateMemberSuccessfully(String membershipInfo, String expected, int expectedStatus) throws Exception {
        MbrSetsResponse response = new MbrSetsResponse();
        response.setStatus(MbrSetsResponse.MbrSetsResponseStatus.SUCCESS);
        when(testing.process(any())).thenReturn(response);
        this.mockMvc.perform(MockMvcRequestBuilders.post("/member/v2/membership")
                .contentType("application/json")
                .header("geo_id", 1)
                .header("business_id", 1)
                .header("channel_id", 1)
                .content(membershipInfo))
                .andExpect(MockMvcResultMatchers.status().is(expectedStatus))
                .andExpect(MockMvcResultMatchers.jsonPath("$.status", Matchers.is(expected)));
    }

    @ParameterizedTest
    @MethodSource(value = "createMemberInValidSource")
    public void shouldNotCreateMemberOnInvalidData(String membershipInfo, int expectedStatus) throws Exception {
        MbrSetsResponse response = new MbrSetsResponse();
        response.setStatus(MbrSetsResponse.MbrSetsResponseStatus.BAD_REQUEST);
        this.mockMvc.perform(MockMvcRequestBuilders.post("/member/v2/membership")
                .contentType("application/json")
                .header("geo_id", 1)
                .header("business_id", 1)
                .header("channel_id", 1)
                .content(membershipInfo))
                .andExpect(MockMvcResultMatchers.status().is(expectedStatus));
    }

    @ParameterizedTest
    @MethodSource(value = "createMemberInValidHeader")
    public void shouldNotCreateMemberOnInvalidHeader(String membershipInfo, String contentType, int expectedStatus) throws Exception {
        MbrSetsResponse response = new MbrSetsResponse();
        response.setStatus(MbrSetsResponse.MbrSetsResponseStatus.BAD_REQUEST);
        MockHttpServletRequestBuilder requestBuilders = MockMvcRequestBuilders.post("/member/v2/membership");
        if (contentType != null)
            requestBuilders.contentType(contentType);
        requestBuilders.content(membershipInfo);
        this.mockMvc.perform(requestBuilders).andExpect(MockMvcResultMatchers.status().is(expectedStatus));
    }

    private static Stream<Arguments> createMemberValidSource() {
        return Stream.of(
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "SUCCESS", 200),
                Arguments.of("{\"type\": \"MULTIPLE\",\"membershipInfo\": {\"primaryMembership\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "SUCCESS", 200),
                Arguments.of("{\"type\": \"single\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "SUCCESS", 200)
        );
    }

    private static Stream<Arguments> createMemberInValidSource() {
        return Stream.of(
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"primaryMembership\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", 400),
                Arguments.of("{\"type\": \"MULTIPLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", 400),
                Arguments.of("{\"type\": \"any\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", 400)
        );
    }

    private static Stream<Arguments> createMemberInValidHeader() {
        return Stream.of(
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", null, 415),
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "", 415),
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "application/xml", 415),
                Arguments.of("{\"type\": \"SINGLE\",\"membershipInfo\": {\"details\": { \"membership\": {\"membershipTier\":\"CLUB\",\"memberRole\":\"ADD_ON\"}}}}", "application/json", 400)
        );
    }

}
