package com.sams.clubops.services;


import com.sams.clubops.mbr.lookup.models.MembershipUpdateDTO;
import com.sams.clubops.mbr.lookup.repositories.MemberDetailsRepository;
import com.sams.clubops.mbr.lookup.services.MemberDetailsService;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.mockito.Mockito.when;

public class MemberDetailsServiceTest {

    @InjectMocks
    private MemberDetailsService memberDetailsService;

    @Mock
    private MemberDetailsRepository memberDetailsRepository;

    public MemberDetailsServiceTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMembershipIfFoundByMemberId() {
        MembershipUpdateDTO membershipUpdateDTO = new MembershipUpdateDTO();
        membershipUpdateDTO.setMembershipId("1");
        when(memberDetailsRepository.findByMembershipId("1")).thenReturn(Optional.of(membershipUpdateDTO));
        Assert.assertTrue(memberDetailsService.findByMembershipId("1").isPresent());
        Assert.assertEquals(membershipUpdateDTO, memberDetailsService.findByMembershipId("1").get());
    }

    @Test
    public void testMembershipIfNotFound() {
        when(memberDetailsRepository.findByMembershipId("1")).thenReturn(Optional.empty());
        Assert.assertFalse(memberDetailsService.findByMembershipId("1").isPresent());
    }

}
