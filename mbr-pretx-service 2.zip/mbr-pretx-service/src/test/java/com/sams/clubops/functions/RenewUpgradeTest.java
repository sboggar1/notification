package com.sams.clubops.functions;

import static com.sams.clubops.mbr.lookup.utils.ObjectMapperUtil.objectMapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.sams.clubops.functions.impl.RenewUpgrade;
import com.sams.clubops.functions.predicates.PredicateHelper;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfigMap;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;
import java.util.stream.Stream;

public class RenewUpgradeTest {

    @InjectMocks
    private RenewUpgrade renewUpgrade;

    @Mock
    private ItemsConfigMap itemsConfigMap;

    private static final String INFORMATIONAL = "INFORMATIONAL";
    private static final String OPTIONAL = "OPTIONAL";
    private static final String RENEW = "RENEW";
    private static final String OE_SAMS_TESTING = "OE_SAMS_Testing";

    public RenewUpgradeTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void validateItemNumberUpcTransformation() throws JsonProcessingException {
        List<Map<String, Object>> feeData = objectMapper.readValue(getInformationalFeeString(), new TypeReference<List<Map<String, Object>>>() {
        });
        ReflectionTestUtils.setField(renewUpgrade, "clientRenewOperations", new HashMap<String, EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>>() {{
            putIfAbsent(OE_SAMS_TESTING, new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                put(RenewUpgrade.FeeType.INFORMATIONAL, EnumSet.of(RenewUpgrade.Operations.UPGRADE, RenewUpgrade.Operations.TRANSFORM));
            }});
        }});
        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");

        String expectedString = "[\n" +
                "    {\n" +
                "        \"feeType\": \"INFORMATIONAL\",\n" +
                "        \"feeDetails\": [\n" +
                "            {\n" +
                "                \"membershipID\": \"561e572a-0051-496d-a633-7f21681e4b07\",\n" +
                "                \"membershipAccount\": \"10205877973\",\n" +
                "                \"issuanceMethod\": \"UPGRADE\",\n" +
                "                \"subscriptionID\": \"MEMBERSHIP.CLUB.PRIMARY.STANDARD\",\n" +
                "                \"price\": [\n" +
                "                    {\n" +
                "                        \"itemNumber\": \"123\",\n" +
                "                        \"itemShortDescription\": \"UPGRADE PRIMARY\",\n" +
                "                        \"itemLongDescription\": \"Upgragde to PLUS PRIMARY--------------------\",\n" +
                "                        \"itemPrice\": \"52.89\",\n" +
                "                        \"itemTaxAmount\": \"0\"\n" +
                "                    }\n" +
                "                ]\n" +
                "            }\n" +
                "        ]\n" +
                "    }\n" +
                "]";
        List<Map<String, Object>> expected = objectMapper.readValue(expectedString, new TypeReference<List<Map<String, Object>>>() {
        });
        ((List<Map<String, Object>>)((List<Map<String, Object>>)expected.get(0).get("feeDetails")).get(0).get("price")).get(0).putIfAbsent("upc","40630001239");
        Map<String, Object> itemsUpcMap = new HashMap<>();
        itemsUpcMap.put("123","40630001239");
        Mockito.when(itemsConfigMap.getItemUpcMap()).thenReturn(itemsUpcMap);
        Assert.assertEquals(expected, renewUpgrade.transform().apply(customAttributes, feeData));
    }

    @Test
    public void testNotSupportedOperationReturnsTrueForNoMatch() {
        Map<String, Object> feeDetail = Collections.singletonMap("issuanceMethod", "ABSENT");
        Assert.assertTrue(PredicateHelper.notSupportedOperation(EnumSet.noneOf(RenewUpgrade.Operations.class)).test(feeDetail));
    }

    @ParameterizedTest
    @MethodSource("provideFeeData")
    public void ValidateSuccessfulTransformation(String feeDataString, EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>> clientRenewOperations, List<Map<String, Object>> expected) throws JsonProcessingException {
        List<Map<String, Object>> feeData = objectMapper.readValue(feeDataString, new TypeReference<List<Map<String, Object>>>() {
        });
        System.out.println(feeData);
        ReflectionTestUtils.setField(renewUpgrade, "clientRenewOperations", new HashMap<String, EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>>() {{
            putIfAbsent(OE_SAMS_TESTING, clientRenewOperations);
        }});
        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");
        List<Map<String, Object>> renewed = renewUpgrade.transform().apply(customAttributes, feeData);
        System.out.println(renewed);
        parseRenewedData(renewed);
        Assert.assertEquals(expected.size(), renewed.size());
        Assert.assertEquals(expected, renewed);
    }

    @ParameterizedTest
    @MethodSource("provideInvalidFeeData")
    public void returnsSameDataifInvalidParams(Map<String, Object> customAttributes, List<Map<String, Object>> feeData) {
        ReflectionTestUtils.setField(renewUpgrade, "clientRenewOperations", new HashMap<String, EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>>() {{
            putIfAbsent(OE_SAMS_TESTING, new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                put(RenewUpgrade.FeeType.INFORMATIONAL, EnumSet.of(RenewUpgrade.Operations.UPGRADE));
            }});
        }});
        Assert.assertEquals(feeData, renewUpgrade.transform().apply(customAttributes, feeData));
    }

    private void parseRenewedData(List<Map<String, Object>> renewed) {
        renewed.forEach(type -> {
            List<Map<String, Object>> feeDetails = (List<Map<String, Object>>) type.get("feeDetails");
            feeDetails.forEach(feeDetail -> feeDetail.entrySet().removeIf(e -> !"issuanceMethod".equalsIgnoreCase(e.getKey())));
        });
    }

    private static Stream<Arguments> provideFeeData() {
        return Stream.of(
                //match renew
                Arguments.of(getInformationalFeeString(), new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                    put(RenewUpgrade.FeeType.INFORMATIONAL, EnumSet.of(RenewUpgrade.Operations.RENEW));
                }}, Collections.singletonList(new HashMap<String, Object>() {{
                    put("feeType", INFORMATIONAL);
                    put("feeDetails", Collections.singletonList(new HashMap<String, Object>() {{
                        put("issuanceMethod", RENEW);
                    }}));
                }})),
                // No match
                Arguments.of(getInformationalFeeString(), new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                    put(RenewUpgrade.FeeType.REQUIRED, EnumSet.of(RenewUpgrade.Operations.RENEW));
                }}, Collections.emptyList()),
                // No match in fee Details
                Arguments.of(getInformationalFeeString(), new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                    put(RenewUpgrade.FeeType.INFORMATIONAL, EnumSet.of(RenewUpgrade.Operations.RENEW_AND_UPGRADE));
                }}, Collections.emptyList()),
                //match renew only from multiple choices
                Arguments.of(getInfoOptionalFeeString(), new EnumMap<RenewUpgrade.FeeType, EnumSet<RenewUpgrade.Operations>>(RenewUpgrade.FeeType.class) {{
                    put(RenewUpgrade.FeeType.INFORMATIONAL, EnumSet.of(RenewUpgrade.Operations.RENEW));
                    put(RenewUpgrade.FeeType.OPTIONAL, EnumSet.of(RenewUpgrade.Operations.RENEW));
                }}, Arrays.asList(new HashMap<String, Object>() {{
                    put("feeType", OPTIONAL);
                    put("feeDetails", Collections.singletonList(new HashMap<String, Object>() {{
                        put("issuanceMethod", RENEW);
                    }}));
                }}, new HashMap<String, Object>() {{
                    put("feeType", INFORMATIONAL);
                    put("feeDetails", Collections.singletonList(new HashMap<String, Object>() {{
                        put("issuanceMethod", RENEW);
                    }}));
                }}))
        );
    }

    private static Stream<Arguments> provideInvalidFeeData() {
        Map<String, Object> customAttributes = new HashMap<String, Object>() {{
            put("client", OE_SAMS_TESTING);
            put("api", "getMembershipFee");
        }};

        return Stream.of(
                Arguments.of(new HashMap<>(), new ArrayList<>()),
                Arguments.of(new HashMap<String, Object>() {{
                    put("client", "INVALID_CLIENT");
                }}, new ArrayList<>()),
                Arguments.of(new HashMap<String, Object>() {{
                    put("client", OE_SAMS_TESTING);
                    put("api", "Not_Fee");
                }}, new ArrayList<>()),
                Arguments.of(customAttributes, null),
                Arguments.of(customAttributes, new ArrayList<>()),
                Arguments.of(customAttributes, new ArrayList<Map<String, Object>>() {{
                    add(new HashMap<>());
                }}),
                Arguments.of(customAttributes, new ArrayList<Map<String, Object>>() {{
                    add(new HashMap<String, Object>() {{
                        put("feeType", null);
                    }});
                }})
        );
    }

    private static String getInformationalFeeString() {
        return "[\n" +
                "    {\n" +
                "        \"feeType\": \"INFORMATIONAL\",\n" +
                "        \"feeDetails\": [\n" +
                "            {\n" +
                "                \"issuanceMethod\": \"NEW\",\n" +
                "                \"subscriptionID\": \"MEMBERSHIP.CLUB.ADD_ON.STANDARD\",\n" +
                "                \"maxAvailableItemCounts\": 8,\n" +
                "                \"price\": [\n" +
                "                    {\n" +
                "                        \"itemNumber\": \"113\",\n" +
                "                        \"itemShortDescription\": \"NEW ADD_ON\",\n" +
                "                        \"itemLongDescription\": \"NEW ADD ON--------------------\",\n" +
                "                        \"itemPrice\": \"38.47\",\n" +
                "                        \"itemTaxAmount\": \"0\"\n" +
                "                    }\n" +
                "                ]\n" +
                "            },\n" +
                "            {\n" +
                "                \"membershipID\": \"561e572a-0051-496d-a633-7f21681e4b07\",\n" +
                "                \"membershipAccount\": \"10205877973\",\n" +
                "                \"issuanceMethod\": \"UPGRADE\",\n" +
                "                \"subscriptionID\": \"MEMBERSHIP.CLUB.PRIMARY.STANDARD\",\n" +
                "                \"price\": [\n" +
                "                    {\n" +
                "                        \"itemNumber\": \"123\",\n" +
                "                        \"itemShortDescription\": \"UPGRADE PRIMARY\",\n" +
                "                        \"itemLongDescription\": \"Upgragde to PLUS PRIMARY--------------------\",\n" +
                "                        \"itemPrice\": \"52.89\",\n" +
                "                        \"itemTaxAmount\": \"0\"\n" +
                "                    }\n" +
                "                ]\n" +
                "            },\n" +
                "            {\n" +
                "                \"membershipID\": \"561e572a-0051-496d-a633-7f21681e4b07\",\n" +
                "                \"membershipAccount\": \"10205877973\",\n" +
                "                \"issuanceMethod\": \"RENEW\",\n" +
                "                \"subscriptionID\": \"MEMBERSHIP.CLUB.PRIMARY.STANDARD\",\n" +
                "                \"price\": [\n" +
                "                    {\n" +
                "                        \"itemNumber\": \"110\",\n" +
                "                        \"itemShortDescription\": \"RENEW PRIMARY\",\n" +
                "                        \"itemLongDescription\": \"RENEW SAVINGS PRIMARY--------------------\",\n" +
                "                        \"itemPrice\": \"45.00\",\n" +
                "                        \"itemTaxAmount\": \"0\"\n" +
                "                    }\n" +
                "                ]\n" +
                "            }\n" +
                "        ]\n" +
                "    }\n" +
                "]";
    }

    private static String getInfoOptionalFeeString() {
        return "[\n" +
                "    {\n" +
                "  \"feeType\": \"OPTIONAL\",\n" +
                "  \"feeDetails\": [\n" +
                "    {\n" +
                "      \"issuanceMethod\": \"RENEW\",\n" +
                "      \"subscriptionID\": \"MEMBERSHIP.CLUB.PRIMARY.STANDARD\",\n" +
                "      \"price\": [\n" +
                "        {\n" +
                "          \"itemNumber\": \"110\",\n" +
                "          \"itemShortDescription\": \"RENEW PRIMARY\",\n" +
                "          \"itemLongDescription\": \"RENEW SAVINGS PRIMARY--------------------\",\n" +
                "          \"itemPrice\": \"45.00\",\n" +
                "          \"itemTaxAmount\": \"0\"\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  ]\n" +
                "},\n" +
                "{\n" +
                "  \"feeType\": \"INFORMATIONAL\",\n" +
                "  \"feeDetails\": [\n" +
                "    {\n" +
                "      \"issuanceMethod\": \"RENEW\",\n" +
                "      \"subscriptionID\": \"MEMBERSHIP.CLUB.ADD_ON.STANDARD\",\n" +
                "      \"price\": [\n" +
                "        {\n" +
                "          \"itemNumber\": \"110\",\n" +
                "          \"itemShortDescription\": \"RENEW ADD_ON\",\n" +
                "          \"itemLongDescription\": \"RENEW SAVINGS ADD_ON--------------------\",\n" +
                "          \"itemPrice\": \"40.00\",\n" +
                "          \"itemTaxAmount\": \"0\"\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"issuanceMethod\": \"RENEW_AND_UPGRADE\",\n" +
                "      \"subscriptionID\": \"MEMBERSHIP.CLUB.PRIMARY.STANDARD\",\n" +
                "      \"price\": [\n" +
                "        {\n" +
                "          \"itemNumber\": \"122\",\n" +
                "          \"itemShortDescription\": \"UPGRADE PRIMARY\",\n" +
                "          \"itemLongDescription\": \"Upgragde to PLUS PRIMARY--------------------\",\n" +
                "          \"itemPrice\": \"55.00\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"itemNumber\": \"110\",\n" +
                "          \"itemShortDescription\": \"RENEW PRIMARY\",\n" +
                "          \"itemLongDescription\": \"RENEW SAVINGS PRIMARY--------------------\",\n" +
                "          \"itemPrice\": \"45.00\",\n" +
                "          \"itemTaxAmount\": \"0\"\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"issuanceMethod\": \"NEW\",\n" +
                "      \"subscriptionID\": \"MEMBERSHIP.CLUB.ADD_ON.STANDARD\",\n" +
                "      \"maxAvailableItemCounts\": 8,\n" +
                "      \"price\": [\n" +
                "        {\n" +
                "          \"itemNumber\": \"113\",\n" +
                "          \"itemShortDescription\": \"NEW ADD_ON\",\n" +
                "          \"itemLongDescription\": \"NEW ADD ON--------------------\",\n" +
                "          \"itemPrice\": \"6.67\",\n" +
                "          \"itemTaxAmount\": \"0\"\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  ]\n" +
                "}\n" +
                " ]\n" +
                "]";
    }

}
