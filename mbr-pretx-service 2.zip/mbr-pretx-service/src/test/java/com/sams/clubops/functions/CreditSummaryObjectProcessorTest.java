package com.sams.clubops.functions;

import static com.sams.clubops.mbr.lookup.utils.ObjectMapperUtil.objectMapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.sams.clubops.functions.impl.CreditSummaryObjectProcessor;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class CreditSummaryObjectProcessorTest {

    private static final String SUCCESSFUL_DATA = "{\n" + "  \"quickscreenSummary\": {\n" + "    \"ok\": true,\n" + "    \"payload\": {\n" + "      \"preScreenNumber\": \"99000072231\",\n"
        + "      \"quickScreenAppId\": \"815516209257276103\",\n" + "      \"disclosures\": {\n" + "        \"rates\": [\n" + "          {\n" + "            \"type\": \"ACCOUNT_TYPE\",\n"
        + "            \"value\": \"2\",\n" + "            \"description\": \"ACCOUNT TYPE\"\n" + "          },\n" + "          {\n" + "            \"type\": \"PURCHASE_APR\",\n"
        + "            \"value\": \"24.90\",\n" + "            \"description\": \"APR\"\n" + "          },\n" + "          {\n" + "            \"type\": \"PURCHASE_DAILY_RATE_PCT\",\n"
        + "            \"value\": \"0.06822\",\n" + "            \"description\": \"DAILY RATE\"\n" + "          },\n" + "          {\n" + "            \"type\": \"CASH_RATE_PCT\",\n"
        + "            \"value\": \"0.07644\",\n" + "            \"description\": \"CASH RATE\"\n" + "          },\n" + "          {\n" + "            \"type\": \"CASH_APR\",\n"
        + "            \"value\": \"27.90\",\n" + "            \"description\": \"CASH APR\"\n" + "          }\n" + "        ],\n" + "        \"lineOfCredit\": [\n" + "          {\n"
        + "            \"type\": \"TEMP_CREDIT_LINE\",\n" + "            \"amount\": \"2000\",\n" + "            \"currency\": \"USD\",\n" + "            \"description\": \"TEMP_CREDIT_LIMIT\"\n"
        + "          },\n" + "          {\n" + "            \"type\": \"CREDIT_LINE\",\n" + "            \"amount\": \"6000\",\n" + "            \"currency\": \"USD\",\n"
        + "            \"description\": \"CREDIT_LIMIT\"\n" + "          }\n" + "        ]\n" + "      },\n" + "      \"availableUntil\": \"20210812\",\n" + "      \"creditType\": \"CONSUMER\",\n"
        + "      \"productType\": \"MASTERCARD\",\n" + "      \"provider\": \"SYF\",\n" + "      \"quickScreenOfferStatus\": \"APPROVED\"\n" + "    }\n" + "  },\n" + "  \"creditSummary\": {\n"
        + "    \"ok\": true,\n" + "    \"payload\": {\n" + "      \"creditInfo\": {\n" + "        \"creditStatus\": \"1\",\n" + "        \"creditType\": \"4\",\n"
        + "        \"hasConsumerMasterCardCredit\": false,\n" + "        \"hasBusinessMasterCardCredit\": false\n" + "      },\n" + "      \"tempCardInfo\": \"0000\",\n"
        + "      \"quickScreenOfferId\": \"815516209257276103\",\n" + "      \"creditOffer\": {\n" + "        \"preScreenNumber\": \"99000072231\",\n"
        + "        \"quickScreenAppId\": \"815516209257276103\",\n" + "        \"disclosures\": {\n" + "          \"rates\": [\n" + "            {\n" + "              \"type\": \"ACCOUNT_TYPE\",\n"
        + "              \"value\": \"2\",\n" + "              \"description\": \"ACCOUNT TYPE\"\n" + "            },\n" + "            {\n" + "              \"type\": \"PURCHASE_APR\",\n"
        + "              \"value\": \"24.90\",\n" + "              \"description\": \"APR\"\n" + "            },\n" + "            {\n" + "              \"type\": \"PURCHASE_DAILY_RATE_PCT\",\n"
        + "              \"value\": \"0.06822\",\n" + "              \"description\": \"DAILY RATE\"\n" + "            },\n" + "            {\n" + "              \"type\": \"CASH_RATE_PCT\",\n"
        + "              \"value\": \"0.07644\",\n" + "              \"description\": \"CASH RATE\"\n" + "            },\n" + "            {\n" + "              \"type\": \"CASH_APR\",\n"
        + "              \"value\": \"27.90\",\n" + "              \"description\": \"CASH APR\"\n" + "            }\n" + "          ],\n" + "          \"lineOfCredit\": [\n" + "            {\n"
        + "              \"type\": \"TEMP_CREDIT_LINE\",\n" + "              \"amount\": \"2000\",\n" + "              \"currency\": \"USD\",\n"
        + "              \"description\": \"TEMP_CREDIT_LIMIT\"\n" + "            },\n" + "            {\n" + "              \"type\": \"CREDIT_LINE\",\n" + "              \"amount\": \"6000\",\n"
        + "              \"currency\": \"USD\",\n" + "              \"description\": \"CREDIT_LIMIT\"\n" + "            }\n" + "          ]\n" + "        },\n"
        + "        \"availableUntil\": \"20210812\",\n" + "        \"creditType\": \"CONSUMER\",\n" + "        \"productType\": \"MASTERCARD\",\n" + "        \"provider\": \"SYF\"\n" + "      },\n"
        + "      \"showConsumerQuickScreenOffer\": \"AT_TOTAL\",\n" + "      \"promotionalOffers\": [\n" + "        {\n" + "          \"type\": \"ACQUISITION_CREDIT_OFFER\",\n"
        + "          \"amount\": {\n" + "            \"value\": \"45.00\",\n" + "            \"currency\": \"USD\"\n" + "          },\n" + "          \"spendGoal\": {\n"
        + "            \"value\": \"100.00\",\n" + "            \"currency\": \"USD\"\n" + "          },\n" + "          \"expiryDate\": \"2020-10-21\"\n" + "        }\n" + "      ],\n"
        + "      \"canApplyForConsumerCredit\": true,\n" + "      \"hasConsumerMasterCardCredit\": false,\n" + "      \"hasBusinessMasterCardCredit\": false,\n"
        + "      \"captureDriverLicense\": true,\n" + "      \"showKiotcPrompt\": true\n" + "    }\n" + "  }\n" + "}";

    private static final String OE_SAMS_TESTING = "OE_SAMS_Testing";
    private static final String QUICK_SCREEN_SUMMARY = "quickscreenSummary";
    private static final String CREDIT_SUMMARY = "creditSummary";
    private static final String PAYLOAD = "payload";
    private static final String CREDIT_OFFER = "creditOffer";

    @InjectMocks
    private CreditSummaryObjectProcessor creditSummaryObjectProcessor;

    public CreditSummaryObjectProcessorTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void validateSuccessfulObjectWithAllData() throws JsonProcessingException {

        Map<String, Object> data = getAllValuesObj();
        Assert.assertNotNull(data);

        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");
        Map<String, Object> processedData = creditSummaryObjectProcessor.transform().apply(customAttributes, data);
        Assert.assertNotNull(processedData);

        //Since all data is present, input and processed data should match
        Assert.assertEquals(data.get(QUICK_SCREEN_SUMMARY), processedData.get(QUICK_SCREEN_SUMMARY));
        Assert.assertEquals(data.get(CREDIT_SUMMARY), processedData.get(CREDIT_SUMMARY));
    }

    @Test
    public void validatewithNullData() {
        Map<String, Object> data = null;
        Assert.assertNull(data);
        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");
        Map<String, Object> processedData = creditSummaryObjectProcessor.transform().apply(customAttributes, data);
        Assert.assertNull(processedData);
    }

    @Test
    public void validatewithEmptyData() {
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");
        Map<String, Object> processedData = creditSummaryObjectProcessor.transform().apply(customAttributes, data);
        Assert.assertEquals(data, processedData);
    }

    @Test
    public void validateSuccessfulObjectWithMissingCreditOffer() throws JsonProcessingException {

        Map<String, Object> allValuesData = getAllValuesObj();
        Assert.assertNotNull(allValuesData);

        Map<String, Object> missingCreditOfferData = getMissingCreditOfferObj();

        Map<String, Object> customAttributes = new HashMap<>();
        customAttributes.put("client", OE_SAMS_TESTING);
        customAttributes.put("api", "getMembershipFee");
        Map<String, Object> processedData = creditSummaryObjectProcessor.transform().apply(customAttributes, missingCreditOfferData);
        Assert.assertNotNull(processedData);

        //Since Payload processor object fill the missing credit offer data, the processed object should match with all data
        Assert.assertEquals(processedData.get(QUICK_SCREEN_SUMMARY), processedData.get(QUICK_SCREEN_SUMMARY));
        Assert.assertEquals(processedData.get(CREDIT_SUMMARY), processedData.get(CREDIT_SUMMARY));
    }


    private static Map<String, Object> getAllValuesObj() throws JsonProcessingException {
        return objectMapper.readValue(SUCCESSFUL_DATA, new TypeReference<Map<String, Object>>() {});
    }


    private static Map<String, Object> getMissingCreditOfferObj() throws JsonProcessingException {
        Map<String, Object> data =  objectMapper.readValue(SUCCESSFUL_DATA, new TypeReference<Map<String, Object>>() {});
        Map<String, Object> creditSummaryObj = (Map<String, Object>) data.get(CREDIT_SUMMARY);
        Map<String, Object> creditSummaryPayloadObj = (Map<String, Object>) creditSummaryObj.get(PAYLOAD);
        creditSummaryPayloadObj.remove(CREDIT_OFFER);
        creditSummaryObj.put(PAYLOAD, creditSummaryPayloadObj);
        data.put(CREDIT_SUMMARY, creditSummaryObj);
        return data;
    }
}
