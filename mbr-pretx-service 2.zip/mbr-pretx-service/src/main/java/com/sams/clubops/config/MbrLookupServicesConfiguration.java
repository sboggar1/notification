package com.sams.clubops.config;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.sams.clubops.constants.AppConstants;
import com.sams.clubops.mbr.sets.commands.processor.MbrSetsCommandProcessor;
import com.sams.clubops.mbr.sets.definition.provider.MbrSetsDefinitionProvider;
import com.sams.clubops.mbr.sets.service.MbrSetsService;
import com.sams.clubops.mbr.sets.service.MbrSetsServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Configuration
public class MbrLookupServicesConfiguration {

    private ThreadFactoryBuilder tfb = new ThreadFactoryBuilder();
    private static final Logger logger = LoggerFactory.getLogger(MbrLookupServicesConfiguration.class);
    private static final float DEFAULT_CPU_FACTOR = .9f;
    private static final float FACTOR = 64f;
    private static final float N = 1f;//cpu


    /**Common Thread Pool
     * Each Service requires N Threads to be healthy where N is the processors processing requests
     * This is expected to be handled per service in future if a particular client faces starvation or has excessive constant wait times.
     * The configuration works per pod level since horizontal scaling is in place. Hence,Keeping the queue size to modest 100 for each core
     * and initiating all threads in the core pool at startup to support heavy incoming traffic.
     * Be default we should use this executor only unless specific reason to initiate separate executor.
     * @return ThreadPoolExecutor for concurrent processing
     */
    @Bean
    public ThreadPoolExecutor defaultTaskExecutor() {
        int poolSize = (int) (N * DEFAULT_CPU_FACTOR * FACTOR);
        ThreadPoolExecutor executor = new ThreadPoolExecutor(poolSize,
                poolSize,
                60L,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(100),
                tfb.setNameFormat("default-worker-%d").build(),
                (runnable, threadPoolExecutor) -> {
                    try {
                        //fail safe
                        threadPoolExecutor.getQueue().put(runnable);
                    } catch (InterruptedException e) {
                        //this should never be reached
                        logger.error("Exception Occurred: ", e);
                    }
                });
        executor.prestartAllCoreThreads();
        executor.allowCoreThreadTimeOut(true);
        return executor;
    }

    @Bean
    @Autowired
    public MbrSetsService wti(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                              MbrSetsDefinitionProvider mbrLookupDefinitionResolver, @Qualifier("defaultTaskExecutor") ThreadPoolExecutor defaultTaskExecutor) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "US_SAMS_WTI", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor);
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService cppos(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                                MbrSetsDefinitionProvider mbrLookupDefinitionResolver, @Qualifier("defaultTaskExecutor") ThreadPoolExecutor defaultTaskExecutor) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "US_WEBPOS_KIOSK_SAMS", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor);
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService testing(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                                  MbrSetsDefinitionProvider mbrLookupDefinitionResolver, @Qualifier("defaultTaskExecutor") ThreadPoolExecutor defaultTaskExecutor) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "OE_SAMS_Testing", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor);
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService fuel(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                               MbrSetsDefinitionProvider mbrLookupDefinitionResolver) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "US_SAMS_FUEL", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor());
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService membershipKiosk(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                                          MbrSetsDefinitionProvider mbrLookupDefinitionResolver) {
        return new MbrSetsServiceImpl("types",
                "US_SAMS_MEMBERSHIP_KIOSK", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor());
    }

    @Bean
    @Autowired
    public MbrSetsService createMember(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                                       MbrSetsDefinitionProvider mbrLookupDefinitionResolver) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "CREATE_MEMBER", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor());
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService createMultiMember(MbrSetsCommandProcessor mbrLookupCommandProcessor,
                                            MbrSetsDefinitionProvider mbrLookupDefinitionResolver) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                "MULTIPLE_MEMBER", mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor());
        return mbrLookupService;
    }

    @Bean
    @Autowired
    public MbrSetsService rewardSummary(MbrSetsCommandProcessor mbrLookupCommandProcessor,
        MbrSetsDefinitionProvider mbrLookupDefinitionResolver) {
        MbrSetsServiceImpl mbrLookupService = new MbrSetsServiceImpl("types",
                    AppConstants.TYPE_CASH_WALLET_SUMMARY, mbrLookupDefinitionResolver, mbrLookupCommandProcessor, defaultTaskExecutor());
        return mbrLookupService;
    }

}
