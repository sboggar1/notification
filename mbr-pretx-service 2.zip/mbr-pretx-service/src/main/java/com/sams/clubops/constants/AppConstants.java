package com.sams.clubops.constants;

public class AppConstants {

    //Credit Apply related constants
    public static final String CREDIT_SUMMARY = "creditSummary";
    public static final String CREDIT_OFFER = "creditOffer";
    public static final String QUICK_SCREEN_SUMMARY = "quickscreenSummary";
    public static final String PAYLOAD = "payload";
    public static final String QUICK_SCREEN_OFFER_ID = "quickScreenOfferId";

    //Sams Cash related constants
    public static final String TITAN_RESPONSE_TOKEN = "accessToken";

    //Credit Summary Header
    public static final String HEADER_CREDIT_SUMMARY_TOKEN = "sams-consumer-request-token";

    //Reward Summary Headers
    public static final String TYPE_CASH_WALLET_SUMMARY = "CASH_WALLET_SUMMARY";

}
