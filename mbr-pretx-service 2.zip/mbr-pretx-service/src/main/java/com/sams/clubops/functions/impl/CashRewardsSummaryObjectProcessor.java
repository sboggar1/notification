package com.sams.clubops.functions.impl;

import static com.sams.clubops.constants.AppConstants.HEADER_CREDIT_SUMMARY_TOKEN;
import static com.sams.clubops.constants.AppConstants.TITAN_RESPONSE_TOKEN;
import static com.sams.clubops.mbr.sets.constants.AppConstants.CUSTOM_ATTRIBUTES_ADDITIONAL_HEADERS;

import com.sams.clubops.functions.PostProcessorInterface;
import java.util.Map;
import java.util.function.BiFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CashRewardsSummaryObjectProcessor implements PostProcessorInterface<Map<String, Object>, Map<String, Object>> {

    private static final Logger logger = LoggerFactory.getLogger(CashRewardsSummaryObjectProcessor.class);

    @Override
    public BiFunction<Map<String, Object>, Map<String, Object>, Map<String, Object>> transform() {
        return (customAttributes, data) -> {
            try {
                if(customAttributes!=null && customAttributes.containsKey(CUSTOM_ATTRIBUTES_ADDITIONAL_HEADERS)) {
                    Map<String, String> additionalHeaders = (Map<String, String>) customAttributes.get(CUSTOM_ATTRIBUTES_ADDITIONAL_HEADERS);
                    if(additionalHeaders!=null && data!=null) {
                        if(data.containsKey(TITAN_RESPONSE_TOKEN)) {
                            additionalHeaders.put(HEADER_CREDIT_SUMMARY_TOKEN, data.get(TITAN_RESPONSE_TOKEN).toString());
                        }
                    }
                }
            } catch (Exception e) {
                logger.error("CashRewardsSummaryObjectProcessor Failure: ", e);
            }
            return data;
        };
    }

}
