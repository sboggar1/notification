package com.sams.clubops.functions.predicates;

import com.sams.clubops.mbr.lookup.models.MembershipUpdateDTO;
import com.sams.clubops.mbr.lookup.models.RenewalsAndUpgradeStatus;
import com.sams.clubops.mbr.lookup.services.MemberDetailsService;
import com.sams.clubops.mbr.sets.exceptions.CustomFilterException;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

public class MembershipPredicate {

    private static final String GET_MEMBERSHIP = "getMembership";
    private static final String MEMBERSHIP = "membership";
    private static final String MEMBERSHIP_STATUS = "memberStatus";
    private static final String MEMBERSHIP_ROLE = "memberRole";
    private static final String ID = "id";
    private static final Set<String> MEMBERSHIP_VALIDATION_SET = new HashSet<>();
    private static final Logger logger = LoggerFactory.getLogger(MembershipPredicate.class);

    @Autowired
    private MemberDetailsService memberDetailsService;

    static {
        MEMBERSHIP_VALIDATION_SET.add("EXPIRED");
        MEMBERSHIP_VALIDATION_SET.add("DELETED");
    }

    public Predicate<Map<String, Object>> isNotExpiredOrDeletedMembership() {
        return (membershipObj) -> {
            if(!isGetMembership(membershipObj)) {
                throw new CustomFilterException("Illegal Argument passed to PreCondition: isExpiredOrDeletedMembership", membershipObj);
            }
            Map<String, Object> getMemberDetails = (Map<String, Object>) membershipObj.get(GET_MEMBERSHIP);
            Map<String, Object> memberDetails = (Map<String, Object>) getMemberDetails.get(MEMBERSHIP);
            String memberStatus = (String) memberDetails.get(MEMBERSHIP_STATUS);
            String memberRole = (String) memberDetails.get(MEMBERSHIP_ROLE);
            boolean isInActive = MEMBERSHIP_VALIDATION_SET.contains(memberStatus);
            boolean isComplete = true;
            if (isInActive) {
                try {
                    String memberId = (String) getMemberDetails.get(ID);
                    Optional<MembershipUpdateDTO> membershipUpdateDTO = memberDetailsService.findByMembershipId(memberId);
                    Optional<RenewalsAndUpgradeStatus> renewalsAndUpgradeStatus = membershipUpdateDTO.map(MembershipUpdateDTO::getRenewalsAndUpgradeStatus);
                    if (renewalsAndUpgradeStatus.isPresent() && renewalsAndUpgradeStatus.get() != RenewalsAndUpgradeStatus.COMPLETED) {
                        memberDetails.put(MEMBERSHIP_STATUS, renewalsAndUpgradeStatus.get().name());
                        isComplete = false;
                    }
                } catch (Exception e) {
                    logger.info("Exception in Set memberStatus : ", e);
                }
            }
            return !isInActive || !isComplete;
        };
    }

    private static boolean isGetMembership(Map<String, Object> membershipObj) {
        return ObjectUtils.isNotEmpty(membershipObj)
                && ObjectUtils.isNotEmpty(membershipObj.get(GET_MEMBERSHIP))
                && ObjectUtils.isNotEmpty(((Map<String, Object>)membershipObj.get(GET_MEMBERSHIP)).get(MEMBERSHIP))
                && ((Map<String, Object>) membershipObj.get(GET_MEMBERSHIP)).get(MEMBERSHIP) instanceof Map;
    }

}
