package com.sams.clubops.mbr.lookup.repositories;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import com.sams.clubops.mbr.lookup.models.MembershipUpdateDTO;
import com.sams.clubops.time.logger.annotation.Timed;
import com.sams.clubops.time.logger.util.TimerUtil;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MemberDetailsRepository extends CosmosRepository<MembershipUpdateDTO, String> {
    @Timed(app = "MemberDetailsRepository",name = "findByMembershipId",route = "isExpired", logLevel = TimerUtil.LOG_LEVEL.DEBUG)
    Optional<MembershipUpdateDTO> findByMembershipId(String membershipId);
}
