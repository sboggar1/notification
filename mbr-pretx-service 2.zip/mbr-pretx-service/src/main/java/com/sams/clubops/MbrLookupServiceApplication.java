package com.sams.clubops;

import com.sams.clubops.config.CosmosProperties;
import com.sams.clubops.config.vault.CashWalletAuthProperties;
import com.sams.clubops.config.vault.CreditAuthProperties;
import com.sams.clubops.config.vault.MocAuthProperties;
import com.sams.clubops.config.vault.TitanAuthProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.retry.annotation.EnableRetry;

@EnableRetry
@EnableConfigurationProperties({CosmosProperties.class,
    MocAuthProperties.class,
    CreditAuthProperties.class,
    TitanAuthProperties.class,
    CashWalletAuthProperties.class})
@PropertySources({
        @PropertySource("file:${secrets.dir}/sensitive.properties")
})
@SpringBootApplication
@ComponentScan("com.sams.clubops")
public class MbrLookupServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MbrLookupServiceApplication.class, args);
    }

}
