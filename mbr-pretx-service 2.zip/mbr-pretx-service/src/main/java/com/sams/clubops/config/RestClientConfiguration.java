package com.sams.clubops.config;

import com.sams.clubops.mbr.sets.ccm.CommonConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestClientConfiguration {

    private RestTemplate restTemplate;

    private static final int MAX_CONNECTIONS = 150;

    private static final int MAX_ROUTE = 100;

    private static final int TIMEOUT_SECOND = 1000;

    @Autowired
    private CommonConfig commonConfig;

    //@PostConstruct
    public void init() {
        PoolingHttpClientConnectionManager httpPool = new PoolingHttpClientConnectionManager();
        httpPool.setMaxTotal(MAX_CONNECTIONS);
        httpPool.setDefaultMaxPerRoute(MAX_ROUTE);
        CloseableHttpClient httpClient = HttpClients.custom().setConnectionManager(httpPool).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        requestFactory.setReadTimeout(commonConfig.getServiceTimeout() * TIMEOUT_SECOND);
        requestFactory.setConnectTimeout(5 * TIMEOUT_SECOND);
        this.restTemplate = new RestTemplate();
        this.restTemplate.setRequestFactory(requestFactory);
    }

    @Bean
    public ClientHttpRequestFactory httpRequestFactory() {
        return new HttpComponentsClientHttpRequestFactory();
    }

    @Bean
    public RestTemplate restTemplateProvided() {
        if (restTemplate == null) {
            this.init();
        }
        return restTemplate;
    }

}