package com.sams.clubops.mbr.lookup.models;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Component;


@Component
@Container(containerName = "${cosmos.container.member.update}", autoCreateContainer = false)
public class MembershipUpdateDTO {

    @Id
    private String id;
    @PartitionKey
    private String membershipId;
    private String cartId;
    private RenewalsAndUpgradeStatus renewalsAndUpgradeStatus;

    public MembershipUpdateDTO() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMembershipId() {
        return membershipId;
    }

    public void setMembershipId(String membershipId) {
        this.membershipId = membershipId;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public RenewalsAndUpgradeStatus getRenewalsAndUpgradeStatus() {
        return renewalsAndUpgradeStatus;
    }

    public void setRenewalsAndUpgradeStatus(RenewalsAndUpgradeStatus renewalsAndUpgradeStatus) {
        this.renewalsAndUpgradeStatus = renewalsAndUpgradeStatus;
    }

    @Override
    public String toString() {
        return String.format("member id: %s , firstName: %s, RenewalsAndUpgradeStatus: %s", getMembershipId(), getCartId(), getRenewalsAndUpgradeStatus());
    }
}
