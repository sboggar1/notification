package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("buyer")
public class BuyerDetails {

    @JsonProperty("membershipDetails")
    private final BuyerMembershipDetails membershipDetails;

    public BuyerDetails(BuyerMembershipDetails membershipDetails) {
        this.membershipDetails = membershipDetails;
    }

    public BuyerMembershipDetails getMembershipDetails() {
        return membershipDetails;
    }

}
