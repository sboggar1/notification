package com.sams.clubops.mbr.lookup.models;

public enum RenewalsAndUpgradeStatus {
    IN_PROCESS,
    COMPLETED,
    FAILED
}
