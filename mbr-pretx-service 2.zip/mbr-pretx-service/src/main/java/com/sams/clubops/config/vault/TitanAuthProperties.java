package com.sams.clubops.config.vault;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "titan.auth")
public class TitanAuthProperties {

    private String consumerId;
    private String privateKey;
    private String serviceName;
    private String env;
    private String privateKeyVersion;

    public String getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getPrivateKeyVersion() {
        return privateKeyVersion;
    }

    public void setPrivateKeyVersion(String privateKeyVersion) {
        this.privateKeyVersion = privateKeyVersion;
    }
}
