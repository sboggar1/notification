package com.sams.clubops.functions;

import java.util.Map;
import java.util.function.BiFunction;

@FunctionalInterface
public interface PostProcessorInterface<T, R> {

    BiFunction<Map<String, Object>, T, R> transform();
}
