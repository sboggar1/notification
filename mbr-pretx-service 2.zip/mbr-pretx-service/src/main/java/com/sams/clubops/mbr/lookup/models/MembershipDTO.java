package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MembershipDTO {
    @NotNull
    private CreateType type;
    @Valid
    @NotNull
    private MembershipInfo membershipInfo;

    public MembershipDTO() {
    }

    public CreateType getType() {
        return type;
    }

    public void setType(CreateType type) {
        this.type = type;
    }

    public MembershipInfo getMembershipInfo() {
        return membershipInfo;
    }

    public void setMembershipInfo(MembershipInfo membershipInfo) {
        this.membershipInfo = membershipInfo;
    }

}

