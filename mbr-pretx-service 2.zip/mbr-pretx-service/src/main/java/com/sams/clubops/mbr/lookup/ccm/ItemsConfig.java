package com.sams.clubops.mbr.lookup.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration
public interface ItemsConfig {

    @Property(propertyName = "item-upc-map")
    String getItemUpcMapping();
}
