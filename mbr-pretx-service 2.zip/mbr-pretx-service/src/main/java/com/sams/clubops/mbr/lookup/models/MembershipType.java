package com.sams.clubops.mbr.lookup.models;

public enum MembershipType {
    V("SAVINGS"), W("BUSINESS"), X("BUSINESS_TAX_EXEMPT"), G("INVITATION_TO_SHOP") ;

    private String codeValue;

    private MembershipType(String codeValue) {
        this.codeValue = codeValue;
    }

    public String getCodeValue() {
        return codeValue;
    }
}
