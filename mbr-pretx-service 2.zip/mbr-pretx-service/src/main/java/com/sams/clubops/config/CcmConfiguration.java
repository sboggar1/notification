package com.sams.clubops.config;

import com.sams.clubops.config.ccm.CashWalletConfig;
import com.sams.clubops.config.ccm.CreditConfig;
import com.sams.clubops.config.ccm.MemberConfig;
import com.sams.clubops.config.ccm.TitanConfig;
import com.sams.clubops.config.vault.CashWalletAuthProperties;
import com.sams.clubops.config.vault.CreditAuthProperties;
import com.sams.clubops.config.vault.MocAuthProperties;
import com.sams.clubops.mbr.lookup.ccm.HeaderConfigChangeListener;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfig;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfigChangeListener;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfigMap;
import com.sams.clubops.mbr.sets.ccm.CustomOAuthVaultDetails;
import com.sams.clubops.mbr.sets.ccm.HeaderConfig;
import com.sams.clubops.mbr.sets.ccm.HeaderConfigAsMap;
import com.sams.clubops.mbr.sets.ccm.MocVaultDetails;
import com.sams.clubops.mbr.sets.ccm.VaultDetails;
import io.strati.ccm.utils.client.api.ServiceConfigVersionCache;
import io.strati.tunr.utils.client.ServiceConfigClientFactory;
import java.io.IOException;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CcmConfiguration {

    private static ServiceConfigVersionCache serviceConfigVersionCache = ServiceConfigClientFactory.getInstance().getServiceConfigVersionCache();

    @Autowired
    private HeaderConfigChangeListener headerConfigChangeListener;

    @Autowired
    private ItemsConfigChangeListener itemsConfigChangeListener;

    public CcmConfiguration() {
        if (serviceConfigVersionCache == null)
            throw new RuntimeException("Exception setting CCM Server");
    }

    @Bean
    public VaultDetails mocVaultDetails(MocAuthProperties authProperties) {
        return new MocVaultDetails(authProperties.getClientId(), authProperties.getSubsrciptionKey());
    }

    @Bean(name="commonConfig")
    public MemberConfig commonConfig() {
        return serviceConfigVersionCache.getResolvedConfiguration("commonConfig", MemberConfig.class, null);
    }

    @Bean
    public HeaderConfig headerConfig() {
        HeaderConfig headerConfig = serviceConfigVersionCache.getResolvedConfiguration("headerConfig", HeaderConfig.class, null);
        return headerConfig;
    }

    @Bean
    public HeaderConfigAsMap headerConfigAsMap(HeaderConfig headerConfig, VaultDetails mocVaultDetails) throws IOException {
        return new HeaderConfigAsMap(headerConfig, mocVaultDetails);
    }

    @Bean
    public ItemsConfig itemsConfig() {
        return serviceConfigVersionCache.getResolvedConfiguration("itemsConfig", ItemsConfig.class, null);
    }

    @Bean
    public ItemsConfigMap itemsConfigMap(ItemsConfig itemsConfig) {
        return new ItemsConfigMap(itemsConfig);
    }

    @Bean
    public HeaderConfigChangeListener headerConfigChangeListener(HeaderConfigAsMap headerConfigAsMap) {
        return new HeaderConfigChangeListener(headerConfigAsMap);
    }

    @Bean
    public ItemsConfigChangeListener itemsConfigChangeListener(ItemsConfigMap itemsConfigMap) {
        return new ItemsConfigChangeListener(itemsConfigMap);
    }

    @PostConstruct
    private void registerConfigChangeListeners() {
        serviceConfigVersionCache.getServiceConfigVersionObserver()
                .addServiceConfigVersionChangeListner(headerConfigChangeListener);
        serviceConfigVersionCache.getServiceConfigVersionObserver()
                .addServiceConfigVersionChangeListner(itemsConfigChangeListener);
    }

    @Bean
    public CustomOAuthVaultDetails creditVaultDetails(CreditAuthProperties creditAuthProperties) {
        return new CustomOAuthVaultDetails(creditAuthProperties.getClientId(), creditAuthProperties.getSubsrciptionKey());
    }

    @Bean
    public CreditConfig creditConfig() {
        return serviceConfigVersionCache.getResolvedConfiguration("commonConfig", CreditConfig.class, null);
    }

    @Bean
    public TitanConfig titanConfig() {
        return serviceConfigVersionCache.getResolvedConfiguration("commonConfig", TitanConfig.class, null);
    }

    @Bean
    public CashWalletConfig cashWalletConfig() {
        return serviceConfigVersionCache.getResolvedConfiguration("commonConfig", CashWalletConfig.class, null);
    }

}
