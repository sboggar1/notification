package com.sams.clubops.config.vault;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "credit.auth")
public class CreditAuthProperties {

    private String clientId;
    private String clientSecret;
    private String accessTokenUri;
    private String resource;
    private String subsrciptionKey;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getAccessTokenUri() {
        return accessTokenUri;
    }

    public void setAccessTokenUri(String accessTokenUri) {
        this.accessTokenUri = accessTokenUri;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }

    public String getSubsrciptionKey() {
        return subsrciptionKey;
    }

    public void setSubsrciptionKey(String subsrciptionKey) {
        this.subsrciptionKey = subsrciptionKey;
    }
}
