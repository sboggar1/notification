package com.sams.clubops.config;

import com.azure.core.credential.AzureKeyCredential;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.DirectConnectionConfig;
import com.azure.cosmos.GatewayConnectionConfig;
import com.azure.spring.data.cosmos.config.AbstractCosmosConfiguration;
import com.azure.spring.data.cosmos.config.CosmosConfig;
import com.azure.spring.data.cosmos.core.ResponseDiagnostics;
import com.azure.spring.data.cosmos.core.ResponseDiagnosticsProcessor;
import com.azure.spring.data.cosmos.repository.config.EnableCosmosRepositories;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.Nullable;

import java.time.Duration;

@Configuration
@EnableCosmosRepositories(basePackages = "com.sams.clubops.mbr.lookup.repositories")
public class CosmosConfiguration extends AbstractCosmosConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(CosmosConfiguration.class);

    @Autowired
    private CosmosProperties properties;

    private AzureKeyCredential azureKeyCredential;

    @Bean
    public CosmosClientBuilder cosmosClientBuilder() {
        DirectConnectionConfig directConnectionConfig = DirectConnectionConfig.getDefaultConfig();
        directConnectionConfig.setIdleEndpointTimeout(Duration.ofSeconds(60))
                .setIdleConnectionTimeout(Duration.ofSeconds(60))
                .setMaxConnectionsPerEndpoint(100);
        GatewayConnectionConfig gatewayConnectionConfig = new GatewayConnectionConfig();
        gatewayConnectionConfig.setIdleConnectionTimeout(Duration.ofSeconds(60))
                .setMaxConnectionPoolSize(100);
        this.azureKeyCredential = new AzureKeyCredential(properties.getKey());
        CosmosClientBuilder cosmosClientBuilder = new CosmosClientBuilder()
                .endpoint(properties.getUri())
                .credential(this.azureKeyCredential);
        if ((properties.getConnectMode().equalsIgnoreCase("DIRECT")))
            cosmosClientBuilder.directMode(directConnectionConfig);
        else
            cosmosClientBuilder.gatewayMode(gatewayConnectionConfig);
        return cosmosClientBuilder;
    }

    @Bean
    public CosmosConfig cosmosConfig() {
        return CosmosConfig.builder()
                .responseDiagnosticsProcessor(new ResponseDiagnosticsProcessorImplementation())
                .enableQueryMetrics(properties.isQueryMetricsEnabled())
                .build();
    }

    @Override
    protected String getDatabaseName() {
        return properties.getDatabase();
    }

    public void switchToSecondaryKey() {
        this.azureKeyCredential.update(properties.getSecondaryKey());
    }

    private static class ResponseDiagnosticsProcessorImplementation implements ResponseDiagnosticsProcessor {

        @Override
        public void processResponseDiagnostics(@Nullable ResponseDiagnostics responseDiagnostics) {
            if (logger.isDebugEnabled()) {
                logger.info("Response Diagnostics {}", responseDiagnostics);
            }
        }
    }
}
