package com.sams.clubops.mbr.lookup.spring.api;

import com.sams.clubops.constants.AppConstants;
import com.sams.clubops.mbr.lookup.models.CreateType;
import com.sams.clubops.mbr.lookup.models.MembershipDTO;
import com.sams.clubops.mbr.sets.domain.request.MbrSetsRequest;
import com.sams.clubops.mbr.sets.domain.request.MbrSetsResponse;
import com.sams.clubops.mbr.sets.domain.request.MbrSetsResponse.MbrSetsResponseStatus;
import com.sams.clubops.mbr.sets.service.MbrSetsService;
import com.sams.clubops.mbr.sets.spring.proxy.constants.MbrSetsConstant;
import com.sams.clubops.time.logger.annotation.HttpLogging;
import com.sams.clubops.time.logger.annotation.Timed;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.Instant;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.sams.clubops.mbr.lookup.utils.ObjectMapperUtil.ObjectToString;
import static org.apache.commons.lang3.ObjectUtils.isEmpty;

@RestController
@RequestMapping(value = "/member")
public class MbrLookupServiceController {
    private static final Logger log = LoggerFactory.getLogger(MbrLookupServiceController.class);
    private Map<String, MbrSetsService> services = new HashMap<>();


    @Autowired
    public MbrLookupServiceController(List<MbrSetsService> serviceList) {
        serviceList.stream().filter(Objects::nonNull).forEach(mbrLookupService -> this.services.put(mbrLookupService.getQualifiedName(), mbrLookupService));
    }

    //membershipID should be 11-17 characters in length
    private static final Pattern VERSION_PATTTERN = Pattern.compile("^/member/(v[\\d])/membership/([\\d]{9}|[\\d]{11}|[\\d]{17})$");

    @GetMapping(value = {"/membership/{memberId}", "/v1/membership/{memberId}"})
    public ResponseEntity<MbrSetsResponse> getMemberInfo(@PathVariable String memberId, @RequestHeader Map<String, String> headers, @PathVariable Map<String, String> pathVariables) {
        MbrSetsResponse mbrLookupResponse;
        ResponseEntity<MbrSetsResponse> serverResponse;
        long startTime = Instant.now().toEpochMilli();
        if (headers == null || !validateBasicHeaderInfo(headers) || StringUtils.isBlank(headers.get(MbrSetsConstant.APP_NAME)) || !services.containsKey(MbrSetsConstant.SITE + "/" + headers.get(MbrSetsConstant.APP_NAME))) {
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, String.format("Following Headers are mandatory %s", MbrSetsConstant.APP_HEADERS), true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        }
        try {
            log.info("GetMemberInfo for memberId:" + memberId +
                    "headers: " + headers);

            String channel = headers.get(MbrSetsConstant.APP_NAME);
            MbrSetsRequest mbrLookupRequest = buildMbrLookupRequest(pathVariables, headers);
            MbrSetsService mbrLookupService = services.get(MbrSetsConstant.SITE + "/" + channel);
            mbrLookupResponse = mbrLookupService.process(mbrLookupRequest);
            serverResponse = ResponseEntity.ok(mbrLookupResponse);
        } catch (Exception e) {
            log.error("Something went wrong ", e);
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong", false);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(mbrLookupResponse);
        } finally {
            long time = startTime - Instant.now().toEpochMilli();
            log.info("Total Time" + time);
        }
        return serverResponse;
    }

    @Timed(app = "MemberCheckout", name = "getMemberInfoV2")
    @HttpLogging(logHeader = MbrSetsConstant.APP_NAME)
    @GetMapping(value = "/v2/membership/{memberId}")
    public ResponseEntity<MbrSetsResponse> getMemberInfoV2(@PathVariable String memberId, @RequestHeader Map<String, String> headers, @PathVariable Map<String, String> pathVariables, HttpServletRequest httpServletRequest) {
        MbrSetsResponse mbrLookupResponse;
        ResponseEntity<MbrSetsResponse> serverResponse;
        String uriString = (String) httpServletRequest.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        Matcher matcher = VERSION_PATTTERN.matcher(uriString);
        if (headers == null || !validateBasicHeaderInfo(headers) || StringUtils.isBlank(headers.get(MbrSetsConstant.APP_NAME)) || !services.containsKey(MbrSetsConstant.SITE + "/" + headers.get(MbrSetsConstant.APP_NAME))) {
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, String.format("Following Headers are mandatory %s", MbrSetsConstant.APP_HEADERS), true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        } else if (!matcher.matches()) {
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, "Invalid Membership Number. Membership Number should be 9 , 11 or 17 digits.", true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        }
        log.info("GetMemberInfo for memberId:" + memberId +
                "headers: " + headers);

        String channel = headers.get(MbrSetsConstant.APP_NAME);
        MbrSetsRequest mbrLookupRequest = buildMbrLookupRequest(pathVariables, headers);
        mbrLookupRequest.setVersion(matcher.group(1));
        MbrSetsService mbrLookupService = services.get(MbrSetsConstant.SITE + "/" + channel);
        mbrLookupResponse = mbrLookupService.process(mbrLookupRequest);
        serverResponse = ResponseEntity.ok(mbrLookupResponse);
        return serverResponse;
    }

    @Timed(app = "MemberCheckout", name = "getMemberInfoMixApi")
    @HttpLogging(logHeader = MbrSetsConstant.APP_NAME)
    @PostMapping(value = "/v2/membership/{memberId}", consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<MbrSetsResponse> getMemberInfoMixApi(@PathVariable String memberId, @RequestBody Map<String, Object> body, @RequestHeader Map<String, String> headers, @PathVariable Map<String, String> pathVariables, HttpServletRequest httpServletRequest) {
        MbrSetsResponse mbrLookupResponse;
        ResponseEntity<MbrSetsResponse> serverResponse;
        String uriString = (String) httpServletRequest.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        Matcher matcher = VERSION_PATTTERN.matcher(uriString);
        if (headers == null || !validateBasicHeaderInfo(headers) || StringUtils.isBlank(headers.get(MbrSetsConstant.APP_NAME)) || !services.containsKey(MbrSetsConstant.SITE + "/" + headers.get(MbrSetsConstant.APP_NAME))) {
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, String.format("Following Headers are mandatory %s", MbrSetsConstant.APP_HEADERS), true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        } else if (!matcher.matches()) {
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, "Invalid Membership Number. Membership Number should be 9 , 11 or 17 digits.", true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        }
        log.info("GetMemberInfo for memberId:" + memberId +
                "headers: " + headers);
        String channel = headers.get(MbrSetsConstant.APP_NAME);
        MbrSetsRequest mbrLookupRequest = buildMbrLookupRequest(pathVariables, headers, body);
        mbrLookupRequest.setVersion(matcher.group(1));
        MbrSetsService mbrLookupService = services.get(MbrSetsConstant.SITE + "/" + channel);
        mbrLookupResponse = mbrLookupService.process(mbrLookupRequest);
        serverResponse = ResponseEntity.ok(mbrLookupResponse);
        return serverResponse;
    }

    @Timed(app = "MemberCheckout", name = "createMembership")
    @PostMapping(value = "/v2/membership", consumes = "application/json", produces = "application/json")
    public ResponseEntity<MbrSetsResponse> createMembership(@Valid @RequestBody MembershipDTO membershipDTO, @RequestHeader Map<String, String> headers) {
        String type;
        Object createMembershipObj;
        Map<String, Object> body = new HashMap<>();
        MbrSetsResponse mbrLookupResponse;
        ResponseEntity<MbrSetsResponse> serverResponse;
        log.info("Create Membership: " +
                "headers: " + headers);
        if (membershipDTO.getType() == CreateType.SINGLE) {
            type = "CREATE_MEMBER";
            createMembershipObj = membershipDTO.getMembershipInfo().getDetails();
        } else {
            type = "MULTIPLE_MEMBER";
            membershipDTO.getMembershipInfo().setDetails(null);
            createMembershipObj = (isEmpty(membershipDTO.getMembershipInfo().getPrimaryMembership())) ? null : membershipDTO.getMembershipInfo();
        }

        if (!containsHeaders(headers) || isEmpty(createMembershipObj) || !services.containsKey(MbrSetsConstant.SITE + "/" + type)) {
            String reason = !containsHeaders(headers) ? "Inappropriate headers. Requires GEO_ID,BUSINESS_ID,CHANNEL_ID" : membershipDTO.getType() == CreateType.SINGLE ? "details required for Type Single" : "PrimaryMembership required by Type Multiple";
            mbrLookupResponse = buildMbrLookupResponse(HttpStatus.BAD_REQUEST, String.format("Payload Mismatch: %s", reason), true);
            return ResponseEntity.badRequest().body(mbrLookupResponse);
        }

        body.put("createMembership", createMembershipObj);
        MbrSetsRequest mbrLookupRequest = buildMbrLookupRequest(Collections.emptyMap(), headers, body);
        mbrLookupRequest.setVersion("v2");
        MbrSetsService mbrLookupService = services.get(MbrSetsConstant.SITE + "/" + type);
        mbrLookupResponse = mbrLookupService.process(mbrLookupRequest);
        serverResponse = ResponseEntity.ok(mbrLookupResponse);
        return serverResponse;
    }

    @Timed(app = "MemberCheckout", name = "summary")
    @PostMapping(value = "/wallet/summary", consumes = "application/json", produces = "application/json")
    public ResponseEntity<MbrSetsResponse> walletSummary(@RequestBody Map<String, Object> body, @RequestHeader Map<String, String> headers, HttpServletRequest httpServletRequest) {
        MbrSetsService mbrDuringService = services.get(MbrSetsConstant.SITE + "/" + AppConstants.TYPE_CASH_WALLET_SUMMARY);
        log.info("Received Reward Summary Request. Body: "+ ObjectToString(body) +", Headers: "+ObjectToString(headers));
        if (!containsHeaders(headers)) {
            return ResponseEntity.badRequest().body(buildMbrLookupResponse(HttpStatus.BAD_REQUEST, "Missing Headers: Inappropriate headers. Requires GEO_ID,BUSINESS_ID,CHANNEL_ID", true));
        } else if(!services.containsKey(MbrSetsConstant.SITE + "/" + AppConstants.TYPE_CASH_WALLET_SUMMARY)) {
            return ResponseEntity.badRequest().body(buildMbrLookupResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Invalid Reward Summary configuration.", true));
        }
        MbrSetsRequest mbrLookupRequest = buildMbrLookupRequest(Collections.emptyMap(), headers, body);
        MbrSetsService mbrLookupService = services.get(MbrSetsConstant.SITE + "/" + AppConstants.TYPE_CASH_WALLET_SUMMARY);
        return ResponseEntity.ok(mbrLookupService.process(mbrLookupRequest));
    }

    private boolean validateBasicHeaderInfo(Map<String, String> headers) {
        Set<String> keys = headers.keySet();
        return keys.containsAll(MbrSetsConstant.APP_HEADERS);
    }

    private boolean containsHeaders(Map<String, String> headers) {
        Set<String> keys = headers.keySet();
        return keys.containsAll(Arrays.asList("geo_id", "business_id", "channel_id"));
    }

    private MbrSetsRequest buildMbrLookupRequest(Map<String, String> pathVar, Map<String, String> headers) {
        MbrSetsRequest mbrLookupRequest = new MbrSetsRequest();
        mbrLookupRequest.setPathVariables(pathVar);
        mbrLookupRequest.setHeaders(headers);
        return mbrLookupRequest;
    }


    private MbrSetsRequest buildMbrLookupRequest(Map<String, String> pathVar, Map<String, String> headers, Map<String, Object> payload) {
        MbrSetsRequest mbrLookupRequest = new MbrSetsRequest();
        mbrLookupRequest.setPathVariables(pathVar);
        mbrLookupRequest.setHeaders(headers);
        mbrLookupRequest.setPayload(payload);
        return mbrLookupRequest;
    }

    public static MbrSetsResponse buildMbrLookupResponse(HttpStatus httpStatus, String message, boolean validation) {
        MbrSetsResponse mbrLookupResponse = new MbrSetsResponse();
        List<String> messages = new ArrayList<>();
        messages.add(message);
        switch (httpStatus) {
            case BAD_REQUEST:
            case METHOD_NOT_ALLOWED:
            case UNSUPPORTED_MEDIA_TYPE: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.BAD_REQUEST);
                break;
            }
            case OK: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.SUCCESS);
                break;
            }
            case CONFLICT: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.CONFLICT);
                break;
            }
            case FORBIDDEN: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.FORBIDDEN);
                break;
            }
            case NOT_FOUND: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.NOT_FOUND);
                break;
            }
            default: {
                mbrLookupResponse.setStatus(MbrSetsResponseStatus.INTERNAL_SERVER_ERROR);
                break;
            }
        }
        if ((validation)) {
            mbrLookupResponse.setValidationErrors(messages);
        } else {
            mbrLookupResponse.setMessages(messages);
        }
        return mbrLookupResponse;
    }

}
