package com.sams.clubops.functions.impl;

import static com.sams.clubops.constants.AppConstants.CREDIT_OFFER;
import static com.sams.clubops.constants.AppConstants.CREDIT_SUMMARY;
import static com.sams.clubops.constants.AppConstants.PAYLOAD;
import static com.sams.clubops.constants.AppConstants.QUICK_SCREEN_SUMMARY;

import com.sams.clubops.functions.PostProcessorInterface;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreditSummaryObjectProcessor implements PostProcessorInterface<Map<String, Object>, Map<String, Object>> {

    private static final Logger logger = LoggerFactory.getLogger(CreditSummaryObjectProcessor.class);

    /**
     *
     * If CreditOffer Object is missing in Credit summary, then populate the CreditOffer section
     *
     * @return
     */

    @Override
    public BiFunction<Map<String, Object>, Map<String, Object>, Map<String, Object>> transform() {
        return (customAttributes, data) -> {
            try {
                if (!Objects.isNull(data)) {

                    Map<String, Object> quickScreenSummaryObj = (Map<String, Object>) data.get(QUICK_SCREEN_SUMMARY);
                    if (MapUtils.isNotEmpty(quickScreenSummaryObj)) {
                        Map<String, Object> creditSummaryObj = (Map<String, Object>) data.get(CREDIT_SUMMARY);

                        Map<String, Object> creditSummaryPayloadObj = (Map<String, Object>) creditSummaryObj.get(PAYLOAD);
                        Map<String, Object> quickScreenPayloadObj = (Map<String, Object>) quickScreenSummaryObj.get(PAYLOAD);

                        creditSummaryPayloadObj.putIfAbsent(CREDIT_OFFER, quickScreenPayloadObj);
                        creditSummaryObj.put(PAYLOAD, creditSummaryPayloadObj);
                        data.put(CREDIT_SUMMARY, creditSummaryObj);
                    }
                }
            } catch (Exception e) {
                logger.error("CreditSummaryObjectProcessor Failure: ", e);
            }
            return data;
        };
    }

}
