package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.validation.Valid;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MembershipInfo {

    @Valid
    MembershipDetails details;
    @Valid
    MembershipDetails primaryMembership;
    @Valid
    MembershipDetails complimentaryMembership;
    @Valid
    List<AddOnMembershipDetails> addOnMemberships;

    public MembershipInfo() {
    }

    public MembershipDetails getPrimaryMembership() {
        return primaryMembership;
    }

    public void setPrimaryMembership(MembershipDetails primaryMembership) {
        this.primaryMembership = primaryMembership;
    }

    public MembershipDetails getComplimentaryMembership() {
        return complimentaryMembership;
    }

    public void setComplimentaryMembership(MembershipDetails complementaryMembership) {
        this.complimentaryMembership = complementaryMembership;
    }

    public MembershipDetails getDetails() {
        return details;
    }

    public void setDetails(MembershipDetails details) {
        this.details = details;
    }

    public List<AddOnMembershipDetails> getAddOnMemberships() {
        return addOnMemberships;
    }

    public void setAddOnMemberships(List<AddOnMembershipDetails> addOnMemberships) {
        this.addOnMemberships = addOnMemberships;
    }

}
