package com.sams.clubops.config;

import com.sams.clubops.mbr.sets.definition.provider.ClasspathMbrSetsDefinitionProvider;
import com.sams.clubops.mbr.sets.definition.provider.MbrSetsDefinitionProvider;
import com.sams.clubops.mbr.sets.definition.provider.impl.MbrSetsDefinitionResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executor;

@Configuration
public class MbrLookupDefinitionConfiguration {

    /**
     * Classpath Definition Provider, that can resolve URIs against classpath resources
     *
     * @return
     */
    @Bean
    @Autowired
    public MbrSetsDefinitionProvider classPathDefinitionProvider(Executor taskExecutor) {
        ClasspathMbrSetsDefinitionProvider classpathMbrLookupDefinitionProvider = new ClasspathMbrSetsDefinitionProvider(taskExecutor);
        return classpathMbrLookupDefinitionProvider;
    }

    /**
     * Create a resolver that aggregates all the definition providers and try to resolve a type definition
     *
     * @param classPathDefinitionProvider
     *
     * @return
     */
    @Bean
    @Autowired
    public MbrSetsDefinitionProvider mbrLookupDefinitionResolver(MbrSetsDefinitionProvider classPathDefinitionProvider) {
        MbrSetsDefinitionResolver mbrLookupDefinitionResolver = new MbrSetsDefinitionResolver();
        mbrLookupDefinitionResolver.add(classPathDefinitionProvider);
        return mbrLookupDefinitionResolver;
    }
}
