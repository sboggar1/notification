package com.sams.clubops.functions.predicates;

import static com.sams.clubops.constants.AppConstants.CREDIT_OFFER;
import static com.sams.clubops.constants.AppConstants.CREDIT_SUMMARY;
import static com.sams.clubops.constants.AppConstants.PAYLOAD;
import static com.sams.clubops.constants.AppConstants.QUICK_SCREEN_OFFER_ID;

import com.sams.clubops.mbr.lookup.services.MemberDetailsService;
import java.util.Map;
import java.util.function.Predicate;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class CreditSummaryPredicate {

    private static final Logger logger = LoggerFactory.getLogger(CreditSummaryPredicate.class);

    @Autowired
    private MemberDetailsService memberDetailsService;

    public Predicate<Map<String, Object>> isNotCreditOfferAvailable() {
        return (creditSummaryObj) -> {
            Map<String, Object> creditSummary = (Map<String, Object>) creditSummaryObj.get(CREDIT_SUMMARY);
            if(MapUtils.isNotEmpty(creditSummary)) {
                Map<String, Object> creditSummaryPayload = (Map<String, Object>) creditSummary.get(PAYLOAD);

                Map<String, Object> creditOffer = (Map<String, Object>) creditSummaryPayload.get(CREDIT_OFFER);
                String quickScreenId = (String) creditSummaryPayload.get(QUICK_SCREEN_OFFER_ID);

                if (quickScreenId != null && creditOffer == null) {
                    logger.info("Credit summary is missing the credit offer details");
                    return false;
                }
            }
            return true;
        };
    }

}
