package com.sams.clubops.config.ccm;

import com.sams.clubops.mbr.sets.ccm.CommonConfig;
import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration
public interface MemberConfig extends CommonConfig {
    @Property(
        propertyName = "membership.host"
    )
    String getHost();

    @Property(
        propertyName = "membership.base.path"
    )
    String getBasePath();

    @Property(
        propertyName = "membership.base.path.compute"
    )
    String getBaseComputePath();
}

