package com.sams.clubops.mbr.lookup.ccm;

import io.strati.ccm.utils.client.api.ServiceConfigVersionChangeEvent;
import io.strati.ccm.utils.client.api.ServiceConfigVersionChangeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ItemsConfigChangeListener implements ServiceConfigVersionChangeListener {

    private ItemsConfigMap itemsConfigMap;
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemsConfigChangeListener.class);

    public ItemsConfigChangeListener(ItemsConfigMap itemsConfigMap) {
        this.itemsConfigMap = itemsConfigMap;
    }

    @Override
    public void serviceConfigVersionUpdated(ServiceConfigVersionChangeEvent event) {
        LOGGER.info("ItemsConfigChangeListener received a change");
        itemsConfigMap.reload();//reload map on a change
    }
}
