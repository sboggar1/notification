package com.sams.clubops.mbr.lookup.ccm;

import static com.sams.clubops.mbr.lookup.utils.ObjectMapperUtil.objectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class ItemsConfigMap {

    private ItemsConfig itemsConfig;
    private Map<String, Object> itemUpcMap;
    private final Logger log = LoggerFactory.getLogger(ItemsConfigMap.class);

    public ItemsConfigMap(ItemsConfig itemsConfig) {
        this.itemsConfig = itemsConfig;
        init();
    }

    private void init() {
        try {
            this.itemUpcMap = objectMapper.readValue(itemsConfig.getItemUpcMapping(), Map.class);
        } catch (Exception e) {
            log.error("Error loading CCM Items Config: " + itemsConfig, e);
        }
    }

    public void reload() {
        init();
    }

    public Map<String, Object> getItemUpcMap() {
        return itemUpcMap;
    }
}
