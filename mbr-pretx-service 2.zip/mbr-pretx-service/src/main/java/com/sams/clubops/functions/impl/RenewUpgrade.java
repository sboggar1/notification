package com.sams.clubops.functions.impl;

import com.sams.clubops.functions.PostProcessorInterface;
import com.sams.clubops.functions.predicates.PredicateHelper;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfigMap;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RenewUpgrade implements PostProcessorInterface<List<Map<String, Object>>, List<Map<String, Object>>> {

    private static final Logger log = LoggerFactory.getLogger(RenewUpgrade.class);

    private final Map<String, EnumMap<FeeType, EnumSet<Operations>>> clientRenewOperations = new HashMap<>();

    private static final String API_ATTRIBUTE = "api";
    private static final String CLIENT_ATTRIBUTE = "client";

    private ItemsConfigMap itemsConfigMap;

    public RenewUpgrade(ItemsConfigMap itemsConfigMap) {
        this.itemsConfigMap = itemsConfigMap;
        //client name should match type property of definition json
        clientRenewOperations.putIfAbsent("OE_SAMS_Testing", new EnumMap<FeeType, EnumSet<Operations>>(FeeType.class) {{
            put(FeeType.OPTIONAL, EnumSet.of(Operations.RENEW, Operations.TRANSFORM));
        }});
        clientRenewOperations.putIfAbsent("US_WEBPOS_KIOSK_SAMS", new EnumMap<FeeType, EnumSet<Operations>>(FeeType.class) {{
            put(FeeType.INFORMATIONAL, EnumSet.of(Operations.RENEW,Operations.UPGRADE, Operations.RENEW_AND_UPGRADE, Operations.TRANSFORM));
            put(FeeType.OPTIONAL, EnumSet.of(Operations.RENEW,Operations.TRANSFORM));
            put(FeeType.REQUIRED, EnumSet.of(Operations.RENEW,Operations.TRANSFORM));
        }});
        clientRenewOperations.putIfAbsent("US_SAMS_FUEL", new EnumMap<FeeType, EnumSet<Operations>>(FeeType.class) {{
            put(FeeType.OPTIONAL, EnumSet.of(Operations.RENEW, Operations.TRANSFORM));
            put(FeeType.REQUIRED, EnumSet.of(Operations.RENEW, Operations.TRANSFORM));
        }});
        clientRenewOperations.putIfAbsent("US_SAMS_MEMBERSHIP_KIOSK", new EnumMap<FeeType, EnumSet<Operations>>(FeeType.class) {{
            put(FeeType.REQUIRED, EnumSet.of(Operations.NEW, Operations.TRANSFORM));
        }});
    }

    public enum FeeType {
        INFORMATIONAL, OPTIONAL, REQUIRED
    }

    public enum Operations {
        RENEW, UPGRADE, RENEW_AND_UPGRADE, NEW, TRANSFORM, NONE
    }

    /**
     * transform membershipFee
     * @return updated fee object
     */
    @Override
    public BiFunction<Map<String, Object>, List<Map<String, Object>>, List<Map<String, Object>>> transform() {
        return (customAttributes, membershipFee) -> {
            String api = (String) customAttributes.get(API_ATTRIBUTE);
            String client = (String) customAttributes.get(CLIENT_ATTRIBUTE);
            if (StringUtils.isEmpty(client) || clientRenewOperations.get(client) == null || StringUtils.isEmpty(api) || !isFeeData(api, membershipFee))
                return membershipFee;
            EnumMap<FeeType, EnumSet<Operations>> filters = clientRenewOperations.get(client);
            //remove all unwanted fee objects
            membershipFee.removeIf(feeTypeMap -> !filters.containsKey(FeeType.valueOf((String) feeTypeMap.get("feeType"))));

            return membershipFee.stream().map(feeTypeMap -> {
                String feeType = (String) feeTypeMap.get("feeType");
                List<Map<String, Object>> feeDetails = getFeeDetails(feeTypeMap);
                if (!feeDetails.isEmpty()) {
                    EnumSet<Operations> feeOperationsEnumSet = feeDetailList(filters, feeType);
                    feeDetails.removeIf(PredicateHelper.notSupportedOperation(feeOperationsEnumSet));
                    // transform item number to upc
                    if (feeOperationsEnumSet.contains(Operations.TRANSFORM)) {
                        transformItemNumberToUPC(feeDetails);
                    }
                }
                return (feeDetails.isEmpty()) ? Collections.<String, Object>emptyMap() : feeTypeMap;
            }).filter(map -> !map.isEmpty()).collect(Collectors.toList());
        };
    }

    /**
     * Validate first object in data is of type Fee
     *
     * @param membershipFee membershipFee Input
     * @return boolean is fee type
     */
    private boolean isFeeData(String api, List<Map<String, Object>> membershipFee) {
        return api.equalsIgnoreCase("getMembershipFee") && ObjectUtils.isNotEmpty(membershipFee) && ObjectUtils.isNotEmpty(membershipFee.get(0)) && membershipFee.get(0).get("feeType") != null;
    }

    private EnumSet<Operations> feeDetailList(EnumMap<FeeType, EnumSet<Operations>> filters, String feeType) {
        EnumSet<Operations> operationsEnumSet;
        try {
            operationsEnumSet = filters.get(FeeType.valueOf(feeType));
        } catch (IllegalArgumentException e) {
            log.error("Fee Type mismatch to EnumSet", e);
            operationsEnumSet = EnumSet.noneOf(Operations.class);
        }
        return operationsEnumSet;
    }

    private List<Map<String, Object>> getFeeDetails(Map<String, Object> objectMap) {
        return (ObjectUtils.isNotEmpty(objectMap) && objectMap.get("feeDetails") != null) ? (List<Map<String, Object>>) objectMap.get("feeDetails") : Collections.emptyList();
    }

    private void transformItemNumberToUPC(List<Map<String, Object>> feeDetails) {
        if (ObjectUtils.isNotEmpty(itemsConfigMap.getItemUpcMap())) {
            feeDetails.forEach(feeMap -> {
                List<Map<String, Object>> priceList = (List<Map<String, Object>>) feeMap.get("price");
                priceList = priceList.stream().peek(priceMap -> {
                    priceMap.putIfAbsent("upc", itemsConfigMap.getItemUpcMap().get(priceMap.get("itemNumber")));
                }).collect(Collectors.toList());
            });
        }
    }

}
