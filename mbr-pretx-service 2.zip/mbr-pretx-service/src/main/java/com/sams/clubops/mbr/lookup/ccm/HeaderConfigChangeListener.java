package com.sams.clubops.mbr.lookup.ccm;

import com.sams.clubops.mbr.sets.ccm.HeaderConfigAsMap;
import io.strati.ccm.utils.client.api.ServiceConfigVersionChangeEvent;
import io.strati.ccm.utils.client.api.ServiceConfigVersionChangeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeaderConfigChangeListener implements ServiceConfigVersionChangeListener {

    private HeaderConfigAsMap headerConfigAsMap;
    private static final Logger LOGGER = LoggerFactory.getLogger(HeaderConfigChangeListener.class);

    public HeaderConfigChangeListener(HeaderConfigAsMap headerConfigAsMap) {
        this.headerConfigAsMap = headerConfigAsMap;
    }

    @Override
    public void serviceConfigVersionUpdated(ServiceConfigVersionChangeEvent event) {
        LOGGER.info("HeaderConfigChangeListener received a change");
        headerConfigAsMap.reload();//reload map on a change
    }
}
