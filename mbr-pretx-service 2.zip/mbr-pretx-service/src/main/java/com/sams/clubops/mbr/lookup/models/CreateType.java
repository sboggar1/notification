package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum CreateType {
    SINGLE, MULTIPLE;

    @JsonCreator
    public static CreateType from(String value) {
        if (value == null) {
            throw new IllegalArgumentException();
        }
        try {
            return CreateType.valueOf(value.toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("type not supported. Type should be either single/multiple");
        }

    }
}
