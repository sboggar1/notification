package com.sams.clubops.config.ccm;

import com.sams.clubops.mbr.sets.ccm.CommonConfig;
import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration
public interface CreditConfig extends CommonConfig {
    @Property(
        propertyName = "credit.host"
    )
    String getHost();

    @Property(
        propertyName = "credit.base.path"
    )
    String getBasePath();

    @Property(
        propertyName = "credit.base.path.compute"
    )
    String getBaseComputePath();
}

