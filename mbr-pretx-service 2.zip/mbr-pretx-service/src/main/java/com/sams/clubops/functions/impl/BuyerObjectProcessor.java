package com.sams.clubops.functions.impl;

import static com.sams.clubops.mbr.lookup.utils.ObjectMapperUtil.objectMapper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sams.clubops.functions.PostProcessorInterface;
import com.sams.clubops.mbr.lookup.models.BuyerDetails;
import com.sams.clubops.mbr.lookup.models.BuyerMembershipDetails;
import com.sams.clubops.mbr.lookup.models.MembershipType;
import com.sams.clubops.mbr.sets.exceptions.CustomFilterException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

public class BuyerObjectProcessor implements PostProcessorInterface<Map<String, Object>, Map<String, Object>> {

    public static final String GET_MEMBERSHIP = "getMembership";
    public static final String MEMBERSHIP = "membership";
    public static final String PRINTED_MEMBERSHIP = "printedMembershipCard";
    public static final String ID = "id";
    public static final String TAX_EXEMPT = "isTaxExempt";
    public static final String TAX_EXEMPT_STATUS = "allowTaxExemptPurchase";
    public static final String MEMBERSHIP_TYPE = "membershipTier";
    public static final String ORGANIZATION ="organization";
    public static final String MEMBERSHIP_STATUS = "memberStatus";
    public static final String CARD_TYPE = "cardType";
    public static final String END_DATE = "endDate";
    public static final String CARD_STATUS = "cardStatus";
    public static final String PERSON = "person";
    public static final String EMAILS = "emailAddresses";
    public static final String EMAIL_ADDRESS = "emailAddress";
    public static final String PRIMARY = "primary";
    public static final String ACTIVE = "active";
    public static final String EMAIL_STATUS = "emailStatus";
    public static final String EMAIL_CONTACT_ORDER = "contactOrder";
    public static final String EMPTY = "";
    public static final String GUEST = "GUEST";

    private static final Logger logger = LoggerFactory.getLogger(BuyerObjectProcessor.class);

    @Override
    public BiFunction<Map<String, Object>, Map<String, Object>, Map<String, Object>> transform() {
        return (customAttributes, data) -> {
            try {
                String memberId = (String) customAttributes.getOrDefault("memberId", EMPTY);
                BuyerMembershipDetails membershipDetails;
                if (!Objects.isNull(data) && hasMembershipInfo(data)) {
                    Map<String, Object> getMembershipObj = (Map<String, Object>) data.get(GET_MEMBERSHIP);
                    Map<String, Object> membershipObj = (Map<String, Object>) getMembershipObj.get(MEMBERSHIP);
                    Map<String, Object> personObj = (Map<String, Object>) getMembershipObj.getOrDefault(PERSON, Collections.emptyMap());
                    Map<String, Object> organizationObj = (Map<String, Object>) getMembershipObj.getOrDefault(ORGANIZATION, Collections.emptyMap());
                    membershipDetails = (BuyerMembershipDetails) BuyerMembershipDetails.builder()
                            .id((String) getMembershipObj.getOrDefault(ID, memberId))
                            .fullId((memberId.length() == 17 ) ? memberId: (String) membershipObj.getOrDefault(PRINTED_MEMBERSHIP,EMPTY))
                            .taxExemptStatus((Boolean) membershipObj.getOrDefault(TAX_EXEMPT_STATUS, null))
                            .membershipType((String) membershipObj.getOrDefault(MEMBERSHIP_TYPE, EMPTY))
                            .membershipTypeCode(getMembershipType(membershipObj,organizationObj))
                            .membershipStatus((String) membershipObj.getOrDefault(MEMBERSHIP_STATUS, EMPTY))
                            .email(fetchPrimaryEmail(personObj))
                            .cardType((String) membershipObj.getOrDefault(CARD_TYPE, EMPTY))
                            .person(personObj)
                            .cardExpirationDate((String) membershipObj.getOrDefault(END_DATE, EMPTY))
                            .nextRenewDate((String) membershipObj.getOrDefault(END_DATE, EMPTY))
                            .cardStatus((String) membershipObj.getOrDefault(CARD_STATUS, EMPTY))
                            .build();
                } else {
                    if (StringUtils.isEmpty(memberId))
                        throw new CustomFilterException("Null/Empty MemberId for default buyer object mapping", memberId);
                    membershipDetails = getDefaultMembership(memberId);
                }
                BuyerDetails buyerObj = new BuyerDetails(membershipDetails);
                Map<String, Object> val = objectMapper.convertValue(buyerObj, new TypeReference<Map<String, Object>>() {
                });
                data.put("buyer", val);

            } catch (Exception e) {
                logger.error("BuyerObjectProcessor Failure: ", e);
            }
            return data;
        };
    }

    private MembershipType getMembershipType(Map<String, Object>membershipObj , Map<String, Object> organizationObj) {
        if (membershipObj.get(MEMBERSHIP_TYPE).equals(GUEST)) {
            return MembershipType.G;
        } else if (!organizationObj.isEmpty()) {
            if ((Boolean)membershipObj.get(TAX_EXEMPT_STATUS)&& (Boolean)membershipObj.get(TAX_EXEMPT) ) {
                return MembershipType.X;
            }
            return MembershipType.W;
        } else {
            return MembershipType.V;
        }
    }

    private String fetchPrimaryEmail(Map<String, Object> person) {
        String primaryEmail = EMPTY;
        List<Map<String, String>> emailAddresses = (List<Map<String, String>>) person.getOrDefault(EMAILS, Collections.emptyList());
        if (!CollectionUtils.isEmpty(emailAddresses)) {
            Optional<Map<String, String>> emailAddress = emailAddresses.stream()
                    .filter(emails -> ACTIVE.equalsIgnoreCase(emails.get(EMAIL_STATUS))
                            && PRIMARY.equalsIgnoreCase(emails.get(EMAIL_CONTACT_ORDER)))
                    .findFirst();
            if (emailAddress.isPresent())
                primaryEmail = emailAddress.get().getOrDefault(EMAIL_ADDRESS, EMPTY);
        }
        return primaryEmail;
    }

    @SuppressWarnings("unchecked")
    private boolean hasMembershipInfo(Map<String, Object> data) {
        Object get_member_obj = data.get(GET_MEMBERSHIP);
        return Objects.nonNull(get_member_obj) && (get_member_obj instanceof Map) && Objects.nonNull(((Map<String, Object>) get_member_obj).get(MEMBERSHIP));
    }

    private BuyerMembershipDetails getDefaultMembership(String memberId) {
        return BuyerMembershipDetails.builder()
                .id(EMPTY)
                .fullId(memberId)
                .taxExemptStatus(false)
                .membershipType(EMPTY)
                .membershipTypeCode(MembershipType.V)
                .membershipStatus(EMPTY)
                .email(EMPTY)
                .cardType(EMPTY)
                .person(Collections.emptyMap())
                .cardExpirationDate(EMPTY)
                .nextRenewDate(EMPTY)
                .cardStatus(EMPTY)
                .build();
    }

}
