package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddOnMembershipDetails {

    private MembershipDetails addOnMembership;
    private MembershipDetails addOnComplimentaryMembership;

    public AddOnMembershipDetails() {
    }

    public MembershipDetails getAddOnMembership() {
        return addOnMembership;
    }

    public void setAddOnMembership(MembershipDetails addOnMembership) {
        this.addOnMembership = addOnMembership;
    }

    public MembershipDetails getAddOnComplimentaryMembership() {
        return addOnComplimentaryMembership;
    }

    public void setAddOnComplimentaryMembership(MembershipDetails addOnComplimentaryMembership) {
        this.addOnComplimentaryMembership = addOnComplimentaryMembership;
    }
}
