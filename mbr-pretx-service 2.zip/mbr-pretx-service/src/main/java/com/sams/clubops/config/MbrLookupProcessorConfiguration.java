package com.sams.clubops.config;

import com.sams.clubops.config.ccm.CashWalletConfig;
import com.sams.clubops.config.ccm.CreditConfig;
import com.sams.clubops.config.ccm.MemberConfig;
import com.sams.clubops.config.ccm.TitanConfig;
import com.sams.clubops.config.vault.CashWalletAuthProperties;
import com.sams.clubops.config.vault.CreditAuthProperties;
import com.sams.clubops.config.vault.MocAuthProperties;
import com.sams.clubops.config.vault.TitanAuthProperties;
import com.sams.clubops.constants.ClientTypes;
import com.sams.clubops.cpcoauth2provider.domain.ClientCredentialsResourceDetails;
import com.sams.clubops.cpcoauth2provider.domain.ResourceDetails;
import com.sams.clubops.cpcoauth2provider.service.OAuth2Template;
import com.sams.clubops.mbr.sets.ccm.CustomOAuthVaultDetails;
import com.sams.clubops.mbr.sets.ccm.HeaderConfigAsMap;
import com.sams.clubops.mbr.sets.client.processor.MbrSetsTypeProcessor;
import com.sams.clubops.mbr.sets.client.utils.MbrMappingUtils;
import com.sams.clubops.mbr.sets.client.web.RestClient;
import com.sams.clubops.mbr.sets.commands.processor.MbrSetsCommandProcessor;
import com.sams.clubops.mbr.sets.constants.AppConstants;
import com.sams.clubops.mbr.sets.domain.request.ClientDetails;
import com.sams.clubops.mbr.sets.domain.request.ClientWrapper;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

@Configuration
public class MbrLookupProcessorConfiguration {

    @Bean
    @Autowired
    public RestClient restClient(RestTemplate restTemplateProvided) {
        return new RestClient(restTemplateProvided);
    }

    @Bean
    @Autowired
    public MbrMappingUtils mbrMappingUtils(HeaderConfigAsMap headerConfigAsMap) {
        return new MbrMappingUtils(headerConfigAsMap);
    }

    @Bean
    public ResourceDetails mocCredentialsResourceDetails(MocAuthProperties mocAuthProperties) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/x-www-form-urlencoded");
        headers.add("CORE_VSN", "v1");
        headers.add("Ocp-Apim-Subscription-Key",mocAuthProperties.getSubsrciptionKey());
        headers.add("clientId",mocAuthProperties.getClientId());

        return new ClientCredentialsResourceDetails(mocAuthProperties.getAccessTokenUri(), mocAuthProperties.getClientId(), mocAuthProperties.getClientSecret(), mocAuthProperties.getResource(), headers);
    }

    @Bean(name="mocOAuth2Template")
    public OAuth2Template mocOAuth2Template(ResourceDetails mocCredentialsResourceDetails) {
        return new OAuth2Template(mocCredentialsResourceDetails);
    }

    @Bean
    public ClientDetails mocClientDetails(OAuth2Template mocOAuth2Template, MemberConfig commonConfig) {
        return new ClientDetails(mocOAuth2Template, commonConfig);
    }

    @Bean
    public ResourceDetails creditCredentialsResourceDetails(CreditAuthProperties creditAuthProperties) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/x-www-form-urlencoded");
        headers.add("Ocp-Apim-Subscription-Key",creditAuthProperties.getSubsrciptionKey());
        headers.add("clientId",creditAuthProperties.getClientId());
        return new ClientCredentialsResourceDetails(creditAuthProperties.getAccessTokenUri(), creditAuthProperties.getClientId(), creditAuthProperties.getClientSecret(), creditAuthProperties.getResource(), headers);
    }

    @Bean(name = "creditOAuth2Template")
    public OAuth2Template creditOAuth2Template(ResourceDetails creditCredentialsResourceDetails) {
        return new OAuth2Template(creditCredentialsResourceDetails);
    }

    @Bean
    public ClientDetails creditClientDetails(OAuth2Template creditOAuth2Template, CreditConfig creditConfig, CustomOAuthVaultDetails creditVaultDetails) {
        return new ClientDetails(creditOAuth2Template, creditVaultDetails, creditConfig);
    }

    //Titan configurations
    @Bean
    public ClientDetails titanClientDetails(TitanConfig titanConfig, TitanAuthProperties titanAuthProperties) {
        ClientDetails titanClientDetails = new ClientDetails(titanConfig);
        titanClientDetails.setApp2AppSecurityData(titanAuthProperties.getConsumerId(),
                                                  titanAuthProperties.getPrivateKey(),
                                                  titanAuthProperties.getServiceName(),
                                                  titanAuthProperties.getEnv(),
                                                  titanAuthProperties.getPrivateKeyVersion());
        return titanClientDetails;
    }

    //Cash Wallet Configuration
    @Bean
    public ClientDetails cashWalletClientDetails(CashWalletConfig cashWalletConfig, CashWalletAuthProperties cashWalletAuthProperties) {
        ClientDetails cashWalletClientDetails = new ClientDetails(cashWalletConfig);
        cashWalletClientDetails.setApp2AppSecurityData(cashWalletAuthProperties.getConsumerId(),
                                                  cashWalletAuthProperties.getPrivateKey(),
                                                  cashWalletAuthProperties.getServiceName(),
                                                  cashWalletAuthProperties.getEnv(),
                                                  cashWalletAuthProperties.getPrivateKeyVersion());
        return cashWalletClientDetails;
    }

    @Bean
    @Autowired
    public ClientWrapper clientWrapper(ClientDetails mocClientDetails,
                            ClientDetails creditClientDetails,
                            ClientDetails titanClientDetails,
                            ClientDetails cashWalletClientDetails) {
        ClientWrapper clientWrapper = new ClientWrapper(ClientTypes.class);
        clientWrapper.addClientDetails(ClientTypes.MOC.name(), mocClientDetails);
        clientWrapper.addClientDetails(ClientTypes.CREDIT.name(), creditClientDetails);
        clientWrapper.addClientDetails(ClientTypes.TITAN.name(), titanClientDetails);
        clientWrapper.addClientDetails(ClientTypes.CASHWALLET.name(), cashWalletClientDetails);
        return clientWrapper;
    }

    @Bean
    @Autowired
    public MbrSetsCommandProcessor mbrLookupCommandProcessor(RestClient restClient, MbrMappingUtils mbrMappingUtils, ClientWrapper clientWrapper) {
        return new MbrSetsTypeProcessor(restClient, mbrMappingUtils, clientWrapper);
    }
}
