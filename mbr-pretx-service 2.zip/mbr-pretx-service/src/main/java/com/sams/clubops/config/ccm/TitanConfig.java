package com.sams.clubops.config.ccm;

import com.sams.clubops.mbr.sets.ccm.CommonConfig;
import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration
public interface TitanConfig extends CommonConfig {
    @Property(
        propertyName = "titan.host"
    )
    String getHost();
}

