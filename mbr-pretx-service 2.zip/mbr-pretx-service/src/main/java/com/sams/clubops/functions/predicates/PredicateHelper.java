package com.sams.clubops.functions.predicates;

import com.sams.clubops.functions.impl.RenewUpgrade;
import java.util.EnumSet;
import java.util.Map;
import java.util.function.Predicate;

public class PredicateHelper {

    public static Predicate<Map<String, Object>> notSupportedOperation(EnumSet<RenewUpgrade.Operations> feeDetailList) {
        return (feeDetail) -> {
            RenewUpgrade.Operations operations;
            try {
                operations = RenewUpgrade.Operations.valueOf((String) feeDetail.get("issuanceMethod"));
            } catch (IllegalArgumentException e) {
                operations = RenewUpgrade.Operations.NONE;
            }
            return !feeDetailList.contains(operations);
        };
    }
}
