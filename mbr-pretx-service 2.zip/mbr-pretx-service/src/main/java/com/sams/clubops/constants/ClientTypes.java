package com.sams.clubops.constants;

public enum ClientTypes {
    MOC,
    CREDIT,
    TITAN,
    CASHWALLET
}
