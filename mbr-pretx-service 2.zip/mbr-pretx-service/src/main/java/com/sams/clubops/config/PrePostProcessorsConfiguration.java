package com.sams.clubops.config;

import com.sams.clubops.functions.impl.BuyerObjectProcessor;
import com.sams.clubops.functions.impl.CashRewardsSummaryObjectProcessor;
import com.sams.clubops.functions.impl.CreditSummaryObjectProcessor;
import com.sams.clubops.functions.impl.RenewUpgrade;
import com.sams.clubops.functions.predicates.CreditSummaryPredicate;
import com.sams.clubops.functions.predicates.MembershipPredicate;
import com.sams.clubops.mbr.lookup.ccm.ItemsConfigMap;
import com.sams.clubops.mbr.sets.commands.processor.PrePostProcessorRegistry;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PrePostProcessorsConfiguration {

    @Autowired
    private RenewUpgrade renewUpgrade;

    @Autowired
    private BuyerObjectProcessor buyerObjectProcessor;

    @Autowired
    private CreditSummaryObjectProcessor creditSummaryObjectProcessor;

    @Autowired
    private MembershipPredicate membershipPredicate;

    @Autowired
    private CreditSummaryPredicate creditSummaryPredicate;

    @Autowired
    private CashRewardsSummaryObjectProcessor cashRewardsSummaryObjectProcessor;

    private PrePostProcessorRegistry prePostProcessorRegistry = PrePostProcessorRegistry.getInstance();

    @PostConstruct
    private void init() {
        registerPreProcessors();
        registerPostProcessors();
    }

    private void registerPreProcessors() {
        preProcessors().forEach((k, v) -> prePostProcessorRegistry.registerPreConditionProcessor(k, v));
    }

    private void registerPostProcessors() {
        postProcessors().forEach((k, v) -> prePostProcessorRegistry.registerPostProcessor(k, v));
    }

    /**
     * pre processors to be registered
     * @return map of processor name-processor
     */
    private Map<String, Predicate<?>> preProcessors() {
        Map<String, Predicate<?>> predicateMap = new HashMap<>();
        predicateMap.putIfAbsent("member-expired-deleted", membershipPredicate.isNotExpiredOrDeletedMembership());
        predicateMap.putIfAbsent("check-credit-offer", creditSummaryPredicate.isNotCreditOfferAvailable());
        return Collections.unmodifiableMap(predicateMap);
    }

    /**
     * post processors to be registered
     * @return map of processor name-processor
     */
    private Map<String, BiFunction<Map<String, Object>, ? , ?>> postProcessors() {
        Map<String, BiFunction<Map<String, Object>, ? , ?>> functionMap = new HashMap<>();
        functionMap.putIfAbsent("renew-upgrade", renewUpgrade.transform());
        functionMap.putIfAbsent("buyer-mapper", buyerObjectProcessor.transform());
        functionMap.putIfAbsent("credit-summary-mapper", creditSummaryObjectProcessor.transform());
        functionMap.putIfAbsent("cash-reward-summary-processor", cashRewardsSummaryObjectProcessor.transform());
        return Collections.unmodifiableMap(functionMap);
    }

    @Bean
    public RenewUpgrade renewUpgrade(ItemsConfigMap itemsConfigMap) {
        return new RenewUpgrade(itemsConfigMap);
    }

    @Bean
    public BuyerObjectProcessor buyerObjectProcessor() {
        return new BuyerObjectProcessor();
    }

    @Bean
    public CreditSummaryObjectProcessor creditSummaryObjectProcessor() {
        return new CreditSummaryObjectProcessor();
    }

    @Bean
    public MembershipPredicate membershipPredicate() {
        return new MembershipPredicate();
    }

    @Bean
    public CreditSummaryPredicate creditSummaryPredicate() {
        return new CreditSummaryPredicate();
    }

    @Bean
    public CashRewardsSummaryObjectProcessor cashRewardsSummaryObjectProcessor() {
        return new CashRewardsSummaryObjectProcessor();
    }
}
