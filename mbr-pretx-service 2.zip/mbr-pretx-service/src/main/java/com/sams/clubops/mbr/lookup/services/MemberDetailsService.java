package com.sams.clubops.mbr.lookup.services;

import com.sams.clubops.mbr.lookup.models.MembershipUpdateDTO;
import com.sams.clubops.mbr.lookup.repositories.MemberDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MemberDetailsService {

    @Autowired
    private MemberDetailsRepository memberDetailsRepository;

    public Optional<MembershipUpdateDTO> findByMembershipId(String memberId) {
        return memberDetailsRepository.findByMembershipId(memberId);
    }
}
