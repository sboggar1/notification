package com.sams.clubops.mbr.lookup.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@JsonInclude(value = JsonInclude.Include.NON_EMPTY)
public class BuyerMembershipDetails {

    private final String id;

    private final String fullId;

    private final Boolean taxExemptStatus;

    private final String membershipType;

    private final MembershipType membershipTypeCode;

    private final String membershipStatus;

    private final String email;

    private final String cardType;

    @JsonProperty("memberName")
    private final Person person;

    private final String cardExpirationDate;

    private final String nextRenewDate;

    private final String cardStatus;

    public interface IdStep {
        FullIdStep id(String id);
    }

    public interface FullIdStep {
        TaxExemptStep fullId(String fullId);
    }

    public interface TaxExemptStep {
        MembershipTypeStep taxExemptStatus(Boolean taxExempt);
    }

    public interface MembershipTypeStep {
        MembershipTypeCodeStep membershipType(String membershipType);
    }
    public interface MembershipTypeCodeStep {
        MembershipStatusStep membershipTypeCode(MembershipType membershipTypeCode);
    }

    public interface MembershipStatusStep {
        EmailStep membershipStatus(String membershipStatus);
    }

    public interface EmailStep {
        CardTypeStep email(String email);
    }

    public interface CardTypeStep {
        PersonStep cardType(String cardType);
    }

    public interface PersonStep {
        CardExpirationDateStep person(Map<String, Object> person);
    }

    public interface CardExpirationDateStep {
        NextRenewDateStep cardExpirationDate(String cardExpirationDate);
    }

    public interface NextRenewDateStep {
        CardStatusStep nextRenewDate(String nextRenewDate);
    }

    public interface CardStatusStep {
        BuildStep cardStatus(String cardStatus);
    }

    public interface BuildStep {
        BuyerMembershipDetails build();
    }

    private BuyerMembershipDetails(MembershipDetailsBuilder membershipDetailsBuilder) {
        this.id = membershipDetailsBuilder.id;
        this.fullId = membershipDetailsBuilder.fullId;
        this.taxExemptStatus = membershipDetailsBuilder.taxExemptStatus;
        this.membershipType = membershipDetailsBuilder.membershipType;
        this.membershipTypeCode=membershipDetailsBuilder.membershipTypeCode;
        this.membershipStatus = membershipDetailsBuilder.membershipStatus;
        this.email = membershipDetailsBuilder.email;
        this.cardType = membershipDetailsBuilder.cardType;
        this.person = membershipDetailsBuilder.person;
        this.cardExpirationDate = membershipDetailsBuilder.cardExpirationDate;
        this.nextRenewDate = membershipDetailsBuilder.nextRenewDate;
        this.cardStatus = membershipDetailsBuilder.cardStatus;
    }

    private static class MembershipDetailsBuilder implements IdStep, FullIdStep, TaxExemptStep, MembershipTypeStep,MembershipTypeCodeStep, MembershipStatusStep, EmailStep, CardTypeStep, PersonStep, CardExpirationDateStep, NextRenewDateStep, CardStatusStep, BuildStep {

        private String id;

        private String fullId;

        private Boolean taxExemptStatus;

        private String membershipType;

        private MembershipType membershipTypeCode;

        private String membershipStatus;

        private String email;

        private String cardType;

        private Person person;

        private String cardExpirationDate;

        private String nextRenewDate;

        private String cardStatus;

        @Override
        public BuyerMembershipDetails build() {
            return new BuyerMembershipDetails(this);
        }

        @Override
        public FullIdStep id(final String id) {
            Objects.requireNonNull(id);
            this.id = id;
            return this;
        }

        @Override
        public TaxExemptStep fullId(final String fullId) {
            Objects.requireNonNull(fullId);
            this.fullId = fullId;
            return this;
        }

        @Override
        public MembershipTypeStep taxExemptStatus(final Boolean taxExempt) {
            this.taxExemptStatus = taxExempt;
            return this;
        }

        @Override
        public MembershipTypeCodeStep membershipType(final String membershipType) {
            Objects.requireNonNull(membershipType);
            this.membershipType = membershipType;
            return this;
        }

        @Override
        public MembershipStatusStep membershipTypeCode(final MembershipType membershipTypeCode)
        {  Objects.requireNonNull(membershipTypeCode);
            this.membershipTypeCode = membershipTypeCode;
            return this;
        }

        @Override
        public EmailStep membershipStatus(final String membershipStatus) {
            Objects.requireNonNull(membershipStatus);
            this.membershipStatus = membershipStatus;
            return this;
        }

        @Override
        public CardTypeStep email(final String email) {
            Objects.requireNonNull(email);
            this.email = email;
            return this;
        }

        @Override
        public PersonStep cardType(final String cardType) {
            Objects.requireNonNull(cardType);
            this.cardType = cardType;
            return this;
        }

        @Override
        public CardExpirationDateStep person(final Map<String, Object> personMap) {
            Objects.requireNonNull(personMap);
            this.person = getPersonFromMap(personMap);
            return this;
        }

        @Override
        public NextRenewDateStep cardExpirationDate(final String cardExpirationDate) {
            Objects.requireNonNull(cardExpirationDate);
            this.cardExpirationDate = cardExpirationDate;
            return this;
        }

        @Override
        public CardStatusStep nextRenewDate(final String nextRenewDate) {
            Objects.requireNonNull(nextRenewDate);
            this.nextRenewDate = nextRenewDate;
            return this;
        }

        @Override
        public BuildStep cardStatus(final String cardStatus) {
            Objects.requireNonNull(cardStatus);
            this.cardStatus = cardStatus;
            return this;
        }

        private Person getPersonFromMap(final Map<String, Object> personMap) {
            Person person = new Person();
            person.setFirstName((String) personMap.getOrDefault("firstName", ""));
            person.setLastName((String) personMap.getOrDefault("lastName", ""));
            person.setFullName((String) personMap.getOrDefault("fullName", ""));
            person.setAffiliations((List<?>) personMap.getOrDefault("affiliations", Collections.emptyList()));
            return person;
        }
    }

    public static IdStep builder() {
        return new BuyerMembershipDetails.MembershipDetailsBuilder();
    }

    public String getId() {
        return id;
    }

    public String getFullId() {
        return fullId;
    }

    public Boolean getTaxExemptStatus() {
        return taxExemptStatus;
    }

    public String getMembershipType() {
        return membershipType;
    }


    public MembershipType getMembershipTypeCode() {
        return membershipTypeCode;
    }

    public String getMembershipStatus() {
        return membershipStatus;
    }

    public String getEmail() {
        return email;
    }

    public String getCardType() {
        return cardType;
    }

    public Person getPerson() throws CloneNotSupportedException {
        return (Person) person.clone();
    }

    public String getCardExpirationDate() {
        return cardExpirationDate;
    }

    public String getNextRenewDate() {
        return nextRenewDate;
    }

    public String getCardStatus() {
        return cardStatus;
    }

}
