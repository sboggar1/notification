package com.sams.er.client.eai;

import static com.sams.er.util.ClientUtil.updateStringMap;

import com.sams.er.ccm.CommonConfig;
import com.sams.er.vault.NextgenEaiProperties;
import com.sams.er.vault.VaultData;
import java.io.ObjectStreamException;
import java.nio.charset.StandardCharsets;
import java.security.KeyRep;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * This will generate the signature required by API Proxy for consumer.
 * Signature will be generated every 4.5 min and updated in signatureMap.
 */
public class EAIProxyHelper {

    public static final Logger logger = LoggerFactory.getLogger(EAIProxyHelper.class);

    private HttpHeaders httpHeaders;
    private Map<String, Object> headers;
    private CommonConfig ccmConfigs;
    private VaultData vaultData;
    private NextgenEaiProperties nextgenEaiProperties;

    public EAIProxyHelper(CommonConfig ccmConfigs, VaultData vaultData, NextgenEaiProperties nextgenEaiProperties) {
        this.ccmConfigs = ccmConfigs;
        this.vaultData = vaultData;
        this.nextgenEaiProperties = nextgenEaiProperties;
    }


    private final Object object = new Object();

    private static final Map<String, String> signatureMap = new ConcurrentHashMap<>();
    private static final Map<String, String> nextGenSignatureMap = new ConcurrentHashMap<>();

    public HttpHeaders getApiProxyHeaders() {
        if (httpHeaders != null)
            return httpHeaders;
        synchronized (object) {
            if (httpHeaders == null) {
                httpHeaders = new HttpHeaders();
                httpHeaders.add(EAIProxyConstants.WM_SEC_KEY_VERSION, EAIProxyConstants.SEC_KEY_VERSION);
                httpHeaders.add(EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, EAIProxyConstants.WM_CONSUMER_INTIMESTAMP);
                httpHeaders.add(EAIProxyConstants.WM_QOS_CORRELATION_ID, EAIProxyConstants.ONE);    // CAN BE ANY DUMMY VALUE
                httpHeaders.add(EAIProxyConstants.CONTENT_TYPE, EAIProxyConstants.APPLICATION_JSON);
                httpHeaders.add(EAIProxyConstants.ACCEPT, EAIProxyConstants.APPLICATION_JSON);
            }
        }
        return httpHeaders;
    }

    public Map<String, Object> getApiProxyHeadersMap() {
        if (headers != null)
            return headers;
        synchronized (object) {
            if (headers == null) {
                headers = new HashMap<>();
                headers.put(EAIProxyConstants.WM_SEC_KEY_VERSION, EAIProxyConstants.SEC_KEY_VERSION);
                headers.put(EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, EAIProxyConstants.WM_CONSUMER_INTIMESTAMP);
                headers.put(EAIProxyConstants.WM_QOS_CORRELATION_ID, EAIProxyConstants.ONE);    // CAN BE ANY DUMMY VALUE
                headers.put(EAIProxyConstants.CONTENT_TYPE, EAIProxyConstants.APPLICATION_JSON);
                headers.put(EAIProxyConstants.ACCEPT, EAIProxyConstants.APPLICATION_JSON);
            }
        }
        return headers;
    }

    private static String generateSignature(String key, String stringToSign) throws Exception {

        Signature signatureInstance = Signature.getInstance("SHA256WithRSA");

        ServiceKeyRep keyRep = new ServiceKeyRep(KeyRep.Type.PRIVATE, "RSA", "PKCS#8", Base64.decodeBase64(key));

        PrivateKey resolvedPrivateKey = (PrivateKey) keyRep.readResolve();

        signatureInstance.initSign(resolvedPrivateKey);

        byte[] bytesToSign = stringToSign.getBytes(StandardCharsets.UTF_8);

        signatureInstance.update(bytesToSign);

        byte[] signatureBytes = signatureInstance.sign();

        return Base64.encodeBase64String(signatureBytes);

    }


    private static String[] canonicalize(Map<String, String> headersToSign) {

        StringBuilder canonicalizedStrBuffer = new StringBuilder();

        StringBuilder parameterNamesBuffer = new StringBuilder();

        Set<String> keySet = headersToSign.keySet();

        // Create sorted key set to enforce order on the key names
        SortedSet<String> sortedKeySet = new TreeSet<>(keySet);

        for (String key : sortedKeySet) {
            Object val = headersToSign.get(key);
            parameterNamesBuffer.append(key.trim()).append(";");
            canonicalizedStrBuffer.append(val.toString().trim()).append("\n");
        }

        return new String[]{parameterNamesBuffer.toString(), canonicalizedStrBuffer.toString()};
    }


    private static class ServiceKeyRep extends KeyRep {
        private static final long serialVersionUID = -7213340660431987616L;

        private ServiceKeyRep(Type type, String algorithm, String format, byte[] encoded) {
            super(type, algorithm, format, encoded);
        }

        protected Object readResolve() throws ObjectStreamException {
            return super.readResolve();
        }
    }

    private void getNextgenSignature() {
        String inTimestamp = String.valueOf(System.currentTimeMillis());
        Map<String, String> map = new HashMap<>();
        updateStringMap(map, EAIProxyConstants.WM_CONSUMER_ID, nextgenEaiProperties.getConsumerId());
        updateStringMap(map, EAIProxyConstants.WM_SEC_KEY_VERSION, EAIProxyConstants.SEC_KEY_VERSION);
        updateStringMap(map, EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, inTimestamp);
        String[] array = EAIProxyHelper.canonicalize(map);
        String apiProxySignature = null;
        try {
            apiProxySignature = EAIProxyHelper.generateSignature(nextgenEaiProperties.getPrivateKey(), array[1]);
            logger.info("Successfully generated Nextgen API Proxy signature");
        } catch (Exception e) {
            logger.error("Error generating Nextgen api proxy signature: " +e);
        }
        updateStringMap(nextGenSignatureMap,EAIProxyConstants.WM_CONSUMER_ID, nextgenEaiProperties.getConsumerId());
        updateStringMap(nextGenSignatureMap,EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, inTimestamp);
        updateStringMap(nextGenSignatureMap,EAIProxyConstants.WM_SEC_AUTH_SIGNATURE, apiProxySignature);
        updateStringMap(nextGenSignatureMap,EAIProxyConstants.WM_SVC_NAME, nextgenEaiProperties.getSvcName());
        updateStringMap(nextGenSignatureMap,EAIProxyConstants.WM_SVC_ENV, nextgenEaiProperties.getSvcEnv());
    }

    private void getSignature() {
        String inTimestamp = String.valueOf(System.currentTimeMillis());
        Map<String, String> map = new HashMap<>();

        updateStringMap(map,EAIProxyConstants.WM_CONSUMER_ID, ccmConfigs.getConsumerId());
        updateStringMap(map,EAIProxyConstants.WM_SEC_KEY_VERSION, EAIProxyConstants.SEC_KEY_VERSION);
        updateStringMap(map,EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, inTimestamp);

        String[] array = EAIProxyHelper.canonicalize(map);

        String apiProxySignature = null;

        try {
            apiProxySignature = EAIProxyHelper.generateSignature(vaultData.getPrivateKey(), array[1]);
            logger.info("Successfully generated API Proxy signature");

        } catch (Exception e) {
            logger.error("Error generating api proxy signature: " +e);
        }

        updateStringMap(signatureMap,EAIProxyConstants.WM_CONSUMER_ID, ccmConfigs.getConsumerId());
        updateStringMap(signatureMap,EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, inTimestamp);
        updateStringMap(signatureMap,EAIProxyConstants.WM_SEC_AUTH_SIGNATURE, apiProxySignature);

    }

    public Map<String, String> getSignatureMap() {
        if (signatureMap.isEmpty()) {
            getSignature();
        }
        return signatureMap;
    }

    public Map<String, String> getNextGenSignatureMap() {
        if (nextGenSignatureMap.isEmpty()) {
            getNextgenSignature();
        }
        return nextGenSignatureMap;
    }


    @Scheduled(fixedRate = EAIProxyConstants.CRON_TIME)
    public void fetchTokenScheduler() {
        getSignature();
        getNextgenSignature();
    }
}
