package com.sams.er.controller;

import static org.springframework.http.HttpStatus.OK;

import com.sams.er.client.eai.EmailResponse;
import com.sams.er.constants.AppConstants;
import com.sams.er.constants.ERConstants;
import com.sams.er.headers.RequestHeaders;
import com.sams.er.response.RestError;
import com.sams.er.response.StatusResponse;
import com.sams.er.service.EmailReceiptService;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/emailreceiptservice",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class EmailReceiptController {

    private static final Logger log = LoggerFactory.getLogger(EmailReceiptController.class);

    @Autowired
    EmailReceiptService emailReceiptService;

    @PostMapping(value = "/postEmailReceipt")
    @ResponseStatus(HttpStatus.OK)
   // public ResponseEntity<EmailResponse> postEmailReceipt(@RequestBody String purchaseContractRequest, @RequestHeader HttpHeaders headers) {
    public ResponseEntity<EmailResponse> postEmailReceipt(@RequestBody String purchaseContractRequest,
                                                          @RequestHeader(name = "Content-Type", required = true) String contentType,
                                                          @RequestHeader(name = "cpc_token", required = true) String cpcToken,
                                                          @RequestHeader(name = "cps_clientApp", required = true) String clientApp) {
        RequestHeaders requestHeaders = new RequestHeaders();
        requestHeaders.setContentType(contentType);
        requestHeaders.setCpcToken(cpcToken);
        requestHeaders.setCpcClientApp(clientApp);
        log.info("postEmailReceipt Call ======================= ");
        return ResponseEntity.status(OK).body(emailReceiptService.processEmailCall(purchaseContractRequest, requestHeaders));
    }

    @PostMapping(value = "/cash/redemption",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<EmailResponse> postCashRdemptionEmail(@RequestBody String cashRedemptionBody, @RequestHeader Map<String, String> headers) {
        log.info("postCashRdemptionEmail Call ======================= ");
        return ResponseEntity.status(OK).body(emailReceiptService.processCashRedemptionEmail(cashRedemptionBody, headers));
    }

    @GetMapping(value = "/status")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity healthCheck() {
        log.info("EmailReceipts Check Status call ===========");
        StatusResponse<String, RestError> response = new StatusResponse<>();
        response.setName(AppConstants.EMAIL_RECEIPTS_SERVICE);
        response.setMessage(AppConstants.HEALTH_CHECK + " --> " + AppConstants.RUNNING);
        response.setData(ERConstants.HEALTHY.toString());
        return new ResponseEntity<StatusResponse>(response, OK);
    }

}
