package com.sams.er.client;

/**
 * General Checkout Service Exception
 * @author VN90514
 * Created on 03/24/2021.
 */
public class ERBadRequestException extends RuntimeException {

    public ERBadRequestException(String message) {
        super( message);
    }

    public ERBadRequestException(String message, Throwable throwable) {
        super( message, throwable);
    }

    public ERBadRequestException(Throwable throwable) {
        super( throwable);
    }

}
