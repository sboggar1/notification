package com.sams.er.config;

import com.sams.er.ccm.CCMConfigs;
import com.sams.er.vault.CosmosProperties;
import com.sams.er.vault.CpcProperties;
import com.sams.er.vault.EaiProperties;
import com.sams.er.vault.VaultData;
import io.strati.ccm.utils.client.api.ServiceConfigVersionCache;
import io.strati.tunr.utils.client.ServiceConfigClientFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CCMConfiguration {

    /*private static ServiceConfigVersionCache serviceConfigVersionCache = ServiceConfigClientFactory.getInstance().getServiceConfigVersionCache();

    public CCMConfiguration() {
        if (serviceConfigVersionCache == null)
            throw new RuntimeException("Exception setting CCM Server");
    }

    @Bean
    public CCMConfigs ccmConfigs() {
        return serviceConfigVersionCache.getResolvedConfiguration("commonConfig", CCMConfigs.class, null);
    }*/


    @Bean
    public VaultData vaultProperties(CosmosProperties cosmosProperties, EaiProperties eaiProperties, CpcProperties cpcProperties) {
        return new VaultData(cosmosProperties.getUri(), cosmosProperties.getSecondaryKey(), cosmosProperties.isQueryMetricsEnabled(), cosmosProperties.getDatabase(), cosmosProperties.getConnectMode(),
                eaiProperties.getPublicKey(), eaiProperties.getPrivateKey(), cpcProperties.getOeToken());
    }


}
