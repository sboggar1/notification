package com.sams.er.client.oe.mappings;

public class Zone {

    private Current current;

    private Next next;

    private Boolean hasDST;

    public Current getCurrent() {
        return current;
    }

    public void setCurrent(Current current) {
        this.current = current;
    }

    public Next getNext() {
        return next;
    }

    public void setNext(Next next) {
        this.next = next;
    }

    public Boolean getHasDST() {
        return hasDST;
    }

    public void setHasDST(Boolean hasDST) {
        this.hasDST = hasDST;
    }
}
