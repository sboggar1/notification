package com.sams.er.client.eai.dto;

public class TimeZoneDTO {

    private LocationDTO location;

    private TimeDTO time;

    public LocationDTO getLocation() {
        return location;
    }

    public void setLocation(LocationDTO location) {
        this.location = location;
    }

    public TimeDTO getTime() {
        return time;
    }

    public void setTime(TimeDTO time) {
        this.time = time;
    }
}
