package com.sams.er.util.constants;

public enum ClientApp {

    US_WEBPOS_KIOSK_SAMS("US_WEBPOS_KIOSK_SAMS");

    private final String clientAppName;

    ClientApp(String clientAppName) {
        this.clientAppName = clientAppName;
    }

    public String getClientAppName() {
        return clientAppName;
    }

}
