package com.sams.er.client.eai.dto;

import java.math.BigDecimal;

public class StoreLocationDTO {

    private TimeZoneDTO timeZone;

    protected BigDecimal latitude;

    protected BigDecimal longitude;

    protected String clubHours;

    protected String clubDirection;

    public String getClubHours() {
        return clubHours;
    }

    public void setClubHours(String clubHours) {
        this.clubHours = clubHours;
    }

    public String getClubDirection() {
        return clubDirection;
    }

    public void setClubDirection(String clubDirection) {
        this.clubDirection = clubDirection;
    }

    public TimeZoneDTO getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(TimeZoneDTO timeZone) {
        this.timeZone = timeZone;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}
