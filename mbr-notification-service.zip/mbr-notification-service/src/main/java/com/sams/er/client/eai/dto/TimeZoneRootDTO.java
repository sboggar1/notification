package com.sams.er.client.eai.dto;

public class TimeZoneRootDTO {

    private TimeZoneDTO timezone;

    public TimeZoneDTO getTimezone() {
        return timezone;
    }

    public void setTimezone(TimeZoneDTO timezone) {
        this.timezone = timezone;
    }
}
