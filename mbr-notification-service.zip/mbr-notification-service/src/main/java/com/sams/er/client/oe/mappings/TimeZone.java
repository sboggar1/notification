package com.sams.er.client.oe.mappings;

public class TimeZone {

    private Location location;

    private Time time;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }
}
