package com.sams.er.client.eai.dto;

public class TimeDTO {

    private ZoneDTO zone;

    public ZoneDTO getZone() {
        return zone;
    }

    public void setZone(ZoneDTO zone) {
        this.zone = zone;
    }
}
