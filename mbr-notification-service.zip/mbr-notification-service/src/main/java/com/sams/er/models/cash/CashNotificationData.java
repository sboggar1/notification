package com.sams.er.models.cash;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CashNotificationData {
    @JsonProperty("dynamic_data")
    private CashNotificationDynamicData cashNotificationDynamicData;

    public CashNotificationDynamicData getCashNotificationDynamicData() {
        return cashNotificationDynamicData;
    }

    public void setCashNotificationDynamicData(CashNotificationDynamicData cashNotificationDynamicData) {
        this.cashNotificationDynamicData = cashNotificationDynamicData;
    }
}
