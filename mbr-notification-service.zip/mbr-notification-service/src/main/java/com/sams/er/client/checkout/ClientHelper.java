package com.sams.er.client.checkout;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.Response;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * HTTP REST/JSON Client helper
 * @author VN90514
 * Created on 03/24/2021.
 */
public class ClientHelper {

    private static final Logger LOG = LoggerFactory.getLogger(ClientHelper.class);

    //  RFC 7231 Date/Time Formats - https://tools.ietf.org/html/rfc7231#section-7.1.1.1
    private static final SimpleDateFormat rfc7231dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");
    private static final String            DEFAULT_CHARSET = StandardCharsets.UTF_8.name();
    private static final String     USER_AGENT_HEADER_NAME = "User-Agent";
    private static final String    USER_AGENT_HEADER_VALUE = "xo-cancel-batch Job";
    private static final String ACCEPT_CHARSET_HEADER_NAME = "Accept-Charset";
    public  static final String   CONTENT_TYPE_HEADER_NAME = "Content-Type";
    private static final String           ETAG_HEADER_NAME = "ETag";
    private static final String          ALLOW_HEADER_NAME = "Allow";
    private static final String           DATE_HEADER_NAME = "Date";
    private static final String  LAST_MODIFIED_HEADER_NAME = "Last-Modified";

    public  static final String APPLICATION_JSON      = "application/json";
    private static final String TEXT_HTML             = "text/html";
    private static final String TEXT_XHTML            = "text/xhtml";
    private static final String TEXT_XML              = "text/xml";
    private static final String TEXT_PLAIN            = "text/plain";
    private static final String APPLICATION_XML       = "application/xml";
    private static final String APPLICATION_XHTML_XML = "application/xhtml+xml";

    private static final String  DEFAULT_CONTENT_TYPE = "text/plain; charset=us-ascii"; // http://mattryall.net/blog/2008/03/default-content-type

    private enum HttpMethod {
        POST, PUT, GET, DELETE;
    }

    public static Response getJson( URL url, Map<String, Object> headers) throws IOException {
        return execJson( url, HttpMethod.GET, headers, null);
    }

    public static Response putJson(URL url, Map<String, Object> headers, String payload) throws IOException {
        return execJson(url, HttpMethod.PUT, headers, payload);
    }

    public static Response postJson(URL url, Map<String, Object> headers, String payload) throws IOException {
        return execJson(url, HttpMethod.POST, headers, payload);
    }

    public static Response delete(URL url, Map<String, Object> headers) throws IOException {
        return execJson(url, HttpMethod.DELETE, headers, null);
    }



    // inspired by http://stackoverflow.com/questions/2793150/using-java-net-urlconnection-to-fire-and-handle-http-requests
    private static Response execJson(URL url, HttpMethod method, Map<String, Object> headers, String payload) throws IOException {

        HttpURLConnection http = (HttpURLConnection) url.openConnection();
        http.setConnectTimeout(0); // We will handle timeouts differently
        http.setReadTimeout(0);
        http.setRequestMethod( method.name());
        if ( LOG.isDebugEnabled()) {
            LOG.debug( "HTTP Request:");
            LOG.debug( "    URL: " + url.toString());
            LOG.debug( "    ConnectTimeout: 0");
            LOG.debug( "    ReadTimeout: 0");
            LOG.debug( "    Method:" + method.name());
            LOG.debug( "    HTTP Request Headers:");
        }
        for (Map.Entry<String, Object> entry : headers.entrySet()) {
            if ( LOG.isDebugEnabled()) {
                LOG.debug( "      " + entry.getKey() + ": " + entry.getValue().toString());
            }
            http.setRequestProperty( entry.getKey(), entry.getValue().toString());
        }
        http.setRequestProperty( ACCEPT_CHARSET_HEADER_NAME, DEFAULT_CHARSET);
        http.setRequestProperty(     USER_AGENT_HEADER_NAME, USER_AGENT_HEADER_VALUE);
        if ( LOG.isDebugEnabled()) {
            LOG.debug( "      " + ACCEPT_CHARSET_HEADER_NAME + ": " + DEFAULT_CHARSET);
            LOG.debug( "      " + USER_AGENT_HEADER_NAME     + ": " + USER_AGENT_HEADER_VALUE);
        }
        if ( null != payload) {
            if ( LOG.isDebugEnabled()) {
                LOG.debug( "    HTTP Request Payload:");
                LOG.debug( "      " + payload);
            }
            http.setDoOutput(true); // Triggers POST and PUT.
            if ( null != payload) {
                DataOutputStream dataOutputStream = new DataOutputStream(http.getOutputStream());
                dataOutputStream.write(payload.getBytes( DEFAULT_CHARSET));
            }
        }
        InputStream stream;
        try {
            http.connect();
            stream = http.getInputStream();
        } catch ( IOException ex) {
            stream = http.getErrorStream();
        }
        int resultCode = http.getResponseCode();
        if ( LOG.isDebugEnabled()) {
            LOG.debug("    HTTP Response Headers:");
            for ( Map.Entry<String,List<String>> entry: http.getHeaderFields().entrySet()) {
                StringBuilder stringBuilder = new StringBuilder();
                for ( String value: entry.getValue()) {
                    stringBuilder.append( ", ");
                    stringBuilder.append( value);
                }
                LOG.debug( "      " + entry.getKey() + ": [" + stringBuilder.substring(2) + "]");
            }
        }
        ClientResponse result = new ClientResponse();
        if ( null != stream) {
            String contentType = http.getHeaderField( CONTENT_TYPE_HEADER_NAME);
            String charset = null;
            if ( null == contentType) {
                contentType = DEFAULT_CONTENT_TYPE;
            }
            for (String param : contentType.replace(" ", "").split(";")) {
                if (param.startsWith( "charset=")) {
                    String[] splitted = param.split("=", 2);
                    charset = splitted[1];
                    break;
                } else {
                    contentType = param.trim();
                }
            }
            final String entity = new BufferedReader( null == charset? new InputStreamReader(stream): new InputStreamReader(stream,charset))
                    .lines()
                    .collect( Collectors.joining("\n"))
                    .trim();
            if ( LOG.isDebugEnabled()) {
                LOG.debug("    HTTP Response Entity:");
                LOG.debug("      " + entity);
            }
            if ( 0 == contentType.trim().length()) {
//                throw new XoClientException( CONTENT_TYPE_HEADER_NAME + " result header value is EMPTY.");
            } else if ( !APPLICATION_JSON.equals( contentType.toLowerCase())) {
//                throw new XoClientException( CONTENT_TYPE_HEADER_NAME + " result header value is not <" + APPLICATION_JSON + ">");
            }

             http://www.iana.org/assignments/media-types/media-types.xhtml
            switch ( contentType.toLowerCase()) {
                case TEXT_HTML:
                    result.entity = Entity.html( entity);
                    break;
                case TEXT_XHTML:
                case APPLICATION_XHTML_XML:
                    result.entity = Entity.xhtml( entity);
                    break;
                case TEXT_XML:
                case APPLICATION_XML:
                    result.entity = Entity.xml( entity);
                    break;
                case APPLICATION_JSON:
                    result.entity = Entity.json( entity);
                    break;
                case TEXT_PLAIN:
                default:
                    result.entity = Entity.text( entity);
            }
            populateResponse( result, http);
        }
        http.disconnect();
        return result;
    }

    private static String headerFirstValue( HttpURLConnection httpURLConnection, String headerName) {
        return httpURLConnection.getHeaderField( headerName);
    }

    private static void populateResponse(ClientResponse result, HttpURLConnection httpURLConnection) throws IOException {
        result.reasonPhrase      = httpURLConnection.getResponseMessage();
        result.status            = httpURLConnection.getResponseCode();
        final String etagHeader  = headerFirstValue( httpURLConnection, ETAG_HEADER_NAME);
        result.etagHeader        = null != etagHeader? new EntityTag(etagHeader): null;
        final String dateHeader  = headerFirstValue( httpURLConnection, DATE_HEADER_NAME);
        try {
            result.dateHeader    = null != dateHeader? rfc7231dateFormat.parse( dateHeader ): null;
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        final String lastModifiedHeader  = headerFirstValue( httpURLConnection, LAST_MODIFIED_HEADER_NAME);
        try {
            result.lastModifiedHeader = null != lastModifiedHeader? rfc7231dateFormat.parse( lastModifiedHeader ): null;
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        final String allowHeader = headerFirstValue( httpURLConnection, ALLOW_HEADER_NAME);
        if ( null != allowHeader && 0 < allowHeader.trim().length()) {
            for ( String allowMehod: allowHeader.split(",")) {
                result.allowedMethods.add( allowMehod.trim());
            }
        }
        Map<String,List<String>> headers = httpURLConnection.getHeaderFields();
        if ( null != headers && 0 < headers.size()) {
            for ( Map.Entry<String,List<String>> header: headers.entrySet()) {
                result.headers.add( header.getKey(), header.getValue().get(0));
            }
        }
    }

}
