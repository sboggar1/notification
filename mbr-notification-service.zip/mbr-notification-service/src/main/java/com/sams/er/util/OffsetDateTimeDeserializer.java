package com.sams.er.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;

public class OffsetDateTimeDeserializer extends StdDeserializer<OffsetDateTime> {
    ZoneOffset DEFAULT_ZONE_OFFSET = ZoneOffset.UTC;
    public OffsetDateTimeDeserializer(){
        this(null);
    }

    protected OffsetDateTimeDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public OffsetDateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        String currentFieldName = jsonParser.getCurrentName();
        String parentName = jsonParser.getParsingContext().getParent().getCurrentName();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        String value = jsonParser.getValueAsString();
        OffsetDateTime offsetDateTime = null;
        Date parsedTimeStamp = null;
        Timestamp timestamp = null;

        if (null == value) {
            return null;
        }

        try {
            offsetDateTime = OffsetDateTime.parse(value, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            /*if (jsonParser.getCurrentName().equals("paymentTimestamp") || jsonParser.getCurrentName().equals("authorizationTimestamp")){
                offsetDateTime = OffsetDateTime.parse(value, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            } else if(currentFieldName.equals("createddate") || (currentFieldName.equals("createdDate") && (null != parentName) && parentName.equals("paymentinfo"))) {
                offsetDateTime = offsetDateTime.parse(value, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } else if (currentFieldName.equals("lastUpdateTimeStamp")) {
                offsetDateTime = OffsetDateTime.ofInstant(Instant.ofEpochSecond(jsonParser.getValueAsLong()),DEFAULT_ZONE_OFFSET);;
            } else {
                parsedTimeStamp = dateFormat.parse(value);
                timestamp = new Timestamp(parsedTimeStamp.getTime());
                offsetDateTime = OffsetDateTime.ofInstant(timestamp.toInstant(), DEFAULT_ZONE_OFFSET);
            }*/
            return offsetDateTime;
        }
        catch(Exception e){
            return null;
        }
    }
}

