package com.sams.er.client.eai.mappings;

public class TransactionData {

    private Integer transactionId;

    private Integer registerNumber;

    private String tcNumber;

    private String createdDate;

    private String modifiedDate;

    private String submittedTime;

    private String clientApp;

    private String deviceId;

    private IsdTotalTax isdTotalTax;

    private PurchaseContractTotals purchaseContractTotals;

    private String orderHistory;

    private TransactionLocation transactionLocation;

    public String getOrderHistory() {
        return orderHistory;
    }

    public void setOrderHistory(String orderHistory) {
        this.orderHistory = orderHistory;
    }

    public Integer getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }

    public Integer getRegisterNumber() {
        return registerNumber;
    }

    public void setRegisterNumber(Integer registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getTcNumber() {
        return tcNumber;
    }

    public void setTcNumber(String tcNumber) {
        this.tcNumber = tcNumber;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getSubmittedTime() {
        return submittedTime;
    }

    public void setSubmittedTime(String submittedTime) {
        this.submittedTime = submittedTime;
    }

    public String getClientApp() {
        return clientApp;
    }

    public void setClientApp(String clientApp) {
        this.clientApp = clientApp;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public IsdTotalTax getIsdTotalTax() {
        return isdTotalTax;
    }

    public void setIsdTotalTax(IsdTotalTax isdTotalTax) {
        this.isdTotalTax = isdTotalTax;
    }

    public PurchaseContractTotals getPurchaseContractTotals() {
        return purchaseContractTotals;
    }

    public void setPurchaseContractTotals(PurchaseContractTotals purchaseContractTotals) {
        this.purchaseContractTotals = purchaseContractTotals;
    }

    public TransactionLocation getTransactionLocation() {
        return transactionLocation;
    }

    public void setTransactionLocation(TransactionLocation transactionLocation) {
        this.transactionLocation = transactionLocation;
    }
}
