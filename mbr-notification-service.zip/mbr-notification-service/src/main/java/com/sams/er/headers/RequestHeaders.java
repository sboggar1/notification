package com.sams.er.headers;

import org.springframework.web.bind.annotation.RequestHeader;

import javax.validation.constraints.NotNull;
import javax.ws.rs.HeaderParam;

public class RequestHeaders {

    public static final String CPC_TOKEN="cpc_token";

    public static final String CPC_CLIENT_APP = "cps_clientApp";


    private String cpcToken;


    private String cpcClientApp;

    @HeaderParam("Content-Type")
    private String contentType;

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getCpcToken() {
        return cpcToken;
    }

    @HeaderParam("cpc_token")
    public void setCpcToken(String cpcToken) {
        this.cpcToken = cpcToken;
    }

    @HeaderParam("cps_clientApp")
    public String getCpcClientApp() {
        return cpcClientApp;
    }

    public void setCpcClientApp(String cpcClientApp) {
        this.cpcClientApp = cpcClientApp;
    }
}
