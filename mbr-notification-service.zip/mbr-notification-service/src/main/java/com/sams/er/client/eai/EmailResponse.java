package com.sams.er.client.eai;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EmailResponse {

    @JsonProperty("EAIResponse")
    @JsonInclude(Include.NON_NULL)
    private EAIResponse eaiResponse;

    @JsonProperty("notificationServiceResponse")
    @JsonInclude(Include.NON_NULL)
    private EAIResponse notificationServiceResponse;

    public EAIResponse getEaiResponse() {
        return eaiResponse;
    }

    public void setEaiResponse(EAIResponse eaiResponse) {
        this.eaiResponse = eaiResponse;
    }

    public EAIResponse getNotificationServiceResponse() {
        return notificationServiceResponse;
    }

    public void setNotificationServiceResponse(EAIResponse notificationServiceResponse) {
        this.notificationServiceResponse = notificationServiceResponse;
    }
}
