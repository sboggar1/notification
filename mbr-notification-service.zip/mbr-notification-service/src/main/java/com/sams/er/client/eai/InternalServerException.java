package com.sams.er.client.eai;

/**
 * General Checkout Service Exception
 * @author VN90514
 * Created on 03/24/2021.
 */
public class InternalServerException extends RuntimeException {

    public InternalServerException(String message) {
        super( message);
    }

    public InternalServerException(String message, Throwable throwable) {
        super( message, throwable);
    }

    public InternalServerException(Throwable throwable) {
        super( throwable);
    }

}
