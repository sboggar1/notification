package com.sams.er.client.eai;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EAIResponse {
    @JsonProperty("StatusCode")
    private String statusCode;

    @JsonProperty("StatusDesc")
    private String StatusDesc;

    public String getStatusDesc() {
        return StatusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        StatusDesc = statusDesc;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
