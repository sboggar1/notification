package com.sams.er.response;

import java.util.ArrayList;
import java.util.List;

public class StatusResponse<T, E extends com.sams.er.response.RestError> {

    private String name;

    private String message;

    private T data;

    private List<E> validationErrors;

    public StatusResponse() {
    }

    public StatusResponse(T data) {
        this.data = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<E> getValidationErrors() {
        return validationErrors;
    }

    public void setValidationErrors(List<E> validationErrors) {
        this.validationErrors = validationErrors;
    }

    public void addError(E error) {

        if (validationErrors == null) {
            validationErrors = new ArrayList<>();
        }

        validationErrors.add(error);
    }
}
