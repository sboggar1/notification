package com.sams.er.models.cash;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class CashRedemptionNotification {

    @JsonProperty("email_recipients")
    private List<String> emailRecipients;

    @JsonProperty("template_id")
    private String templateId;

    @JsonProperty("source")
    private String source;

    @JsonProperty("data")
    private CashNotificationData data;

    public List<String> getEmailRecipients() {
        return emailRecipients;
    }

    public void setEmailRecipients(List<String> emailRecipients) {
        this.emailRecipients = emailRecipients;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public CashNotificationData getData() {
        return data;
    }

    public void setData(CashNotificationData data) {
        this.data = data;
    }
}
