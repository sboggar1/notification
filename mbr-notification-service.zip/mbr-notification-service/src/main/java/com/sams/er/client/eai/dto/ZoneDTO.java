package com.sams.er.client.eai.dto;

public class ZoneDTO {

    private CurrentDTO current;

    private NextDTO next;

    private Boolean hasDST;

    public CurrentDTO getCurrent() {
        return current;
    }

    public void setCurrent(CurrentDTO current) {
        this.current = current;
    }

    public NextDTO getNext() {
        return next;
    }

    public void setNext(NextDTO next) {
        this.next = next;
    }

    public Boolean getHasDST() {
        return hasDST;
    }

    public void setHasDST(Boolean hasDST) {
        this.hasDST = hasDST;
    }
}
