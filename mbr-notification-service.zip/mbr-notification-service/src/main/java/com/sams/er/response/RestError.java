package com.sams.er.response;

import com.sams.er.constants.ErrorEnum;

public class RestError {

    private String code;
    private String message;
    private String detailedMessage;


    public RestError(ErrorEnum errorEnum) {
        this.code = errorEnum.getCode();
        this.message = errorEnum.getMessage();
    }


    public RestError(ErrorEnum errorEnum, Throwable ex) {
        this.code = errorEnum.getCode();
        this.message = errorEnum.getMessage();
        this.detailedMessage = ex.getLocalizedMessage();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetailedMessage() {
        return detailedMessage;
    }

    public void setDetailedMessage(String detailedMessage) {
        this.detailedMessage = detailedMessage;
    }
}
