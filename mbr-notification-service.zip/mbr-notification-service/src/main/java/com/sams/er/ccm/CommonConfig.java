package com.sams.er.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;

public interface CommonConfig {

    String getXoUrl();

    String getOeUrl();

    String getConsumerId();

    String getCpcOEToken();

    String getEaiMailrouterProxyUrl();

    String getEaiPrivateKey();

    String getEaiPublicKey();

    String getSamsClubhoursUrl();

    String getSamsDirectionUrl();

    String getSamsOrderhistoryUrl();

    Integer getServiceTimeout();

    String getNextgenEAIProxyUrl();
}
