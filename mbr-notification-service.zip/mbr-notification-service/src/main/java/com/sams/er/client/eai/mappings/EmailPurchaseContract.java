package com.sams.er.client.eai.mappings;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sams.er.client.eai.mappings.Item;
import com.sams.er.client.eai.mappings.Payment;
import com.sams.er.client.eai.mappings.TransactionData;

import java.math.BigDecimal;
import java.util.List;

public class EmailPurchaseContract {

    private Integer itemCount;

    private List<Item> items;

    private List<Payment> payments;

    private TransactionData transactionData;

    public Integer getItemCount() {
        return itemCount;
    }

    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public List<Payment> getPayments() {
        return payments;
    }

    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    public TransactionData getTransactionData() {
        return transactionData;
    }

    public void setTransactionData(TransactionData transactionData) {
        this.transactionData = transactionData;
    }
}
