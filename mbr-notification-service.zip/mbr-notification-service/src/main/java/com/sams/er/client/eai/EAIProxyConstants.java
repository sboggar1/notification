package com.sams.er.client.eai;

public class EAIProxyConstants {
    public static final String WM_CONSUMER_ID = "WM_CONSUMER.ID";
    public static final String WM_CONSUMER_INTIMESTAMP = "WM_CONSUMER.INTIMESTAMP";
    public static final String WM_SEC_KEY_VERSION = "WM_SEC.KEY_VERSION";
    public static final String WM_SEC_AUTH_SIGNATURE = "WM_SEC.AUTH_SIGNATURE";
    public static final String WM_QOS_CORRELATION_ID = "WM_QOS.CORRELATION_ID";
    public static final String WM_SVC_NAME = "WM_SVC.NAME";
    public static final String WM_SVC_ENV = "WM_SVC.ENV";
    public static final String CPC_TOKEN = "CPC_TOKEN";
    public static final String X_TB_DEBUG = "x-tb-debug";
    public static final String ONE = "1";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String APPLICATION_JSON = "application/json";
    public static final String CONSUMER_ID = "CONSUMER-ID";
    public static final String TOKEN = "CPC-OE-TOKEN";
    public static final String PRIVATE_KEY = "PRIVATE-KEY";
    public static final String SEC_KEY_VERSION = "1";
    public static final int CRON_TIME = 271000;
}
