package com.sams.er.config;

import com.sams.er.ccm.CCMConfigs;
import com.sams.er.ccm.CommonConfig;
import com.sams.er.client.checkout.XoClient;
import com.sams.er.client.eai.EAIProxyClient;
import com.sams.er.client.eai.EAIProxyHelper;
import com.sams.er.client.oe.OEClient;
import com.sams.er.vault.NextgenEaiProperties;
import com.sams.er.vault.VaultData;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class AppConfig
{
    @Bean
    public static PropertyPlaceholderConfigurer getPropertyPlaceholderConfigurer()
    {
        PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
        ppc.setIgnoreUnresolvablePlaceholders(true);
        return ppc;
    }

    @Bean(name = "eaiClient")
    public EAIProxyClient eaiClient() {
        return new EAIProxyClient();
    }

    @ManagedConfiguration
    private CommonConfig ccmConfigs;

    @Bean(name = "eaiProxyHelper")
    public EAIProxyHelper eaiProxyHelper(VaultData vaultData, NextgenEaiProperties nextgenEaiProperties) {
        return new EAIProxyHelper(ccmConfigs, vaultData, nextgenEaiProperties);
    }

    @Bean(name= "checkoutClient")
    public XoClient checkoutClient() {
        return new XoClient();
    }

    @Bean(name="cpcOEClient")
    public OEClient CpcOEClient() {
        return new OEClient();

    }
}