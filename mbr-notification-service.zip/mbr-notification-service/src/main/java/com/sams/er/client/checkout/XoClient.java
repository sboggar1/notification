package com.sams.er.client.checkout;

import com.sams.er.ccm.CCMConfigs;
import com.sams.er.ccm.CommonConfig;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.services.checkout.commons.dto.RequestParams;
import com.walmart.services.checkout.commons.dto.response.GetPurchaseContractResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

public class XoClient {

    private static final Logger LOG = LoggerFactory.getLogger(XoClient.class);

    static final String ROOT_PATH = "/checkoutservice/v1/purchasecontracts";

    /*@Value("${xo.url}")
    private String xoUrl;*/

    @ManagedConfiguration
    private CommonConfig ccmConfigs;

    public static class Builder {}

        @FunctionalInterface
        interface SupplierThrowingIO<T> {
            T getWithIO() throws IOException;
        }

        private Map<String, Object> populateHeaders(RequestParams requestParams) {
            final Map<String, Object> headers = new HashMap<>();
            // headers.put( XoClientHelper.CONTENT_TYPE_HEADER_NAME, XoClientHelper.APPLICATION_JSON);
            headers.put("GEO_ID", requestParams.getGeoId());
            headers.put("BUSINESS_ID", requestParams.getBusinessId());
            headers.put("CHANNEL_ID", requestParams.getChannelId());
            return headers;
        }

        public ServiceResponse<GetPurchaseContractResponse> get(UUID id) throws XoClientException {
            try {
                final Map<String, Object> headers = new HashMap<>();
                headers.put(ClientHelper.CONTENT_TYPE_HEADER_NAME, ClientHelper.APPLICATION_JSON);
                headers.put("GEO_ID", "0");
                headers.put("BUSINESS_ID", "0");
                headers.put("CHANNEL_ID", "0");
                // final TimeUnit timeoutUnit = TimeUtil.asTimeUnit(String.valueOf(config.timeoutUnit()));
                final String path = ccmConfigs.getXoUrl() + ROOT_PATH + '/' + id.toString();
                URL url = new URI(path).toURL();
                // int timeout = (int) config.timeout();
                int timeout = 0;
                Response response = 0 == timeout ? ClientHelper.getJson(url, headers)
                        //: Executors.newSingleThreadExecutor().submit(( ) -> { // Spring 3 Framework doesn't support Java 8 features
                        : Executors.newSingleThreadExecutor().submit(new Callable<Response>() {
                    @Override
                    public Response call() throws Exception {
                        return ClientHelper.getJson(url, headers);
                    }
                }).get(timeout, TimeUnit.MILLISECONDS);
                Response.Status status = Response.Status.fromStatusCode(response.getStatus());
                switch (status) {
                    case OK:
                        break;
                    default:
                        throw new XoClientWebException
                                (status.getStatusCode()
                                        , status.getReasonPhrase()
                                        , response.hasEntity() ? response.readEntity(String.class) : "");
                }
                if (response.hasEntity()) {
                    ServiceResponse<GetPurchaseContractResponse> result = response.readEntity(new GenericType<ServiceResponse<GetPurchaseContractResponse>>() {
                    });
                    return result;
                } else {
                    throw new XoClientWebException(Response.Status.NO_CONTENT.getStatusCode()
                            , Response.Status.NO_CONTENT.getReasonPhrase()
                            , ""
                    );
                }
            } catch (TimeoutException e) {
                throw new XoClientTimeoutException();
            } catch (XoClientException e) {
                throw e;
            } catch (IllegalArgumentException | IOException | URISyntaxException | InterruptedException | ExecutionException e) {
                throw new XoClientException(e);
            }
        }
}
