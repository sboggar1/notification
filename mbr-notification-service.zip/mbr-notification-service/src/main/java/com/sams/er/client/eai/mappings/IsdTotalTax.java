package com.sams.er.client.eai.mappings;

import java.math.BigDecimal;
import java.util.List;

public class IsdTotalTax {

    private BigDecimal totalTaxAmount;

    private List<TaxRateBracket> taxRateBracket;

    public BigDecimal getTotalTaxAmount() {
        return totalTaxAmount;
    }

    public void setTotalTaxAmount(BigDecimal totalTaxAmount) {
        this.totalTaxAmount = totalTaxAmount;
    }

    public List<TaxRateBracket> getTaxRateBracket() {
        return taxRateBracket;
    }

    public void setTaxRateBracket(List<TaxRateBracket> taxRateBracket) {
        this.taxRateBracket = taxRateBracket;
    }


}
