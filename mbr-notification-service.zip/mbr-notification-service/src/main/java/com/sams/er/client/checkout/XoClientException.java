package com.sams.er.client.checkout;

/**
 * General Checkout Service Exception
 * @author VN90514
 * Created on 03/24/2021.
 */
public class XoClientException extends RuntimeException {

    public XoClientException(String message) {
        super( message);
    }

    public XoClientException(String message, Throwable throwable) {
        super( message, throwable);
    }

    public XoClientException(Throwable throwable) {
        super( throwable);
    }

}
