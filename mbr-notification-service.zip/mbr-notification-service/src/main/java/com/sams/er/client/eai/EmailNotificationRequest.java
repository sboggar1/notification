package com.sams.er.client.eai;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EmailNotificationRequest {

    @JsonProperty("notification")
    private Email email;

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }
}
