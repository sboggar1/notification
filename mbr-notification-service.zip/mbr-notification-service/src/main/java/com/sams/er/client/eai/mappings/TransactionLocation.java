package com.sams.er.client.eai.mappings;

import com.sams.er.client.eai.dto.AddressDTO;
import com.sams.er.client.eai.dto.StoreLocationDTO;
import com.sams.er.client.oe.mappings.Address;
import com.sams.er.client.oe.mappings.StoreInformation;
import com.sams.er.client.oe.mappings.StoreLocation;

public class TransactionLocation {

    /*private String postalCode;

    private String city;

    private String stateOrProvinceCode;

    private String countryCode;

    private String storeId;

    private String streetAddress;*/

    private Integer storeId;

    private String storePhoneNumber;

    private StoreInformation storeInformation;

    private AddressDTO storeAddress;

    private StoreLocationDTO storeCoordinates;

    public String getStorePhoneNumber() {
        return storePhoneNumber;
    }

    public void setStorePhoneNumber(String storePhoneNumber) {
        this.storePhoneNumber = storePhoneNumber;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public StoreInformation getStoreInformation() {
        return storeInformation;
    }

    public void setStoreInformation(StoreInformation storeInformation) {
        this.storeInformation = storeInformation;
    }

    public AddressDTO getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(AddressDTO storeAddress) {
        this.storeAddress = storeAddress;
    }

    public StoreLocationDTO getStoreCoordinates() {
        return storeCoordinates;
    }

    public void setStoreCoordinates(StoreLocationDTO storeCoordinates) {
        this.storeCoordinates = storeCoordinates;
    }
}
