package com.sams.er.models.cash;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CashRedemptionEAIRequest {
    @JsonProperty("notification")
    private CashRedemptionNotification cashRedemptionNotification;

    public CashRedemptionNotification getCashRedemptionNotification() {
        return cashRedemptionNotification;
    }

    public void setCashRedemptionNotification(CashRedemptionNotification cashRedemptionNotification) {
        this.cashRedemptionNotification = cashRedemptionNotification;
    }
}
