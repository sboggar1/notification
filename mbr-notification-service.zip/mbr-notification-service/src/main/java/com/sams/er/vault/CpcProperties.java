package com.sams.er.vault;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "cpc")
public class CpcProperties {

    private String oeToken;

    public String getOeToken() {
        return oeToken;
    }

    public void setOeToken(String oeToken) {
        this.oeToken = oeToken;
    }
}
