package com.sams.er.constants;

public class AppConstants {

    public static final String TRUE = "true";
    public static final String HEALTH_CHECK = "Health Check";
    public static final String RUNNING = "Is Running";
    public static final String EMAIL_RECEIPTS_SERVICE = "Email Receipts Service";
    public static final String FALSE = "false";

    public static final String HEADER_STORE_NUMBER = "sams-consumer-club-number";
    public static final String HEADER_COUNTRY_CODE = "sams-consumer-country-code";
    public static final String HEADER_CPC_TOKEN = "cpc_token";
}
