package com.sams.er.client.checkout;

/**
 * Checkout Service Timeout Exception
 * @author vn90514
 * Created on 03/24/2021.
 */
public class XoClientTimeoutException extends XoClientException {

    public XoClientTimeoutException() {
        super("Checkout Timeout");
    }

}
