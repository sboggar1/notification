package com.sams.er.client.checkout;

/**
 * Checkout Http Exception
 * @author vn90514
 * Created on 03/24/2021.
 */
public class XoClientWebException extends XoClientException {

    private int code;
    private String reason;
    public int getCode() { return code;}
    public String getReason() {return reason;}

    public XoClientWebException(int code, String reason, String message) {
        super( message);
        this.code   = code;
        this.reason = reason;
    }

    public XoClientWebException(int code, String reason, String message, Throwable throwable) {
        super( message, throwable);
        this.code   = code;
        this.reason = reason;
    }

}
