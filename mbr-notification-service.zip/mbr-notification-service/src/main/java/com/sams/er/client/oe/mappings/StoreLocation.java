package com.sams.er.client.oe.mappings;

//import com.walmartstores.xmlns.demandchain.offerservices.datatypes.redeemoffers._1.TimeZone;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
        name = "storeLocation",
        propOrder = {"timeZone", "latitude", "longitude"}
)
@XmlRootElement(
        name = "storeLocation"
)
public class StoreLocation {

    private StoreTimeZone timeZone;
  //  private TimeZone timeZone;

    protected BigDecimal latitude;

    protected BigDecimal longitude;

    public StoreTimeZone getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(StoreTimeZone timeZone) {
        this.timeZone = timeZone;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}
