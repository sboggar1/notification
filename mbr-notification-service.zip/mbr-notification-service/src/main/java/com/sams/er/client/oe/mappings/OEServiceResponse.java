package com.sams.er.client.oe.mappings;

import com.walmart.platform.kernel.exception.error.Error;
import com.walmart.platform.soa.common.service.wrappers.ServiceHeader;
import com.walmart.platform.soa.common.service.wrappers.Status;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
        name = "ServiceResponse",
        propOrder = {"status", "timezone"}
)
@XmlRootElement(
        name = "ServiceResponse"
)
public class OEServiceResponse<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    @XmlElement(
            name = "status",
            required = true
    )
    private Status status;
    private T timezone;

    public OEServiceResponse() {
        this.status = Status.FAIL;
    }

    public OEServiceResponse(ServiceHeader header, T timezone) {
        this.status = Status.FAIL;
        this.timezone = timezone;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public T getTimezone() {
        return timezone;
    }

    public void setTimezone(T timezone) {
        this.timezone = timezone;
    }

    public String toString() {
        return "OEServiceResponse [status=" + this.status + ", timezone=" + this.timezone + "]";
    }
}

