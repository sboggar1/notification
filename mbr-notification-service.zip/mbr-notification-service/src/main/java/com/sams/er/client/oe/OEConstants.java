package com.sams.er.client.oe;

public class OEConstants {

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String APPLICATION_JSON = "application/json";
    public static final String CPC_TOKEN = "CPC_TOKEN";
}
