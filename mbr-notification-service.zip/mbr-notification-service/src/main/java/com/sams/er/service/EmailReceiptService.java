package com.sams.er.service;

import com.sams.er.client.eai.EmailResponse;
import com.sams.er.headers.RequestHeaders;
import java.util.Map;

public interface EmailReceiptService {
    //EmailResponse processEmailCall(ServiceResponse purchaseContractRequest);
    EmailResponse processEmailCall(String purchaseContractRequest, RequestHeaders requestHeaders);
    EmailResponse processCashRedemptionEmail(String cashRedemptionBody, Map<String, String> requestHeaders);
}
