package com.sams.er.util.constants;

public enum EmailTemplate {
    CPPOS_RECEIPT;
}
