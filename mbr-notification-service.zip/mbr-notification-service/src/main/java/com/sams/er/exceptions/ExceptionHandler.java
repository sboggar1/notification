package com.sams.er.exceptions;

import com.sams.er.client.ERBadRequestException;
import com.sams.er.client.checkout.XoClientException;
import com.sams.er.client.checkout.XoClientWebException;
import com.sams.er.client.eai.EAIBadRequestException;
import com.sams.er.client.eai.EAIClientException;
import com.sams.er.client.eai.InternalServerException;
import com.sams.er.client.oe.OEBadRequestException;
import com.sams.er.client.oe.OECientException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {

    @org.springframework.web.bind.annotation.ExceptionHandler(EAIBadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Map<String,String> showCustomMessage400(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","01");
        response.put("StatusDesc","Email not sent, Bad Request");

        return response;
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(EAIClientException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    Map<String,String> showCustomMessage500(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","02");
        response.put("StatusDesc","Email not sent, Some thing went wrong calling Email Service");

        return response;
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(OEBadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Map<String,String> showBadRequestMessage400(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","03");
        response.put("StatusDesc","Email not sent, Bad Request for calling OE/StoreConfig");

        return response;
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(OECientException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    Map<String,String> showClientException500(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","04");
        response.put("StatusDesc","Email not sent, Some thing went wrong calling OE/StoreConfig Service");

        return response;
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(InternalServerException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    Map<String,String> showInternalServerException500(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","05");
        response.put("StatusDesc","Email not sent, Some thing went wrong. Internal Server Exception");

        return response;
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(ERBadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Map<String,String> showERBadRequestException400(){


        Map<String,String> response = new HashMap<>();
        response.put("StatusCode","06");
        response.put("StatusDesc","Email not sent, Bad Request. Purchase Contract is not in SUBMITTED status.");

        return response;
    }

}
