package com.sams.er.client.eai.mappings;

import java.math.BigDecimal;

public class PurchaseContractTotals {

    private BigDecimal subTotal;

    private BigDecimal discountEligibleSubTotal;

    private BigDecimal savingsTotal;

    private BigDecimal discountedSubTotal;

    private BigDecimal taxTotal;

    private BigDecimal grandTotal;

    private BigDecimal productFee;

    public BigDecimal getProductFee() {
        return productFee;
    }

    public void setProductFee(BigDecimal productFee) {
        this.productFee = productFee;
    }

    public BigDecimal getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(BigDecimal subTotal) {
        this.subTotal = subTotal;
    }

    public BigDecimal getDiscountEligibleSubTotal() {
        return discountEligibleSubTotal;
    }

    public void setDiscountEligibleSubTotal(BigDecimal discountEligibleSubTotal) {
        this.discountEligibleSubTotal = discountEligibleSubTotal;
    }

    public BigDecimal getSavingsTotal() {
        return savingsTotal;
    }

    public void setSavingsTotal(BigDecimal savingsTotal) {
        this.savingsTotal = savingsTotal;
    }

    public BigDecimal getDiscountedSubTotal() {
        return discountedSubTotal;
    }

    public void setDiscountedSubTotal(BigDecimal discountedSubTotal) {
        this.discountedSubTotal = discountedSubTotal;
    }

    public BigDecimal getTaxTotal() {
        return taxTotal;
    }

    public void setTaxTotal(BigDecimal taxTotal) {
        this.taxTotal = taxTotal;
    }

    public BigDecimal getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(BigDecimal grandTotal) {
        this.grandTotal = grandTotal;
    }
}
