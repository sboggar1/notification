package com.sams.er.client.oe;

import com.sams.er.client.oe.mappings.StoreManager;
import com.sams.er.client.oe.mappings.StoreLocation;
import com.sams.er.client.oe.mappings.TimeZone;
import com.sams.er.client.oe.mappings.TimeZoneRoot;
import com.walmart.cpc.store.config.dto.Address;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
        name = "ServiceResponse",
        propOrder = {"statusCode", "timezone", "storeTypeCode", "storeSubType", "countryCode", "storeNumber", "storeTypeCode", "storeDescription", "address", "manager" }
)
@XmlRootElement(
        name = "StoreConfigResponse"
)
public class StoreConfigResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    //private StoreConfig storeConfig;

    private Integer statusCode;

    private StoreLocation storeLocation;

    private String storeSubType;

    private String countryCode;

    private Integer storeNumber;

    private Integer storeTypeCode;

    private String storeDescription;

    private Address address;

    private TimeZone timezone;

    private StoreManager manager;

    public StoreManager getManager() {
        return manager;
    }

    public void setManager(StoreManager manager) {
        this.manager = manager;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public StoreLocation getStoreLocation() {
        return storeLocation;
    }

    public void setStoreLocation(StoreLocation storeLocation) {
        this.storeLocation = storeLocation;
    }

    public String getStoreSubType() {
        return storeSubType;
    }

    public void setStoreSubType(String storeSubType) {
        this.storeSubType = storeSubType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Integer getStoreNumber() {
        return storeNumber;
    }

    public void setStoreNumber(Integer storeNumber) {
        this.storeNumber = storeNumber;
    }

    public Integer getStoreTypeCode() {
        return storeTypeCode;
    }

    public void setStoreTypeCode(Integer storeTypeCode) {
        this.storeTypeCode = storeTypeCode;
    }

    public String getStoreDescription() {
        return storeDescription;
    }

    public void setStoreDescription(String storeDescription) {
        this.storeDescription = storeDescription;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public TimeZone getTimezone() {
        return timezone;
    }

    public void setTimezone(TimeZone timezone) {
        this.timezone = timezone;
    }
}
