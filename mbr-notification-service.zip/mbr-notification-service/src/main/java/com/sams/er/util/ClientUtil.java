package com.sams.er.util;

import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;

public class ClientUtil {

    public static void updateStringMap(Map<String, String> map, String key, String value) {
        if(ObjectUtils.allNotNull(map, key, value)) {
            map.put(key, value);
        }
    }

    public static void updateMap(Map<String, Object> map, String key, Object value) {
        if(ObjectUtils.allNotNull(map, key, value)) {
            map.put(key, value);
        }
    }

}
