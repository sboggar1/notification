package com.sams.er.client.oe.mappings;

public class StoreInformation {

    private String storeOpensAt;

    private String storeClosesAt;
    private String store;




}
