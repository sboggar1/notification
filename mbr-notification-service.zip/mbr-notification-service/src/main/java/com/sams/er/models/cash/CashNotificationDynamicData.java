package com.sams.er.models.cash;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CashNotificationDynamicData {
    @JsonProperty("username")
    private String userName;

    @JsonProperty("redeemed_amount")
    private String redeemedAmount;

    @JsonProperty("transaction_datetime")
    private String transactionDateTime;

    @JsonProperty("club_name")
    private String clubName;

    @JsonProperty("club_addressline1")
    private String clubAddressLine1;

    @JsonProperty("club_city")
    private String clubCity;

    @JsonProperty("club_state")
    private String clubState;

    @JsonProperty("club_zipcode")
    private String clubZipCode;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRedeemedAmount() {
        return redeemedAmount;
    }

    public void setRedeemedAmount(String redeemedAmount) {
        this.redeemedAmount = redeemedAmount;
    }

    public String getTransactionDateTime() {
        return transactionDateTime;
    }

    public void setTransactionDateTime(String transactionDateTime) {
        this.transactionDateTime = transactionDateTime;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getClubAddressLine1() {
        return clubAddressLine1;
    }

    public void setClubAddressLine1(String clubAddressLine1) {
        this.clubAddressLine1 = clubAddressLine1;
    }

    public String getClubCity() {
        return clubCity;
    }

    public void setClubCity(String clubCity) {
        this.clubCity = clubCity;
    }

    public String getClubState() {
        return clubState;
    }

    public void setClubState(String clubState) {
        this.clubState = clubState;
    }

    public String getClubZipCode() {
        return clubZipCode;
    }

    public void setClubZipCode(String clubZipCode) {
        this.clubZipCode = clubZipCode;
    }
}
