package com.sams.er.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;

@Configuration(configName = "commonConfig")
public interface CCMConfigs {

    //@Property(propertyName = "xo.url")
    @Property(propertyName = "xoUrl")
    String getXoUrl();

    //@Property(propertyName = "oe.url")
    @Property(propertyName = "oeUrl")
    String getOeUrl();

    //@Property(propertyName = "consumerid")
    @Property(propertyName = "consumerId")
    String getConsumerId();

    //@Property(propertyName = "cpc.oe.token")
    @Property(propertyName = "cpcOeToken")
    String getCpcOEToken();

    //@Property(propertyName = "eai.mailrouter.proxy.url")
    @Property(propertyName = "eaiMailrouterProxyUrl")
    String getEaiProxyUrl();

    //@Property(propertyName = "eai.privateKey")
    @Property(propertyName = "eaiPrivateKey")
    String getEaiPrivateKey();

    //@Property(propertyName = "eai.publickey")
    @Property(propertyName = "eaiPublickey")
    String getEaiPublicKey();

    //@Property(propertyName = "sams.clubhours.url")
    @Property(propertyName = "samsClubhoursUrl")
    String getClubHoursEndpoint();

    //@Property(propertyName = "sams.direction.url")
    @Property(propertyName = "samsDirectionUrl")
    String getClubDirectionsEndPoint();

    //@Property(propertyName = "sams.orderhistory.url")
    @Property(propertyName = "samsOrderhistoryUrl")
    String getOrderHistoryEndpoint();

    //@Property(propertyName = "service.timeout" )
    @Property(propertyName = "serviceTimeout" )
    Integer getServiceTimeout();

    @Property(propertyName = "eai.nextgen.proxy.url" )
    String getNextgenEAIProxyUrl();
}
