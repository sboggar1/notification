package com.sams.er.client.eai.mappings;

import java.math.BigDecimal;

public class TaxRateBracket {

    private String taxCode;

    private BigDecimal bracketAmount;

    private String taxRateId;

    private BigDecimal taxRateAmount;

    private String taxRateAmountType;

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public BigDecimal getBracketAmount() {
        return bracketAmount;
    }

    public void setBracketAmount(BigDecimal bracketAmount) {
        this.bracketAmount = bracketAmount;
    }

    public String getTaxRateId() {
        return taxRateId;
    }

    public void setTaxRateId(String taxRateId) {
        this.taxRateId = taxRateId;
    }

    public BigDecimal getTaxRateAmount() {
        return taxRateAmount;
    }

    public void setTaxRateAmount(BigDecimal taxRateAmount) {
        this.taxRateAmount = taxRateAmount;
    }

    public String getTaxRateAmountType() {
        return taxRateAmountType;
    }

    public void setTaxRateAmountType(String taxRateAmountType) {
        this.taxRateAmountType = taxRateAmountType;
    }
}
