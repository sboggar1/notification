package com.sams.er.client.eai.mappings;

import com.walmart.services.cxo.commons.api.enums.DiscountType;

import java.math.BigDecimal;

public class DiscountsApplied {

    private DiscountType discountType;

    private String savingType;

    private BigDecimal savingAmount;

    private BigDecimal totalSavings;

    private BigDecimal quantitiesApplied;

    public DiscountType getDiscountType() {
        return discountType;
    }

    public void setDiscountType(DiscountType discountType) {
        this.discountType = discountType;
    }

    public String getSavingType() {
        return savingType;
    }

    public void setSavingType(String savingType) {
        this.savingType = savingType;
    }

    public BigDecimal getSavingAmount() {
        return savingAmount;
    }

    public void setSavingAmount(BigDecimal savingAmount) {
        this.savingAmount = savingAmount;
    }

    public BigDecimal getTotalSavings() {
        return totalSavings;
    }

    public void setTotalSavings(BigDecimal totalSavings) {
        this.totalSavings = totalSavings;
    }

    public BigDecimal getQuantitiesApplied() {
        return quantitiesApplied;
    }

    public void setQuantitiesApplied(BigDecimal quantitiesApplied) {
        this.quantitiesApplied = quantitiesApplied;
    }
}
