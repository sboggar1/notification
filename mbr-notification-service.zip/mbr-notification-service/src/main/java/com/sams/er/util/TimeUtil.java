package com.sams.er.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Utility methods for dealing with time.
 * 
 * @author VN90514
 *
 */
public class TimeUtil {

    private static final Logger LOG = LoggerFactory.getLogger(TimeUtil.class);
    // private static final CpcPayLogger LOG = CpcPayLogger.createLogger(TimeUtil.class);

    public static long MILLIS_PER_SECOND = 1000;
    public static long MILLIS_PER_MINUTE = 60 * MILLIS_PER_SECOND;
    public static long MILLIS_PER_HOUR = 60 * MILLIS_PER_MINUTE;
    public static long MILLIS_PER_DAY = 24 * MILLIS_PER_HOUR;
    public static long NANOS_PER_MILLI = 1000000;

    @SuppressWarnings("serial")
    private Map<ChronoUnit, Long> chronoSizeMap = new HashMap<ChronoUnit, Long>() {
        {
            put(ChronoUnit.DAYS, MILLIS_PER_DAY);
            put(ChronoUnit.HOURS, MILLIS_PER_HOUR);
            put(ChronoUnit.MINUTES, MILLIS_PER_MINUTE);
            put(ChronoUnit.SECONDS, MILLIS_PER_SECOND);
            put(ChronoUnit.MILLIS, 1L);
        }
    };

    /**
     *
     * @param millis
     *            a time in milliseconds.
     *
     * @return The time in nanoseconds.
     */
    public long convertToNanos(long millis) {
        return millis * NANOS_PER_MILLI;
    }

    /**
     *
     * @param nanos
     *            a time in nanoseconds.
     *
     * @return The time in milliseconds
     */
    public long convertToMillis(long nanos) {
        return nanos / NANOS_PER_MILLI;
    }

    /**
     *
     * @return The current time in the Unix epoch milliseconds, GMT.
     */
    public long getCurrentUtcTime() {
        return System.currentTimeMillis();
    }

    /**
     * Note that the System.nanoTime() method is not based on an absolute fixed
     * time. This means that subsequent calls to this method may not return
     * monotonically increasing values. It is intended only to differentiate
     * events happening in less than 1 millisecond where it is desirable for
     * duplicate time values to be minimized.
     *
     * @return The current UTC time in nanoseconds.
     */
    public long getCurrentUtcTimeNanos() {
        return convertToNanos(getCurrentUtcTime()) + (System.nanoTime() % NANOS_PER_MILLI);
    }

    /**
     * @param bucketSizeMillis
     *            The size of the bucket in milliseconds.
     *
     * @return The current time in the Unix epoch milliseconds, GMT.
     */
    public long getCurrentTimeBucket(long bucketSizeMillis) {
        return this.truncateTimestamp(getCurrentUtcTime(), bucketSizeMillis);
    }

    /**
     * @param startBucketMillis
     *            The start bucket to increment.
     * @param bucketSizeMillis
     *            The size of the bucket in milliseconds.
     *
     * @return The current time in the Unix epoch milliseconds, GMT.
     */
    public long getNextTimeBucket(long startBucketMillis, long bucketSizeMillis) {
        return startBucketMillis + bucketSizeMillis;
    }

    /**
     * @param bucketSizeMillis
     *            The size of the bucket in milliseconds.
     * @param mulitplier
     *            The number of time buckets to go back.
     *
     * @return The current time in the Unix epoch milliseconds, GMT.
     */
    public long getPreviousTimeBucket(long bucketSizeMillis, int mulitplier) {
        return getCurrentTimeBucket(bucketSizeMillis) - mulitplier * bucketSizeMillis;
    }

    /**
     * Calculated the total time in milliseconds for the given chronoUnit and
     * multiplier. For example, given ChronoUnit.HOURS and multiplier = 2, the
     * result is the number of milliseconds in two hours = 7200000 ms.
     * @param multiplier
     *            The number of time units
     * @param chronoUnit
     *            The time unit.
     *
     * @return The number of milliseconds in the time range specified.
     */
    public long getTotalMillis(int multiplier, ChronoUnit chronoUnit) {
        if (multiplier <= 0) {
            throw new IllegalArgumentException("invalid multiplier=" + multiplier);
        }
        Long unitSize = null;
        if (chronoUnit != null) {
            unitSize = chronoSizeMap.get(chronoUnit);
        }
        if (unitSize == null) {
            throw new IllegalArgumentException("invalid ChronoUnit=" + chronoUnit);
        }
        return unitSize * multiplier;
    }

    /**
     * Checks if the interval for the provided timestamp is before the current
     * time. For example, if the interval size is one hour then the timestamp
     * will have to be in an earlier hour.
     * @param timestamp
     *		The timestamp to check.
     * @param bucketSizeMillis
     *      The size of the bucket in milliseconds.
     * @return
	 * 		True if the timestamp's interval is before the current time's interval.
     */
    public boolean isTimeStampIntervalBeforeCurrent(long timestamp, long bucketSizeMillis) {
        long intervalStart = truncateTimestamp(timestamp, bucketSizeMillis);

        return (intervalStart + bucketSizeMillis) <= getCurrentUtcTime();
    }

    /**
     * Checks if the interval for the provided timestamp is before the current
     * time. For example, if the interval size is one hour then the timestamp
     * will have to be in an earlier hour.
     * @param timestamp
     *		The timestamp to check.
     * @param multiplier
     *		The number of time units in the time bucket.
     * @param chronoUnit
     *		The Time unit on the multiplier.
     * @return
	 * 		True if the timestamp's interval is before the current time's interval.
     */
    public boolean isTimeStampIntervalBeforeCurrent(long timestamp, short multiplier, ChronoUnit chronoUnit) {
        long intervalStart = truncateTimestamp(timestamp, multiplier, chronoUnit);

        return (intervalStart + getTotalMillis(multiplier, chronoUnit)) <= getCurrentUtcTime();
    }

    /**
     *
     * @param millis
     *		a time in milliseconds.
     * @return
	 * 		The time in nanoseconds.
     */
    public long makeHighResolutionTime(long millis) {
        return (millis * NANOS_PER_MILLI) + (getCurrentUtcTimeNanos() % NANOS_PER_MILLI);
    }

    /**
     * Helper method to ignore the exception on a sleep.
     * @param time
     *		The time to sleep in milliseconds.
     */
    public void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            if ( LOG.isDebugEnabled()) {
                LOG.debug( "sleep interrupted", e);
            }
        }
    }

    /**
     * Truncates the timestamp into its time bucket. The bucketSizeMillis is
     * expected to be rounded to the desired size.
     *
     * @param timestamp
     *            The timestamp to truncate. Must be non-negative.
     * @param bucketSizeMillis
     *            The size of the time bucket in milliseconds. Must be greater
     *            than 0.
     *
     * @return The timestamp truncated based on the specified bucket.
     *
     * @throws IllegalArgumentException
     *             Thrown if the parameter values are not allowed.
     */
    public long truncateTimestamp(long timestamp, long bucketSizeMillis) {
        if (timestamp < 0) {
            throw new IllegalArgumentException("invalid timestamp=" + timestamp);
        }

        if (bucketSizeMillis <= 0) {
            throw new IllegalArgumentException("invalid bucketSizeMillis=" + bucketSizeMillis);
        }
        return timestamp / bucketSizeMillis * bucketSizeMillis;
    }

    /**
     * Truncates the timestamp into its time bucket. The bucket is defined based
     * on the ChronoUnit and multiplier. For example, ChronoUnit.HOURS and
     * multiplier=3 will place the timestamp into its three hour time bucket (or
     * time window). so 14:17:37 becomes 12:00:00 since that is the 3 hour
     * bucket that contains the time. The bucket, therefore, will go from
     * 12:00:00 to 14:59:59.999.
     *
     * @param timestamp
     *		The timestamp to truncate. Must be non-negative.
     * @param multiplier
     *      The number of timeunits in the time bucket.
     * @param chronoUnit
     *      The timeunit on the multiplier
     * @return
     * 		The timestamp truncated based on the specified bucket.
     * @throws IllegalArgumentException
     *		Thrown if the parameter values are not allowed.
     */
    public long truncateTimestamp(long timestamp, int multiplier, ChronoUnit chronoUnit) {
        return truncateTimestamp(timestamp, getTotalMillis(multiplier, chronoUnit));
    }

    static public ChronoUnit asChronoUnit( String value) {
        Objects.requireNonNull( value, "unit");
        final String val = value.trim().toUpperCase();
        try {
            return ChronoUnit.valueOf( val);
        } catch ( Throwable ex) {
            return chronoUnit( TimeUnit.valueOf( val));
        }
    }

    static public TimeUnit asTimeUnit( String value) {
        Objects.requireNonNull( value, "unit");
        final String val = value.trim().toUpperCase();
        try {
            return TimeUnit.valueOf( val);
        } catch ( Throwable ex) {
            return timeUnit( ChronoUnit.valueOf( val));
        }
    }

    /**
     * Converts a {@code TimeUnit} to a {@code ChronoUnit}.
     * <p>
     * This handles the seven units declared in {@code TimeUnit}.
     * @param unit
     *      the unit to convert, not null
     * @return
     *      the converted unit, not null
     */
    static public ChronoUnit chronoUnit( TimeUnit unit) {
        Objects.requireNonNull(unit, "unit");
        switch (unit) {
            case NANOSECONDS:
                return ChronoUnit.NANOS;
            case MICROSECONDS:
                return ChronoUnit.MICROS;
            case MILLISECONDS:
                return ChronoUnit.MILLIS;
            case SECONDS:
                return ChronoUnit.SECONDS;
            case MINUTES:
                return ChronoUnit.MINUTES;
            case HOURS:
                return ChronoUnit.HOURS;
            case DAYS:
                return ChronoUnit.DAYS;
            default:
                throw new IllegalArgumentException("Unknown TimeUnit constant");
        }
    }

    /**
     * Converts a {@code ChronoUnit} to a {@code TimeUnit}.
     * <p>
     * This handles the seven units declared in {@code TimeUnit}.
     * @param unit
     *      the unit to convert, not null
     * @return
     *      the converted unit, not null
     * @throws IllegalArgumentException
     *      if the unit cannot be converted
     */
    static public TimeUnit timeUnit(ChronoUnit unit) {
        Objects.requireNonNull( unit, "unit");
        switch (unit) {
            case NANOS:
                return TimeUnit.NANOSECONDS;
            case MICROS:
                return TimeUnit.MICROSECONDS;
            case MILLIS:
                return TimeUnit.MILLISECONDS;
            case SECONDS:
                return TimeUnit.SECONDS;
            case MINUTES:
                return TimeUnit.MINUTES;
            case HOURS:
                return TimeUnit.HOURS;
            case DAYS:
                return TimeUnit.DAYS;
            default:
                throw new IllegalArgumentException("ChronoUnit cannot be converted to TimeUnit: " + unit);
        }
    }

}
