package com.sams.er.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sams.er.client.eai.EAIBadRequestException;
import com.sams.er.client.eai.Email;
import com.sams.er.client.eai.EmailNotificationRequest;
import com.sams.er.client.eai.InternalServerException;
import com.sams.er.client.eai.dto.*;
import com.sams.er.client.eai.mappings.TaxRateBracket;
import com.sams.er.client.eai.mappings.*;
import com.sams.er.client.oe.StoreConfigResponse;
import com.sams.er.headers.RequestHeaders;
import com.sams.er.models.cash.CashNotificationDynamicData;
import com.sams.er.util.constants.ClientApp;
import com.sams.er.util.constants.EmailTemplate;
import com.walmart.services.checkout.commons.adapter.Jackson1Mapper;
import com.walmart.services.checkout.commons.dto.*;
import com.walmart.services.checkout.commons.dto.constants.PaymentInfoStatus;
import com.walmart.services.checkout.commons.dto.constants.TenderType;
import com.walmart.services.checkout.commons.dto.response.AssociateDiscount;
import com.walmart.services.checkout.commons.dto.response.SavingDiscount;
import com.walmart.services.cpcpay.core.dto.standard.PaymentInstrument;
import com.walmart.services.cxo.commons.api.Discount;
import com.walmart.services.cxo.commons.api.Fee;
import com.walmart.services.cxo.commons.api.OrderTotals;
import com.walmart.services.cxo.commons.api.enums.DiscountType;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class ObjectMappingHelper {

    private String orderHistory;

    private String clubHours;

    private String clubDirections;

    private static final Logger logger = LoggerFactory.getLogger(ObjectMappingHelper.class);

    private static final ObjectMapper JACKSON_MAPPER = Jackson1Mapper.instance().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public ObjectMappingHelper(String clubHours, String clubDirections, String orderHistory) {
        this.clubHours = clubHours;
        this.clubDirections = clubDirections;
        this.orderHistory = orderHistory;
    }

    public String mapEmailObject(PurchaseContract purchaseContract, StoreConfigResponse storeConfigResponse, RequestHeaders requestHeaders) {
        Email email = new Email();
        EmailNotificationRequest emailRequest = new EmailNotificationRequest();
        String emailReqString = null;
        if (StringUtils.isNoneEmpty(purchaseContract.getBuyerInfo().getPrimaryContact().getEmail().getEmailAddress())) {
            logger.info("=========== EMailId: "+ purchaseContract.getBuyerInfo().getPrimaryContact().getEmail().getEmailAddress());
            email.setMemberEmailId(purchaseContract.getBuyerInfo().getPrimaryContact().getEmail().getEmailAddress());
        } else {
            logger.error("Error =========== Email ID is not found:");
            throw new EAIBadRequestException("Bad Request Exception: EmailID is Not found");
        }

        if(ClientApp.US_WEBPOS_KIOSK_SAMS.toString().equals(requestHeaders.getCpcClientApp())) {
            email.setTemplateId(EmailTemplate.CPPOS_RECEIPT.toString());
        }
        //email.setUserName("Test User");
        email.setEmailNotification(Boolean.TRUE); //Always true, Only for logging purpose for EAI
        email.setPurchasseContract(mapEmailPurchaseContract(purchaseContract));
        if(null != storeConfigResponse) {
            mapTransactionLocation(email, storeConfigResponse);
        }
        emailRequest.setEmail(email);
        orderParentChildItems(emailRequest);

        try {
            emailReqString = JACKSON_MAPPER.writeValueAsString(emailRequest);
            logger.info("Email Request to EAI ===========>: "+emailReqString);
        } catch (JsonProcessingException e) {
            logger.error("Error Processing Email Request into a String====");
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Error Processing Request into a String");
        }
        return emailReqString;
    }

    private void orderParentChildItems(EmailNotificationRequest emailRequest) {
        List<Item> items = new ArrayList<>();
        List<String> insertedChildItemsList = new ArrayList<>();

        final int[] itemPosition = {0};
        final int[] itemSequenceNumber = {1};

        for (Item item : emailRequest.getEmail().getPurchasseContract().getItems()) {
            if ((resolveNulls(item::getLinkedLineItems).isPresent()) && !item.getLinkedLineItems().isEmpty()) {
                //Process items only if they have linkedItems (if has any child items)
                item.setItemSequenceNumber(itemSequenceNumber[0]++);
                items.add(itemPosition[0], item);
                itemPosition[0]++;
                List<String> tempChildItemsList = new ArrayList<>();
                item.getLinkedLineItems().stream().forEach(linkedId -> {
                    tempChildItemsList.add(linkedId.toString());
                });

                tempChildItemsList.forEach(tempchildItem -> {
                    if (insertedChildItemsList.stream().noneMatch(tempchildItem::equals
                    )) {

                        emailRequest.getEmail().getPurchasseContract().getItems().stream()
                                .filter( item1 -> item1.getId().equals(tempchildItem) )
                                .findAny().ifPresent(matchedItem -> {
                                    matchedItem.setItemSequenceNumber(itemSequenceNumber[0]++);
                                    items.add(itemPosition[0], matchedItem);
                                    itemPosition[0]++;
                                    insertedChildItemsList.add(tempchildItem);
                                });

                        /*emailRequest.getEmail().getPurchasseContract().getItems().parallelStream().forEach(item1 -> {
                            if(item1.getId().equals(childItem)) {
                                items.add(itemPosition[0], item);
                                itemPosition[0]++;
                                insertedChildItemsList.add(childItem);
                                break; //wont work, We can't 'break' Stream loop in java8. java9 has 'takeWhile' for this purpose.
                            }
                        } );*/
                    }
                });

            } else if(!resolveNulls(item::getLinkedTo).isPresent()){
                /*
                 else, Process items only if they neither have linkedTo nor linkedItems to it
                 (i.e independent and regular items, no linkedItems and it is not linked to any other item.).
                 */
                item.setItemSequenceNumber(itemSequenceNumber[0]++);
                items.add(itemPosition[0], item);
                itemPosition[0]++;
            }
        }
        emailRequest.getEmail().getPurchasseContract().setItems(items);

    }

    private EmailPurchaseContract mapEmailPurchaseContract(PurchaseContract purchaseContract) {
        EmailPurchaseContract emailPurchaseContract = new EmailPurchaseContract();
        emailPurchaseContract.setItemCount(purchaseContract.getItemCount());
        emailPurchaseContract.setItems(mapItems(purchaseContract));
        emailPurchaseContract.setPayments(mapPayments(purchaseContract.getPayments()));
        emailPurchaseContract.setTransactionData(mapTransactionData(purchaseContract));
        return emailPurchaseContract;

    }

    private TransactionData mapTransactionData(PurchaseContract purchaseContract) {
        TransactionData transactionData = new TransactionData();
        transactionData.setClientApp(purchaseContract.getWmStoreExtension().getLedgers().get(0).getClientApp());
        transactionData.setDeviceId(purchaseContract.getWmStoreExtension().getLedgers().get(0).getDeviceId());
        transactionData.setCreatedDate(purchaseContract.getWmStoreExtension().getCreatedDate().toString());
        transactionData.setModifiedDate(purchaseContract.getWmStoreExtension().getModifiedDate().toString());
        transactionData.setSubmittedTime(purchaseContract.getWmStoreExtension().getSubmittedTime().toString());
        transactionData.setRegisterNumber(purchaseContract.getWmStoreExtension().getRegisterNumber());
        transactionData.setTcNumber(purchaseContract.getWmStoreExtension().getCustomerOrderID());
        transactionData.setTransactionId(purchaseContract.getWmStoreExtension().getTransactionId());
        transactionData.setIsdTotalTax(mapTax(purchaseContract));
        transactionData.setOrderHistory(orderHistory);
       // transactionData.setTransactionLocation(mapTrxLocation(purchaseContract));
        transactionData.setPurchaseContractTotals(mapTotals(purchaseContract.getPurchaseContractTotals()));

        return transactionData;

    }

    private PurchaseContractTotals mapTotals(OrderTotals orderTotals) {
        PurchaseContractTotals purchaseContractTotals = new PurchaseContractTotals();

        purchaseContractTotals.setGrandTotal(orderTotals.getGrandTotal().getCurrencyAmount());
        purchaseContractTotals.setTaxTotal(orderTotals.getTaxTotal().getCurrencyAmount());
        if(null != orderTotals.getDiscountedSubTotal()) {
            purchaseContractTotals.setDiscountedSubTotal(orderTotals.getDiscountedSubTotal().getCurrencyAmount());
        }
        purchaseContractTotals.setDiscountedSubTotal(null != orderTotals.getDiscountedSubTotal()
                ? orderTotals.getDiscountedSubTotal().getCurrencyAmount()
                : orderTotals.getGrandTotal().getCurrencyAmount());
        purchaseContractTotals.setDiscountEligibleSubTotal(null != orderTotals.getDiscountEligibleSubTotal()
                ? orderTotals.getDiscountEligibleSubTotal().getCurrencyAmount()
                : BigDecimal.ZERO);

        purchaseContractTotals.setSavingsTotal(null != orderTotals.getSavingsTotal()
                ? orderTotals.getSavingsTotal().getCurrencyAmount()
                : BigDecimal.ZERO);
        List<Fee> feeTotals = orderTotals.getFeeTotals();
        BigDecimal productFees = BigDecimal.ZERO;
        for (Fee fee : feeTotals) {
            productFees = productFees.add(fee.getFeesTotal().getCurrencyAmount());
        }
        BigDecimal newSubTotal = orderTotals.getSubTotal().getCurrencyAmount().add(productFees);
        purchaseContractTotals.setSubTotal(newSubTotal);
        purchaseContractTotals.setProductFee(productFees);

        return purchaseContractTotals;
    }

    private void mapTransactionLocation(Email email, StoreConfigResponse storeConfigResponse) {

        if(resolveNulls(storeConfigResponse::getAddress).isPresent()) {
            TransactionLocation transactionLocation = new TransactionLocation();
            transactionLocation.setStoreId(storeConfigResponse.getStoreNumber());
            if(resolveNulls(() -> storeConfigResponse.getManager().getPhoneNumber()).isPresent()) {
                transactionLocation.setStorePhoneNumber(storeConfigResponse.getManager().getPhoneNumber());
            }
            transactionLocation.setStoreAddress(mapAddress(storeConfigResponse));
            email.getPurchasseContract().getTransactionData().setTransactionLocation(transactionLocation);
        }
        if(resolveNulls(storeConfigResponse::getStoreLocation).isPresent()) {
            StoreLocationDTO storeLocationDTO = new StoreLocationDTO();
            storeLocationDTO.setLatitude(storeConfigResponse.getStoreLocation().getLatitude());
            storeLocationDTO.setLongitude(storeConfigResponse.getStoreLocation().getLongitude());

            if(resolveNulls(storeConfigResponse::getTimezone).isPresent()) {
                TimeZoneDTO timeZoneDto = new TimeZoneDTO();
                LocationDTO locationDto = new LocationDTO();

                String latitude = null;
                String longitude = null;
                if(resolveNulls(() -> storeConfigResponse.getTimezone().getLocation().getLongitude()).isPresent()) {
                    longitude = storeConfigResponse.getTimezone().getLocation().getLongitude();
                } else if(resolveNulls(() -> storeConfigResponse.getStoreLocation().getLongitude()).isPresent()) {
                    longitude = storeConfigResponse.getStoreLocation().getLongitude().toString();
                }

                if(resolveNulls(() -> storeConfigResponse.getTimezone().getLocation().getLatitude()).isPresent()) {
                    latitude = storeConfigResponse.getTimezone().getLocation().getLatitude();
                } else if(resolveNulls(() -> storeConfigResponse.getStoreLocation().getLatitude()).isPresent()) {
                    latitude = storeConfigResponse.getStoreLocation().getLatitude().toString();
                }
                locationDto.setLatitude(latitude);
                locationDto.setLongitude(longitude);
                if(resolveNulls(() -> storeConfigResponse.getTimezone().getLocation()).isPresent()) {
                    locationDto.setRegion(storeConfigResponse.getTimezone().getLocation().getRegion());
                }
                TimeDTO timeDto = new TimeDTO();
                ZoneDTO zoneDto = new ZoneDTO();
                zoneDto.setCurrent(mapCurrentTimeZone(storeConfigResponse));
                zoneDto.setNext(mapNextTimeZone(storeConfigResponse));
                timeDto.setZone(zoneDto);

                timeZoneDto.setLocation(locationDto);
                timeZoneDto.setTime(timeDto);

                storeLocationDTO.setTimeZone(timeZoneDto);
                if(StringUtils.isNotEmpty(latitude) && StringUtils.isNotEmpty(longitude)) {
                    final String storeDirections = clubDirections + latitude + "," + longitude;
                    storeLocationDTO.setClubDirection(storeDirections);
                }
                email.getPurchasseContract().getTransactionData().getTransactionLocation().setStoreCoordinates(storeLocationDTO);
                final String storeHours = clubHours + "/"+storeConfigResponse.getStoreNumber();
                email.getPurchasseContract().getTransactionData().getTransactionLocation().getStoreCoordinates().setClubHours(storeHours);
            }
            //StoreInformation storeInformation = new StoreInformation();
        }
    }

    private AddressDTO mapAddress(StoreConfigResponse storeConfigResponse) {
        AddressDTO addressDTO = new AddressDTO();
        if(resolveNulls(storeConfigResponse::getAddress).isPresent()) {
            addressDTO.setAddressLine1(storeConfigResponse.getAddress().getAddress1());
            addressDTO.setCity(storeConfigResponse.getAddress().getCity());
            addressDTO.setCounty(storeConfigResponse.getAddress().getCounty());
            addressDTO.setState(storeConfigResponse.getAddress().getState());
            addressDTO.setZipCode(storeConfigResponse.getAddress().getZipCode());
            addressDTO.setCountry(resolveNulls(() -> storeConfigResponse.getTimezone().getLocation().getRegion()).isPresent()
                    ? storeConfigResponse.getTimezone().getLocation().getRegion() : storeConfigResponse.getCountryCode());
        }
        return addressDTO;
    }

    private NextDTO mapNextTimeZone(StoreConfigResponse storeConfigResponse) {
        NextDTO nextDto = new NextDTO();
        if(resolveNulls(() -> storeConfigResponse.getTimezone().getTime().getZone().getNext()).isPresent()) {
            nextDto.setAbbreviation(storeConfigResponse.getTimezone().getTime().getZone().getNext().getAbbreviation());
            nextDto.setDescription(storeConfigResponse.getTimezone().getTime().getZone().getNext().getDescription());
            nextDto.setEffectiveUntil(storeConfigResponse.getTimezone().getTime().getZone().getNext().getEffectiveUntil());
            nextDto.setIsdst(storeConfigResponse.getTimezone().getTime().getZone().getNext().getIsdst());
            nextDto.setUtcoffset(storeConfigResponse.getTimezone().getTime().getZone().getNext().getUtcoffset());
        }
        return nextDto;
    }

    private CurrentDTO mapCurrentTimeZone(StoreConfigResponse storeConfigResponse) {
        CurrentDTO currentDto = new CurrentDTO();
        if(resolveNulls(() -> storeConfigResponse.getTimezone().getTime().getZone().getCurrent()).isPresent()) {
            currentDto.setAbbreviation(storeConfigResponse.getTimezone().getTime().getZone().getCurrent().getAbbreviation());
            currentDto.setDescription(storeConfigResponse.getTimezone().getTime().getZone().getCurrent().getDescription());
            currentDto.setEffectiveUntil(storeConfigResponse.getTimezone().getTime().getZone().getCurrent().getEffectiveUntil());
            currentDto.setIsdst(storeConfigResponse.getTimezone().getTime().getZone().getCurrent().getIsdst());
            currentDto.setUtcoffset(storeConfigResponse.getTimezone().getTime().getZone().getCurrent().getUtcoffset());
        }
        return currentDto;
    }

    /*private TransactionLocation mapTrxLocation(PurchaseContract purchaseContract) {
        TransactionLocation transactionLocation = new TransactionLocation();
        if(null != purchaseContract.getPurchaseContractLocation()) {
            transactionLocation.setCity(purchaseContract.getPurchaseContractLocation().getCity());
            transactionLocation.setCountryCode(purchaseContract.getPurchaseContractLocation().getCountryCode());
            transactionLocation.setPostalCode(purchaseContract.getPurchaseContractLocation().getPostalCode());
            transactionLocation.setStateOrProvinceCode(purchaseContract.getPurchaseContractLocation().getStateOrProvinceCode());
            transactionLocation.setStoreId(purchaseContract.getPurchaseContractLocation().getPickUpStores().get(0).getStoreFrontId().getStoreId());
        }

        if (!StringUtils.isEmpty(Objects.requireNonNull(purchaseContract.getPurchaseContractLocation()).getAddressLineOne())) {
            transactionLocation.setStreetAddress(purchaseContract.getPurchaseContractLocation().getAddressLineOne());
        } else {
            //purchaseContract.getPayments().filter
            Optional<PaymentInfo> optionalPaymentInfo = purchaseContract.getPayments().parallelStream().filter(pay -> resolveNulls(() -> pay.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getBusinessUnit()).isPresent())
                    .findAny();
            //.map(pay.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getBusinessUnit().)
            optionalPaymentInfo.ifPresent(optpay -> {
                transactionLocation.setStreetAddress(optpay.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getBusinessUnit().getAddress().getAddressLine1());
            });
        }
        return transactionLocation;
    }*/

    private IsdTotalTax mapTax(PurchaseContract purchaseContract) {
        IsdTotalTax isdTotalTax = new IsdTotalTax();
        isdTotalTax.setTotalTaxAmount(purchaseContract.getWmStoreExtension().getIsdTotalTax().getTotalTaxAmount());
        isdTotalTax.setTaxRateBracket(mapTaxRateBrackets(purchaseContract.getWmStoreExtension().getIsdTotalTax().getTaxRateBrackets()));
        return isdTotalTax;
    }

    private List<TaxRateBracket> mapTaxRateBrackets(List<com.walmart.services.checkout.commons.dto.TaxRateBracket> taxRateBrackets) {

        List<TaxRateBracket> taxBrackets = new ArrayList<>();
        taxRateBrackets.forEach(taxRateBracket -> {
            TaxRateBracket taxBracket = new TaxRateBracket();
            taxBracket.setBracketAmount(taxRateBracket.getBracketAmount());
            taxBracket.setTaxRateAmount(taxRateBracket.getTaxRateAmount());
            taxBracket.setTaxCode(taxRateBracket.getTaxCode());
            taxBracket.setTaxRateAmountType(taxRateBracket.getTaxRateAmountType());
            taxBracket.setTaxRateId(taxRateBracket.getTaxRateId());

            taxBrackets.add(taxBracket);
        });
        return taxBrackets;
    }

    private List<Payment> mapPayments(List<PaymentInfo> paymentInfos) {
        List<Payment> payments = new ArrayList<>();

        /*emailRequest.getEmail().getPurchasseContract().getItems().parallelStream()
                .filter( item1 -> item1.getId().equals(tempchildItem) )
                .findAny().ifPresent(matchedItem -> {
            matchedItem.setItemSequenceNumber(itemSequenceNumber[0]++);
            items.add(itemPosition[0], matchedItem);
            itemPosition[0]++;
            insertedChildItemsList.add(tempchildItem);
        });*/
        paymentInfos.forEach(paymentInfo -> {
            if(PaymentInfoStatus.COMPLETED == paymentInfo.getStatus()
                    || PaymentInfoStatus.FL_COMPLETED == paymentInfo.getStatus()) {
                Payment payment = new Payment();
                payment.setAmountCharged(resolveNulls(() -> paymentInfo.getPayment().getPaymentInfo().getAmountSettled()).isPresent()
                        ? paymentInfo.getPayment().getPaymentInfo().getAmountSettled().getCurrencyAmount():  BigDecimal.ZERO);
                payment.setCurrencyType(resolveNulls(() -> paymentInfo.getPayment().getPaymentInfo().getAmountSettled().getCurrencyUnit()).isPresent()
                        ? paymentInfo.getPayment().getPaymentInfo().getAmountSettled().getCurrencyUnit().toString()
                        : null);
                if(resolveNulls(() -> paymentInfo.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getPaymentInstrument().getPaymentInstrumentIssuer()).isPresent()) {
                    String issuerType = matchIssuerType(paymentInfo.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getPaymentInstrument().getPaymentInstrumentIssuer().toString());
                    payment.setInstrumentIssuerType(StringUtils.isNotEmpty(issuerType)
                                    ? issuerType
                                    : paymentInfo.getWmStoreExtension().getCpcPayMessage().getPaymentCardInterface().getPayment().getPaymentInstrument().getPaymentInstrumentIssuer().toString());
                }
                payment.setPaymentMediaType(resolveNulls(() -> paymentInfo.getWmStoreExtension().getCpcPayMessage().getPaymentMediaType()).isPresent()
                        ? paymentInfo.getWmStoreExtension().getCpcPayMessage().getPaymentMediaType().toString()
                        : null);
                if(resolveNulls(paymentInfo::getTenderType).isPresent()) {
                    if(paymentInfo.getTenderType() == TenderType.BUSINESS_CASHBACK || paymentInfo.getTenderType() == TenderType.CONSUMER_CASHBACK
                            || paymentInfo.getTenderType() == TenderType.CASHBACK || paymentInfo.getTenderType() == TenderType.SAMS_CASHBACK
                            || paymentInfo.getTenderType() == TenderType.SAMSCASH || paymentInfo.getTenderType() == TenderType.SAMS_CLUB_CASH) {
                        payment.setTenderType(TenderType.SAMSCASH.toString());
                    } else if(paymentInfo.getTenderType() == TenderType.EBT_FOOD) {
                        payment.setTenderType("EBTFOOD");
                    } else if(paymentInfo.getTenderType() == TenderType.EBT_CASH) {
                        payment.setTenderType("EBTCASH");
                    } else {
                        payment.setTenderType(paymentInfo.getTenderType().toString());
                    }
                }
                if(resolveNulls(() -> paymentInfo.getWmStoreExtension().getPaymentCard().getSuffixDigits()).isPresent()) {
                    payment.setCardSuffixDigits(paymentInfo.getWmStoreExtension().getPaymentCard().getSuffixDigits());
                }
                payments.add(payment);
            }

        });

        return payments;
    }

    private String matchIssuerType(String paymentInstrumentIssuer) {
        switch(paymentInstrumentIssuer) {
            case "V":
                return PaymentInstrument.PaymentInstrumentIssuer.VISA.toString();
            case "M":
                return PaymentInstrument.PaymentInstrumentIssuer.MASTERCARD.toString();
            case "A":
                return PaymentInstrument.PaymentInstrumentIssuer.AMEX.toString();
            case "D":
                return PaymentInstrument.PaymentInstrumentIssuer.DISCOVER.toString();
            default:
                return "";

        }


    }

    private List<Item> mapItems(PurchaseContract purchaseContract) {
        List<Item> items = new ArrayList<>();
        purchaseContract.getPurchaseContractItems().stream().forEach(lineItem -> {
            Item item = new Item();
            item.setId(lineItem.getId().toString());
            item.setItemId(getItemId(lineItem));
            item.setUpc(getUpc(lineItem));
            item.setType(resolveNulls(() -> lineItem.getWmStoreExtension().getItemType()).isPresent()
                    ? lineItem.getWmStoreExtension().getItemType()
                    : null);
            item.setDescription(getItemName(lineItem));
            item.setQuantity(lineItem.getQuantity());
            item.setUnitOfMeasure(lineItem.getUnitOfMeasure().getCode());
            item.setUnitPrice(lineItem.getUnitPricingInfo().getPrice().getCurrencyAmount());
            item.setSubTotal(lineItem.getLineItemPricingInfo().getLineItemPrice().getCurrencyAmount());
            item.setItemsTotalPrice(resolveNulls(() -> lineItem.getLineItemPricingInfo().getLineItemDiscountedPrice().getCurrencyAmount()).isPresent()
                    ? lineItem.getLineItemPricingInfo().getLineItemDiscountedPrice().getCurrencyAmount()
                    : lineItem.getLineItemPricingInfo().getLineItemPrice().getCurrencyAmount());
            if((resolveNulls(() -> lineItem.getLineItemPricingInfo().getLineItemSavingsAmount().getCurrencyAmount()).isPresent()) &&
                    !BigDecimal.ZERO.equals(lineItem.getLineItemPricingInfo().getLineItemSavingsAmount().getCurrencyAmount())) {
                item.setLineItemSavingsAmount(lineItem.getLineItemPricingInfo().getLineItemSavingsAmount().getCurrencyAmount());
            }
            item.setTaxExempt(lineItem.isTaxExempt());
            item.setTaxIndicator(lineItem.getWmStoreExtension().getTaxIndicator());
            if(null != lineItem.getDiscountsApplied()) {
                item.setDiscountsApplied(mapDiscountsApplied(lineItem));
            }
            //TODO: addonitems after test a scenario, from where should we read thsi object? from linkedToItems or somewhere?
            //item.setAddOnItems(mapAddonItems(lineItem.getLinkedLineItemIds()));
            if(resolveNulls(lineItem::getLinkedTo).isPresent()) {
                item.setLinkedTo(lineItem.getLinkedTo().toString());
            }
            if(resolveNulls(lineItem::getLinkedLineItemIds).isPresent() && !lineItem.getLinkedLineItemIds().isEmpty()) {
                item.setLinkedLineItems(lineItem.getLinkedLineItemIds());
            }

            items.add(item);

        });

        return items;
    }

    private List<DiscountsApplied> mapDiscountsApplied(PurchaseLineItem purchaseLineItem) {
        List<DiscountsApplied> discounts = new ArrayList<>();
        purchaseLineItem.getDiscountsApplied().forEach(discount -> {
            DiscountsApplied discountsApplied = new DiscountsApplied();
            discountsApplied.setDiscountType(discount.getDiscountType());
            SavingDiscount savingsDiscount = getSavingsDiscount(discount);
            if(savingsDiscount != null) {
                discountsApplied.setSavingAmount(savingsDiscount.getTotalSavings());
                discountsApplied.setSavingType(savingsDiscount.getSavingType());
                discountsApplied.setQuantitiesApplied(savingsDiscount.getQuantityApplied());
            } else {
                AssociateDiscount associateDiscount = getAssociateDiscount(discount);
                if(associateDiscount != null) {
                    discountsApplied.setSavingAmount(associateDiscount.getTotalSavings());
                }
            }
            discounts.add(discountsApplied);
        });
        return discounts;
    }

    private SavingDiscount getSavingsDiscount(Discount discount) {
        SavingDiscount savingDiscount = null;
        if (DiscountType.SAVINGS == discount.getDiscountType() || DiscountType.LINKSAVE == discount.getDiscountType() || DiscountType.COUPON == discount.getDiscountType()
                || DiscountType.LINEITEM == discount.getDiscountType() || DiscountType.FUEL_SAVINGS == discount.getDiscountType()) {
            savingDiscount = (SavingDiscount) discount;

        }
        return savingDiscount;
    }

    private AssociateDiscount getAssociateDiscount(Discount discount) {
        if (DiscountType.ASSOCIATE == discount.getDiscountType()) {
            AssociateDiscount associateDiscount = (AssociateDiscount) discount;
            return associateDiscount;
        }
        return null;
    }

    private static String getItemName(PurchaseLineItem purchaseLineItem){
        AbstractProductItem productItem = purchaseLineItem.getProductItem();
        if (productItem instanceof ProductCarePlan) {
            ProductCarePlan productCarePlan = (ProductCarePlan) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> productCarePlan.getOffer().getOfferId().getSigningDescription()).isPresent()) {
                return productCarePlan.getOffer().getOfferId().getSigningDescription();
            }
        } else if (productItem instanceof PromotionalGiftCard) {
            PromotionalGiftCard promotionalGiftCard = (PromotionalGiftCard) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> promotionalGiftCard.getOffer().getOfferId().getSigningDescription()).isPresent()) {
                return promotionalGiftCard.getOffer().getOfferId().getSigningDescription();
            }
        } else {
            ProductOffer productOffer = (ProductOffer) purchaseLineItem.getProductItem();
            /*if (resolveNulls(() -> productOffer.getOffer().getOfferId().getSigningDescription()).isPresent()) {
                return productOffer.getOffer().getOfferId().getSigningDescription();
            }*/
            if (resolveNulls(() -> purchaseLineItem.getWmStoreExtension().getProduct().getName()).isPresent()) {
                return purchaseLineItem.getWmStoreExtension().getProduct().getName();
            } else if (resolveNulls(() -> productOffer.getOffer().getOfferId().getSigningDescription()).isPresent()) {
                return productOffer.getOffer().getOfferId().getSigningDescription();
            }

        }
        return StringUtils.EMPTY;
    }

    private static Long getItemId(PurchaseLineItem purchaseLineItem){
        AbstractProductItem productItem = purchaseLineItem.getProductItem();
        if (productItem instanceof ProductCarePlan) {
            ProductCarePlan productCarePlan = (ProductCarePlan) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> productCarePlan.getOffer().getOfferId().getUSItemId()).isPresent()) {
                return productCarePlan.getOffer().getOfferId().getUSItemId();
            }
        } else if (productItem instanceof PromotionalGiftCard) {
            PromotionalGiftCard promotionalGiftCard = (PromotionalGiftCard) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> promotionalGiftCard.getOffer().getOfferId().getUSItemId()).isPresent()) {
                return promotionalGiftCard.getOffer().getOfferId().getUSItemId();
            }
        } else {
            ProductOffer productOffer = (ProductOffer) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> productOffer.getOffer().getOfferId().getUSItemId()).isPresent()) {
                return productOffer.getOffer().getOfferId().getUSItemId();
            }
        }
        return null;
    }

    private static String getUpc(PurchaseLineItem purchaseLineItem){
        AbstractProductItem productItem = purchaseLineItem.getProductItem();
        if (productItem instanceof ProductCarePlan) {
            ProductCarePlan productCarePlan = (ProductCarePlan) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> productCarePlan.getOffer().getOfferId().getUpc()).isPresent()) {
                return productCarePlan.getOffer().getOfferId().getUpc();
            }
        } else if (productItem instanceof PromotionalGiftCard) {
            PromotionalGiftCard promotionalGiftCard = (PromotionalGiftCard) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> promotionalGiftCard.getOffer().getOfferId().getUpc()).isPresent()) {
                return promotionalGiftCard.getOffer().getOfferId().getUpc();
            }
        } else {
            ProductOffer productOffer = (ProductOffer) purchaseLineItem.getProductItem();
            if (resolveNulls(() -> productOffer.getOffer().getOfferId().getUpc()).isPresent()) {
                return productOffer.getOffer().getOfferId().getUpc();
            }
        }
        return null;
    }

    public static <T> Optional<T> resolveNulls(Supplier<T> resolver) {
        try {
            return Optional.ofNullable(resolver.get());
        } catch (NullPointerException e) {
            return Optional.empty();
        }
    }


    public static CashNotificationDynamicData mapCashNotificationDynamicDataClub(CashNotificationDynamicData cashNotificationDynamicData, StoreConfigResponse storeConfigResponse) {
        if(ObjectUtils.allNotNull(cashNotificationDynamicData, storeConfigResponse, storeConfigResponse.getAddress())) {
            cashNotificationDynamicData.setClubName(storeConfigResponse.getStoreDescription());
            cashNotificationDynamicData.setClubAddressLine1(storeConfigResponse.getAddress().getAddress1());
            cashNotificationDynamicData.setClubCity(storeConfigResponse.getAddress().getCity());
            cashNotificationDynamicData.setClubState(storeConfigResponse.getAddress().getState());
            cashNotificationDynamicData.setClubZipCode(storeConfigResponse.getAddress().getZipCode());
        }
        return cashNotificationDynamicData;
    }
}
