package com.sams.er.client.oe.mappings;

public class Next {

    private String abbreviation;

    private String description;

    private String utcoffset;

    private String effectiveUntil;

    private Boolean isdst;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUtcoffset() {
        return utcoffset;
    }

    public void setUtcoffset(String utcoffset) {
        this.utcoffset = utcoffset;
    }

    public String getEffectiveUntil() {
        return effectiveUntil;
    }

    public void setEffectiveUntil(String effectiveUntil) {
        this.effectiveUntil = effectiveUntil;
    }

    public Boolean getIsdst() {
        return isdst;
    }

    public void setIsdst(Boolean isdst) {
        this.isdst = isdst;
    }
}
