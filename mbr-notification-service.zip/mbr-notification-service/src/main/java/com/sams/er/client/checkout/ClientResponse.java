package com.sams.er.client.checkout;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sams.er.client.eai.EmailResponse;
import com.sams.er.client.oe.StoreConfigResponse;
import com.walmart.platform.soa.common.service.wrappers.ServiceResponse;
import com.walmart.services.checkout.commons.adapter.Jackson1Mapper;
import com.walmart.services.checkout.commons.dto.response.GetPurchaseContractResponse;
import com.walmart.services.checkout.commons.dto.response.PurchaseContractResponse;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.*;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.URI;
import java.util.*;

/**
 * JAX-RS Client Response Wrapper
 * @author VN90514
 * Created on 03/24/2021.
 */
public class ClientResponse extends Response {

    protected ClientResponse( ) {}

    MultivaluedMap<String, Object> headers = new MultivaluedHashMap<>();

    protected int status;
    @Override public int getStatus() { return status;}

    protected String reasonPhrase;
    @Override public StatusType getStatusInfo() {
        return new StatusType() {
            @Override public int getStatusCode() { return status;}
            @Override public Status.Family getFamily() {
                Status s = Status.fromStatusCode( status);
                return null != s? s.getFamily(): null;
            }
            @Override public String getReasonPhrase() {
                return reasonPhrase;
            }
        };
    }

    protected Entity entity;
    @Override public Object getEntity() throws IllegalStateException {
        return this.entity;
    }

    static protected final ObjectMapper jacksonMapper = Jackson1Mapper.instance().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
            .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
           // .configure(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES, false);

    @Override public <T> T readEntity(Class<T> entityType) throws  IllegalStateException {
        try {
            if ( entity.getEntity().getClass().isAssignableFrom( entityType)) {
                return (T) entity.getEntity();
            }
            return jacksonMapper.readValue( entity.getEntity().toString(), entityType);
        } catch ( Throwable ex) {
            throw new RuntimeException( ex);
        }
    }

    @Override public <T> T readEntity(GenericType<T> entityType) throws IllegalStateException {
        try {
            if(entityType.getType() == EmailResponse.class) {
                return jacksonMapper.readValue( entity.getEntity().toString(), (Class<T>) entityType.getType());
            } else if(entityType.getType() == StoreConfigResponse.class) {
                return jacksonMapper.readValue( entity.getEntity().toString(), (Class<T>) entityType.getType());
            }

            ParameterizedType type = (ParameterizedType) entityType.getType();

            if (    entityType.getRawType() == ServiceResponse.class
                    && null != type
                    && null != type.getActualTypeArguments()
                    &&    1 == type.getActualTypeArguments().length
                    ) {
                Type parameterType = type.getActualTypeArguments()[0];
                if ( parameterType == PurchaseContractResponse.class) {
//                    return jacksonMapper.readValue(entity.getEntity().toString(), new TypeReference<ServiceResponse<PurchaseContractResponse>>() {});
                } else if ( parameterType == GetPurchaseContractResponse.class) {
//                    return jacksonMapper.readValue(entity.getEntity().toString(), new TypeReference<ServiceResponse<GetPurchaseContractResponse>>() {});
//                } else if ( parameterType == XoRest.WmAddPaymentResponse.class) {
//                    return jacksonMapper.readValue(entity.getEntity().toString(), new TypeReference<ServiceResponse<XoRest.WmAddPaymentResponse>>() {});
//                } else if ( parameterType == AddPaymentResponse.class) {
//                    return jacksonMapper.readValue(entity.getEntity().toString(), new TypeReference<ServiceResponse<AddPaymentResponse>>() {});
//                } else {
//                    throw new MessageProcessingException("Unknown Generic Parameter Type: " + parameterType.getTypeName());
                }
            }
            return jacksonMapper.readValue( entity.getEntity().toString(), (Class<T>) entityType.getRawType());
        } catch ( Throwable ex) {
            throw new RuntimeException( ex);
        }
    }

    @Override public <T> T readEntity(Class<T> entityType, Annotation[] annotations) throws  IllegalStateException {
        try {
            return jacksonMapper.readValue( entity.getEntity().toString(), entityType);
        } catch ( Throwable ex) {
            throw new RuntimeException( ex);
        }
    }

    @Override public <T> T readEntity(GenericType<T> entityType, Annotation[] annotations) throws  IllegalStateException {
        try {
            return jacksonMapper.readValue( entity.getEntity().toString(), (Class<T>) entityType.getRawType());
        } catch ( Throwable ex) {
            throw new RuntimeException( ex);
        }
    }

    @Override public   boolean hasEntity   () throws IllegalStateException { return true;}

    @Override
    public MultivaluedMap<String, Object> getHeaders() {
        return super.getHeaders();
    }

    @Override
    public boolean bufferEntity() {
        return false;
    }

    @Override
    public void close() {

    }

    //    @Override public   boolean bufferEntity() throws MessageProcessingException, IllegalStateException { return false;}
//    @Override public      void close       () throws MessageProcessingException {return;}
    @Override public MediaType getMediaType() { return MediaType.APPLICATION_JSON_TYPE;}
    @Override public Locale getLanguage () { return Locale.getDefault();}
    @Override public int getLength() { return ((String) this.entity.getEntity()).length();}
    protected Set<String> allowedMethods = new TreeSet<>();
    @Override public Set<String> getAllowedMethods() {
        return 0 < this.allowedMethods.size()? this.allowedMethods: null;
    }
    @Override public Map<String, NewCookie> getCookies() {
        return null;
    }
    protected EntityTag etagHeader;
    @Override public EntityTag getEntityTag() {
        return this.etagHeader;
    }
    protected Date dateHeader;
    @Override public Date getDate() {
        return dateHeader;
    }
    protected Date lastModifiedHeader;
    @Override public Date getLastModified() {
        return lastModifiedHeader;
    }

    @Override public URI getLocation() {
        // should new a url with provided payment id
        return null;
    }

    @Override public Set<Link> getLinks() {
        return null;
    }

    @Override public boolean hasLink(String relation) {
        return false;
    }

    @Override public Link getLink(String relation) {
        return null;
    }

    @Override public Link.Builder getLinkBuilder(String relation) {
        throw new IllegalStateException();
    }

    @Override public MultivaluedMap<String, Object> getMetadata() {
        return headers;
    }

    @Override public MultivaluedMap<String, String> getStringHeaders() {
        throw new UnsupportedOperationException();
    }

    @Override public String getHeaderString( String name) {
        return getHeaderString(toListOfStrings( headers.get( name)));
    }

    // This conversion is needed as some values may not be Strings
    private List<String> toListOfStrings(List<Object> values) {
        if (values == null) {
            return null;
        } else {
            List<String> stringValues = new ArrayList<String>(values.size());
            for (Object value : values) {
                stringValues.add(value.toString());
            }
            return stringValues;
        }
    }

    private static String getHeaderString(List<String> values) {
        if ( values == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            String value = values.get(i);
            if ( value.isEmpty()) {
                continue;
            }
            sb.append(value);
            if (i + 1 < values.size()) {
                sb.append(",");
            }
        }
        return sb.toString();
    }

}
