package com.sams.er;

import com.sams.er.vault.CosmosProperties;
import com.sams.er.vault.CpcProperties;
import com.sams.er.vault.EaiProperties;
import com.sams.er.vault.NextgenEaiProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@EnableConfigurationProperties({CosmosProperties.class, CpcProperties.class, EaiProperties.class, NextgenEaiProperties.class})
@SpringBootApplication(scanBasePackages={"com.sams.er","io.strati.tunr.utils.client"})
        @PropertySources({
        @PropertySource("file:${secrets.dir}/sensitive.properties")
})

public class EmailReceiptsApplication {

    private static final Logger logger = LoggerFactory.getLogger(EmailReceiptsApplication.class);
    public static void main(String[] args) {
        SpringApplication.run(EmailReceiptsApplication.class, args);
    }
}
