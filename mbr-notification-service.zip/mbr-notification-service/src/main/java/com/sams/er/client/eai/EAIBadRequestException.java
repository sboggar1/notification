package com.sams.er.client.eai;

/**
 * General Checkout Service Exception
 * @author VN90514
 * Created on 03/24/2021.
 */
public class EAIBadRequestException extends RuntimeException {

    public EAIBadRequestException(String message) {
        super( message);
    }

    public EAIBadRequestException(String message, Throwable throwable) {
        super( message, throwable);
    }

    public EAIBadRequestException(Throwable throwable) {
        super( throwable);
    }

}
