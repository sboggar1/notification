package com.sams.er.client.eai;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sams.er.client.eai.mappings.EmailPurchaseContract;
import com.walmart.services.checkout.commons.dto.PurchaseContract;

import java.math.BigDecimal;

public class Email {
    //{"Email":{"member_email_id":"xyz@.COM","username":"APRIL","Template_ID":"ABC"}}

    @JsonProperty("member_email_id")
    private String memberEmailId;

    @JsonProperty("username")
    private String userName;

    @JsonProperty("template_id")
    private String templateId;

    @JsonProperty("email_notification")
    private Boolean emailNotification;

    @JsonProperty("purchaseContract")
    private EmailPurchaseContract purchasseContract;

    public Boolean getEmailNotification() {
        return emailNotification;
    }

    public void setEmailNotification(Boolean emailNotification) {
        this.emailNotification = emailNotification;
    }

    public String getMemberEmailId() {
        return memberEmailId;
    }

    public void setMemberEmailId(String memberEmailId) {
        this.memberEmailId = memberEmailId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public EmailPurchaseContract getPurchasseContract() {
        return purchasseContract;
    }

    public void setPurchasseContract(EmailPurchaseContract purchasseContract) {
        this.purchasseContract = purchasseContract;
    }

}
