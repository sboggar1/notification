package com.sams.er.client.eai.mappings;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public class Item {

    private String id;

    private Integer itemSequenceNumber;

    private Long itemId;

    private String type;

    private String description;

    private BigDecimal quantity;

    private BigDecimal unitPrice;

    private BigDecimal itemsTotalPrice;

    private BigDecimal lineItemSavingsAmount;

    private BigDecimal subTotal;

    private Boolean taxExempt;

    private String taxIndicator;

    private List<DiscountsApplied> discountsApplied;

    private String linkedTo;

    private List<UUID> linkedLineItems;

    private String unitOfMeasure;

    private String Upc;

    public String getUpc() {
        return Upc;
    }

    public void setUpc(String upc) {
        Upc = upc;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public List<UUID> getLinkedLineItems() {
        return linkedLineItems;
    }

    public void setLinkedLineItems(List<UUID> linkedLineItems) {
        this.linkedLineItems = linkedLineItems;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getItemsTotalPrice() {
        return itemsTotalPrice;
    }

    public void setItemsTotalPrice(BigDecimal itemsTotalPrice) {
        this.itemsTotalPrice = itemsTotalPrice;
    }

    public BigDecimal getLineItemSavingsAmount() {
        return lineItemSavingsAmount;
    }

    public void setLineItemSavingsAmount(BigDecimal lineItemSavingsAmount) {
        this.lineItemSavingsAmount = lineItemSavingsAmount;
    }

    public BigDecimal getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(BigDecimal subTotal) {
        this.subTotal = subTotal;
    }

    public Boolean getTaxExempt() {
        return taxExempt;
    }

    public void setTaxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
    }

    public String getTaxIndicator() {
        return taxIndicator;
    }

    public void setTaxIndicator(String taxIndicator) {
        this.taxIndicator = taxIndicator;
    }

    public List<DiscountsApplied> getDiscountsApplied() {
        return discountsApplied;
    }

    public void setDiscountsApplied(List<DiscountsApplied> discountsApplied) {
        this.discountsApplied = discountsApplied;
    }

    public Integer getItemSequenceNumber() {
        return itemSequenceNumber;
    }

    public void setItemSequenceNumber(Integer itemSequenceNumber) {
        this.itemSequenceNumber = itemSequenceNumber;
    }

    public String getLinkedTo() {
        return linkedTo;
    }

    public void setLinkedTo(String linkedTo) {
        this.linkedTo = linkedTo;
    }
}
