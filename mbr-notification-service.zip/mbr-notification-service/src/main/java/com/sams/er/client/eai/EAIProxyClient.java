package com.sams.er.client.eai;

import static com.sams.er.util.ClientUtil.updateMap;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sams.er.ccm.CommonConfig;
import com.sams.er.client.checkout.ClientHelper;
import com.walmart.services.checkout.commons.adapter.Jackson1Mapper;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestClientException;

public class EAIProxyClient {

    @Autowired
    private EAIProxyHelper eaiProxyHelper;

    /*@Autowired
    private RestClientHelper apiProxyClient;*/

    /*@Value("${eai.mailrouter.proxy.url}")
    private String eaiProxyUrl;*/

    @ManagedConfiguration
    private CommonConfig ccmConfigs;

    private static Logger logger = LoggerFactory.getLogger(EAIProxyClient.class);

    private static final ObjectMapper JACKSON_MAPPER = Jackson1Mapper.instance().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public EmailResponse callEAI(String request) throws URISyntaxException, IOException, InterruptedException, ExecutionException, TimeoutException {
        return callEAI(request, false);
    }
    public EmailResponse callEAI(String request, boolean isNextGenEai) throws URISyntaxException, IOException, InterruptedException, ExecutionException, TimeoutException {
        //Get the latest signature details and set in headers
        Map<String, String> signatureDetails;
        URL url;
        if(isNextGenEai) {
            signatureDetails = eaiProxyHelper.getNextGenSignatureMap();
            url = new URL(ccmConfigs.getNextgenEAIProxyUrl());
        } else {
            signatureDetails = eaiProxyHelper.getSignatureMap();
            url = new URL(ccmConfigs.getEaiMailrouterProxyUrl());
        }
        String timestamp = signatureDetails.get(EAIProxyConstants.WM_CONSUMER_INTIMESTAMP);
        String signature = signatureDetails.get(EAIProxyConstants.WM_SEC_AUTH_SIGNATURE);
        String consumerId = signatureDetails.get(EAIProxyConstants.WM_CONSUMER_ID);
        EmailResponse result = new EmailResponse();
        try {
            logger.info("Calling API Proxy for authorizing with request details -> " + "Timestamp: " + timestamp + " ,URL: " + ccmConfigs.getEaiMailrouterProxyUrl() + " ,Signature: " + signature);

            int timeout = 0;
            final Map<String, Object> headers = eaiProxyHelper.getApiProxyHeadersMap();
            updateMap(headers,ClientHelper.CONTENT_TYPE_HEADER_NAME, ClientHelper.APPLICATION_JSON);
            updateMap(headers,EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, timestamp);
            updateMap(headers,EAIProxyConstants.WM_SEC_AUTH_SIGNATURE, signature);
            updateMap(headers,EAIProxyConstants.WM_CONSUMER_ID, consumerId);
            updateMap(headers,EAIProxyConstants.WM_SVC_NAME, signatureDetails.get(EAIProxyConstants.WM_SVC_NAME));
            updateMap(headers,EAIProxyConstants.WM_SVC_ENV, signatureDetails.get(EAIProxyConstants.WM_SVC_ENV));
            Response response = 0 == timeout ? ClientHelper.postJson(url, headers, request)
                    : Executors.newSingleThreadExecutor().submit(() -> ClientHelper.postJson(url, headers, request)).get(timeout, TimeUnit.MILLISECONDS);
            Response.Status status = Response.Status.fromStatusCode(response.getStatus());
            logger.debug("Response received from EAI service : "+ response.getEntity());
            switch (status) {
                case OK:
                    if (response.hasEntity()) {
                        result = response.readEntity(new GenericType<EmailResponse>() {
                        });
                        return result;
                    }
                    break;
                case BAD_REQUEST:
                    throw new EAIBadRequestException("Email Not sent, Bad Request Exception");
                case INTERNAL_SERVER_ERROR:
                    throw new InternalServerException("Email Not sent, Internal server Exception");
                default:
                    throw new EAIClientException("Email not sent, Something went wrong calling the EAI service");
            }

        } catch (RestClientException e) {
            logger.error("RestClientException ========>"+e.getMessage(), e);
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Internal server Exception");
            //throw new URISyntaxException("Proxy Payment Service:", Objects.requireNonNull(e.getMessage()));
        } catch (EAIClientException | EAIBadRequestException e) {
            logger.error("========== Error While sending Email Receipt:" + e.getMessage());
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Internal server Exception");
        } catch (Exception e) {
            logger.error("========== Error calling Email Receipt servcie:" + e.getMessage());
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Internal server Exception");
        }
    return result;
    }
}
