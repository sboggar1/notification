package com.sams.er.service;

import static com.sams.er.util.ObjectMappingHelper.mapCashNotificationDynamicDataClub;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.sams.er.ccm.CommonConfig;
import com.sams.er.client.ERBadRequestException;
import com.sams.er.client.checkout.XoClient;
import com.sams.er.client.checkout.XoClientWebException;
import com.sams.er.client.eai.EAIProxyClient;
import com.sams.er.client.eai.EAIProxyHelper;
import com.sams.er.client.eai.EmailResponse;
import com.sams.er.client.eai.InternalServerException;
import com.sams.er.client.oe.OEClient;
import com.sams.er.client.oe.StoreConfigResponse;
import com.sams.er.constants.AppConstants;
import com.sams.er.headers.RequestHeaders;
import com.sams.er.models.cash.CashNotificationDynamicData;
import com.sams.er.models.cash.CashRedemptionEAIRequest;
import com.sams.er.util.ObjectMappingHelper;
import com.sams.er.util.OffsetDateTimeDeserializer;
import com.sams.er.util.OffsetDateTimeSerializer;
import com.sams.er.vault.VaultData;
import com.walmart.services.checkout.commons.adapter.Jackson1Mapper;
import com.walmart.services.checkout.commons.dto.PurchaseContract;
import com.walmart.services.checkout.commons.dto.constants.PurchaseContractStatus;
import com.walmart.services.checkout.commons.dto.response.GetPurchaseContractResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;
import javax.net.ssl.SSLContext;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class EmailReceiptServiceImpl implements EmailReceiptService {

    //@Value("${trust.store}")
    private Resource trustStore;

    //@Value("${trust.store.password}")
    private String trustStorePassword;

    @Autowired
    private EAIProxyHelper eaiProxyHelper;

    @Autowired
    private EAIProxyClient eaiProxyClient;

    @Autowired
    private XoClient xoClient;

    @Autowired
    private OEClient oeClient;

    @ManagedConfiguration
    private CommonConfig ccmConfigs;

    @Autowired
    private VaultData vaultData;

   /* @Autowired
    private ObjectMappingHelper objectMappingHelper;*/

    private static final Logger logger = LoggerFactory.getLogger(EmailReceiptServiceImpl.class);

    private static final ObjectMapper JACKSON_MAPPER = Jackson1Mapper.instance().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private ObjectMapper objectMapper;


    private void buildObjectMapper() {
        try {
            objectMapper = new ObjectMapper();
            SimpleModule module = new SimpleModule();
            module.addSerializer(OffsetDateTime.class, new OffsetDateTimeSerializer());
            module.addDeserializer(OffsetDateTime.class, new OffsetDateTimeDeserializer());
            objectMapper.registerModule(module);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        } catch (Exception exp) {
            logger.error("===========Error During buildObjectMapper ====");
            exp.printStackTrace();
            throw exp;
        }
    }

    @Override
    public EmailResponse processEmailCall(String purchaseContractRequest, RequestHeaders requestHeaders) {
        logger.info("inside ServiceImpl=========>");
        try {
            System.out.println("===== ccmConfig==="+new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(ccmConfigs));
            System.out.println("vault data==="+ vaultData.getPrivateKey());
            PurchaseContract purchaseContract = JACKSON_MAPPER.readValue(purchaseContractRequest, PurchaseContract.class);
            if (PurchaseContractStatus.SUBMITTED != purchaseContract.getStatus()) {
                logger.error("========== Error, Purchase contract is not in submitted state: status==>" + purchaseContract.getStatus());
                throw new ERBadRequestException("Email Not sent, Purchase contract status is "+purchaseContract.getStatus()+", status should be SUBMITTED");
            }
            logger.info("inside ServiceImpl, Purchase Contract Request=========>"+purchaseContract);
            ObjectMappingHelper objectMappingHelper = new ObjectMappingHelper(ccmConfigs.getSamsClubhoursUrl(), ccmConfigs.getSamsDirectionUrl(), ccmConfigs.getSamsOrderhistoryUrl());
            // call OE for storeconfig data
            return eaiProxyClient.callEAI(objectMappingHelper.mapEmailObject(purchaseContract,
                                                                             getStoreConfig(purchaseContract, requestHeaders.getCpcToken()),
                                                                             requestHeaders));
        } catch (XoClientWebException e) {
            logger.error("===========1 Error While sending Email Receipt:" + e.getReason());
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Internal server Exception");
        } catch (Exception ex) {
            logger.error("==========2 Error While sending Email Receipt, Exception reason:" + ex.getMessage());
            throw new InternalServerException("Email Not sent, Internal server Exception");
        }
    }

    @Override
    public EmailResponse processCashRedemptionEmail(String cashRedemptionBody, Map<String, String> requestHeaders) {
        try {
            logger.info("Entered into processCashRedemptionEmail method with body : "+ JACKSON_MAPPER.writeValueAsString(cashRedemptionBody)+". And Headers: "
                        +JACKSON_MAPPER.writeValueAsString(requestHeaders));
            CashRedemptionEAIRequest cashRedemptionEAIRequest = JACKSON_MAPPER.readValue(cashRedemptionBody, CashRedemptionEAIRequest.class);
            validateRedemptionEmail(cashRedemptionEAIRequest, requestHeaders);
            CashNotificationDynamicData cashNotificationDynamicData = cashRedemptionEAIRequest.getCashRedemptionNotification().getData().getCashNotificationDynamicData();
            if(StringUtils.isAnyEmpty(cashNotificationDynamicData.getClubName(),
                                      cashNotificationDynamicData.getClubAddressLine1(),
                                      cashNotificationDynamicData.getClubCity(),
                                      cashNotificationDynamicData.getClubState(),
                                      cashNotificationDynamicData.getClubZipCode())) {
                StoreConfigResponse storeConfigResponse = getStoreConfig(requestHeaders.get(AppConstants.HEADER_COUNTRY_CODE),
                                                                         requestHeaders.get(AppConstants.HEADER_STORE_NUMBER),
                                                                         requestHeaders.get(AppConstants.HEADER_CPC_TOKEN));
                cashNotificationDynamicData = mapCashNotificationDynamicDataClub(cashNotificationDynamicData, storeConfigResponse);
                cashRedemptionEAIRequest.getCashRedemptionNotification().getData().setCashNotificationDynamicData(cashNotificationDynamicData);
            }
            return eaiProxyClient.callEAI(JACKSON_MAPPER.writeValueAsString(cashRedemptionEAIRequest), true);
        } catch (Exception e) {
            logger.error("Email Not sent, Internal server Exception. Exception : " + e.getMessage());
            throw new InternalServerException(e);
        }
    }

    private void validateRedemptionEmail(CashRedemptionEAIRequest cashRedemptionEAIRequest, Map<String, String> requestHeaders) throws JsonProcessingException {
        if(!ObjectUtils.allNotNull(requestHeaders,
                                   requestHeaders.get(AppConstants.HEADER_STORE_NUMBER),
                                   requestHeaders.get(AppConstants.HEADER_COUNTRY_CODE))) {
            throw new ERBadRequestException("Missing mandatory header values of "+ AppConstants.HEADER_STORE_NUMBER + " & "+AppConstants.HEADER_COUNTRY_CODE);
        } else if(requestHeaders.get(AppConstants.HEADER_CPC_TOKEN) == null) {
            throw new ERBadRequestException("Missing cpc token of client");
        } else if(!ObjectUtils.allNotNull(cashRedemptionEAIRequest,
                                          cashRedemptionEAIRequest.getCashRedemptionNotification(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getEmailRecipients(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getTemplateId(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getSource(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getData(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getData().getCashNotificationDynamicData(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getData().getCashNotificationDynamicData().getUserName(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getData().getCashNotificationDynamicData().getRedeemedAmount(),
                                          cashRedemptionEAIRequest.getCashRedemptionNotification().getData().getCashNotificationDynamicData().getTransactionDateTime())) {
            throw new ERBadRequestException("Missing mandatory request payload");
        }
    }

    private StoreConfigResponse getStoreConfig(PurchaseContract purchaseContract, String cpcOeToken) {
        if(null != purchaseContract.getPurchaseContractLocation().getPickUpStores() && null != purchaseContract.getPurchaseContractLocation().getPickUpStores().get(0).getStoreFrontId().getStoreId()) {
            return getStoreConfig(purchaseContract.getPurchaseContractLocation().getCountryCode(),
                                  purchaseContract.getPurchaseContractLocation().getPickUpStores().get(0).getStoreFrontId().getStoreId(),
                                  cpcOeToken);
        }
        return null;
    }

    private StoreConfigResponse getStoreConfig(String countryCode, String storeId, String cpcOeToken) {
        if(StringUtils.isNoneEmpty(countryCode, storeId, cpcOeToken)) {
            return oeClient.callOE(countryCode, storeId, cpcOeToken);
        }
        return null;
    }

    private PurchaseContract callXOService(String purchaseContractId) {
        PurchaseContract purchaseContract = null;
        try {
            logger.info("Before calling checkout service, PurchaseContractId =========>"+ purchaseContractId);
            //String pcid = "7ec78ecb-78a2-47a4-9f8a-2b4b027e4d2c";
            purchaseContract = JACKSON_MAPPER.readValue(JACKSON_MAPPER.writeValueAsString(xoClient.get(UUID.fromString(purchaseContractId)).getPayload()), GetPurchaseContractResponse.class).getPurchaseContract();
            logger.info("After calling checkout service pc response====>"+purchaseContract);
        } catch (Exception e) {
            logger.error("Error calling checkout service======"+e.getMessage());
            e.printStackTrace();
        }
        return purchaseContract;
    }



    private RestTemplate getRestTemplate() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException, IOException {
        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(trustStore.getURL(), trustStorePassword.toCharArray())
                .build();
        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
        HttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(socketFactory)
                .build();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
        return new RestTemplate(factory);
    }

    /*public String callEAI(String request) throws URISyntaxException, IOException {
        //Get the latest signature details and set in headers

        define the privateKey and use it from keyvault if needed

        //EAIProxyHelper eaiProxyHelper = new EAIProxyHelper(clientConsumerId, privateKey);
        Map<String, String> signatureDetails = eaiProxyHelper.getSignatureMap();
        HttpHeaders httpHeaders = eaiProxyHelper.getApiProxyHeaders();
        String timestamp = signatureDetails.get(EAIProxyConstants.WM_CONSUMER_INTIMESTAMP);
        String signature = signatureDetails.get(EAIProxyConstants.WM_SEC_AUTH_SIGNATURE);
        httpHeaders.set(EAIProxyConstants.WM_CONSUMER_INTIMESTAMP, timestamp);
        httpHeaders.set(EAIProxyConstants.WM_SEC_AUTH_SIGNATURE, signature);
        String result;
        try {
            //  String request = AoJacksonMapper.AO_REQUEST_WRITER.writeValueAsString(aoRequest);
            logger.info("Calling API Proxy for authorizing with request details -> " + "Timestamp: " + timestamp + " ,URL: " + eaiProxyUrl + " ,Signature: " + signature);

            //=================
            XoClient xoClient =  new XoClient();
            String xoUrl = "https://membercheckout-cpc-stg.cld.samsclub.com/cpc-test";
            String pcid = "7ec78ecb-78a2-47a4-9f8a-2b4b027e4d2c";
            PurchaseContract purchaseContract = JACKSON_MAPPER.readValue(JACKSON_MAPPER.writeValueAsString(xoClient.get(UUID.fromString(pcid)).getPayload()), GetPurchaseContractResponse.class).getPurchaseContract();
            //=================


            RestTemplate restTemplate = new RestTemplate();
            HttpEntity httpEntity = new HttpEntity(request, httpHeaders);
            //RequestEntity<String> requestEntity = RequestEntity .post(new URL(eaiProxyUrl).toURI()) .contentType(MediaType.APPLICATION_JSON) .body(request);
            //restTemplate.exchange();
            result = restTemplate.exchange(eaiProxyUrl, HttpMethod.POST, httpEntity, String.class).getBody();
            System.out.println("result====>"+result);
            *//*CheckoutLoggingUtils.logResponseDetails(LoggingConstants.PROXY_AUTH_AO_AUTHORIZE, responseEntity);
            if (MessageUtils.getPaymentMediaType(aoRequest) != null && MessageUtils.getPaymentMediaType(aoRequest).equals(PaymentMediaType.EWIC)) {
                AoProxyUtils.assertAuthorizationDetail(result);
            } else {
                AoProxyUtils.assertPaymentAuthorization(result);
            }*//*
        *//*} catch (URISyntaxException | RestClientException e) {
            logger.error(e.getMessage(), e);
            throw new URISyntaxException("Proxy Payment Service:", e.getMessage());
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new IOException("Json Processing exception", e);*//*
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw e;
        }

        return result;
    }*/


}
