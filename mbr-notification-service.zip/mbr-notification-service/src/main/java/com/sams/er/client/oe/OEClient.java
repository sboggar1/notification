package com.sams.er.client.oe;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sams.er.ccm.CommonConfig;
import com.sams.er.client.checkout.ClientHelper;
import com.sams.er.client.eai.InternalServerException;
import com.walmart.services.checkout.commons.adapter.Jackson1Mapper;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class OEClient {

    /*@Value("${oe.url}")
    private String oeUrl;*/
    @ManagedConfiguration
    private CommonConfig ccmConfigs;

    //private String cpcOeToken;

    private static Logger logger = LoggerFactory.getLogger(OEClient.class);

    private static final ObjectMapper JACKSON_MAPPER = Jackson1Mapper.instance().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    /*public OEClient(String cpcOeToken) {
        this.cpcOeToken = cpcOeToken;
    }*/

    public StoreConfigResponse callOE(String countryCode, String storeId, String cpcOeToken) {

        int timeout =0;
        Response response = null;
        StoreConfigResponse result = new StoreConfigResponse();

        try {
            final String path = ccmConfigs.getOeUrl()+"/"+countryCode+"/"+storeId;
            logger.info(" OE StoreConfig Url===> "+ path);
            response = 0 == timeout ? ClientHelper.getJson(new URL(path), getHeaders(cpcOeToken))
                    : Executors.newSingleThreadExecutor().submit(() -> ClientHelper.getJson(new URL(path), getHeaders(cpcOeToken))).get(timeout, TimeUnit.MILLISECONDS);
            Response.Status status = Response.Status.fromStatusCode(response.getStatus());
            switch (status) {
                case OK:
                    if (response.hasEntity()) {
                        result = response.readEntity(new GenericType<StoreConfigResponse>() {
                        });
                        logger.info("StoreConfig Response for store ID: "+ result.getStoreNumber());
                        return result;
                    }
                    break;
                case BAD_REQUEST:
                    throw new OEBadRequestException("Email Not sent, Email not sent, Bad Request for calling OE/StoreConfig");
                case INTERNAL_SERVER_ERROR:
                    throw new InternalServerException("Email Not sent, Internal server Exception while calling OE/StoreConfig");
                default:
                    throw new OECientException("Email not sent, Email not sent, Some thing went wrong calling OE/StoreConfig Service");
            }
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            logger.error("Exception in calling OE =======>");
            e.printStackTrace();
            throw new InternalServerException("Email Not sent, Internal server Exception");
        }

        return result;
    }

    private Map<String, Object> getHeaders(String cpcOeToken) {
        Map<String, Object> headers = new HashMap<>();
        headers.put(OEConstants.CONTENT_TYPE, OEConstants.APPLICATION_JSON);
        headers.put(OEConstants.ACCEPT, OEConstants.APPLICATION_JSON);
        headers.put(OEConstants.CPC_TOKEN, cpcOeToken);
        return headers;
    }

}
