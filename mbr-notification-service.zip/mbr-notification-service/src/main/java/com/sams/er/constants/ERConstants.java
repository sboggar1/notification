package com.sams.er.constants;

public enum ERConstants {
    ERROR,
    SUCCESS,
    NOT_FOUND,
    CONFLICT,
    NOT_ALLOWED,
    BAD_REQUEST,
    INTERNAL_SERVER_ERROR,
    HEALTHY
}