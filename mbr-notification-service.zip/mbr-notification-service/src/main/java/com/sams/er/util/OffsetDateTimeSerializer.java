package com.sams.er.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class OffsetDateTimeSerializer extends StdSerializer<OffsetDateTime> {

    public OffsetDateTimeSerializer(){
        this(null);
    }
    ZoneOffset DEFAULT_ZONE_OFFSET = ZoneOffset.UTC;

    protected OffsetDateTimeSerializer(Class<OffsetDateTime> vc) {
        super(vc);
    }

    @Override
    public void serialize(OffsetDateTime offsetDateTime, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        String currentFieldName = jsonGenerator.getOutputContext().getCurrentName();
        String parentName = jsonGenerator.getOutputContext().getParent().getCurrentName();
        String value;
        offsetDateTime = offsetDateTime.truncatedTo(ChronoUnit.SECONDS);

        if (null != offsetDateTime) {
            value = offsetDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            jsonGenerator.writeString(value);
          /* if (currentFieldName.equals("paymentTimestamp") || currentFieldName.equals("authorizationTimestamp") || currentFieldName.equals("authorizedDate")) {
               value = offsetDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
               jsonGenerator.writeString(value);
           } else if(currentFieldName.equals("createddate") || (currentFieldName.equals("createdDate") && (null != parentName) && parentName.equals("paymentinfo"))) {
               value = offsetDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
               jsonGenerator.writeString(value);
           } else if (currentFieldName.equals("lastUpdateTimeStamp")) {
               jsonGenerator.writeNumber(offsetDateTime.toEpochSecond());
           } else {
               LocalDateTime  localDateTime = offsetDateTime.withOffsetSameInstant(DEFAULT_ZONE_OFFSET).truncatedTo(ChronoUnit.SECONDS).toLocalDateTime();
               value = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDateTime);
               jsonGenerator.writeString(value);
           }*/
        }
    }

}

