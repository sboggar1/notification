package com.sams.er.client.eai.mappings;

import java.math.BigDecimal;

public class Payment {

    private String paymentMediaType;

    private String tenderType;

    private BigDecimal amountCharged;

    private String currencyType;

    private String cardSuffixDigits;

    private String instrumentIssuerType;

    public String getPaymentMediaType() {
        return paymentMediaType;
    }

    public void setPaymentMediaType(String paymentMediaType) {
        this.paymentMediaType = paymentMediaType;
    }

    public String getTenderType() {
        return tenderType;
    }

    public void setTenderType(String tenderType) {
        this.tenderType = tenderType;
    }

    public BigDecimal getAmountCharged() {
        return amountCharged;
    }

    public void setAmountCharged(BigDecimal amountCharged) {
        this.amountCharged = amountCharged;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public String getCardSuffixDigits() {
        return cardSuffixDigits;
    }

    public void setCardSuffixDigits(String cardSuffixDigits) {
        this.cardSuffixDigits = cardSuffixDigits;
    }

    public String getInstrumentIssuerType() {
        return instrumentIssuerType;
    }

    public void setInstrumentIssuerType(String instrumentIssuerType) {
        this.instrumentIssuerType = instrumentIssuerType;
    }
}
