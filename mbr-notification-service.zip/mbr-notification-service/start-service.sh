#!/bin/ash

# The 'ash' shell is the default for Alpine Linux
# Variables are expected to be passed via docker whens starting the image
# You may have other variables; modify as needed.
#
# e.g. docker run -p 8080:8080 -e ENV=qa -e APPNAME=mbr-notification-service -e PROFILE=isd walmart/pos/email-receipts:latest

BASE_DIR=/home/app

. /etc/profile
export HOME=/home/app

# export clientId=3f321c37-3ed8-47c9-a622-7099cf2084d2
# export accessTokenUri=https://stagemembershipapim.cld.samsclub.com/token-generation/v1/oauth2/token
# export resource=https://walmart.onmicrosoft.com/2722169b-8d09-408d-a52d-bc31b48498ff
# export subsrciptionKey=8cbf9572533e4787ab8c655efd42d16e
# export ENV=dev
# export JAVA_OPTS='-Dspring.config.location=classpath:file:///home/app/resources/'

# These memory settings allow us to control how much memory is allocated to the container
# via Docker/k8s and force the JVM to use the maximum memory allocated
# e.g. docker run -m 3GB <other settings>
#
JVM_MEMORY="-XX:+UnlockExperimentalVMOptions -XX:+UseCGroupMemoryLimitForHeap -XX:MaxRAMFraction=1"

JAVA_OPTS="$JVM_MEMORY $JAVA_OPTS -Djavax.net.ssl.trustStore=/home/app/allServices-truststore.jks -Djavax.net.ssl.trustStorePassword=changeit"

echo "export JAVA_OPTS=\"$JAVA_OPTS\""

java ${JAVA_OPTS} -jar ${BASE_DIR}/mbr-notification-service*.jar
